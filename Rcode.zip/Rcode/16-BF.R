## ----beta24, fig.cap = "Beta distribution with parameters a = 4 and b = 2.", echo = FALSE----
ggplot(tibble(theta = c(0, 1)), aes(theta)) +
  stat_function(fun = dbeta, args = list(
    shape1 = 4,
    shape2 = 2
  ))


## ----LikelihoodPrior, fig=TRUE, include=TRUE, echo=FALSE, cache=FALSE, fig.width=7, fig.height=6, fig.cap = "Likelihood, priors, and posteriors for two models with differing priors. a) + d) Binomial likelihood for 80 successes out of 100 trials. b) + e) Prior beta distribution with parameters a = 4 and b = 2 (b) and with parameters a = 1 and b = 1 (e). c) + f) The likelihood times the prior, i.e., the posterior for each model.", eval = FALSE----
## x <- seq(0, 1, 0.01)
## y <- dbeta(x, 4, 2)
## p <- dbinom(80, 100, x)
## dat <- data.frame(x, y, p, z = y * p)
## gdat <- dat %>% gather(y, p, z, key = "distr", value = "value")
## gdat$distr <- factor(gdat$distr)
## levels(gdat$distr) <- c("Binomial likelih.", "Beta prior", "Likelihood x Prior")
## p1 <- ggplot(data = gdat, aes(x = x, y = value)) +
##   geom_line() +
##   facet_wrap(~distr, scales = "free_y") +
##   labs(x = "Probability of success", y = "") +
##   theme_bw()
## p1a <- ggplot(data = subset(gdat, distr == "Binomial likelih."), aes(x = x, y = value)) +
##   geom_line() +
##   facet_wrap(~distr, scales = "free_y") +
##   labs(x = expression(theta), y = "") +
##   theme_bw()
## p1b <- ggplot(data = subset(gdat, distr == "Beta prior"), aes(x = x, y = value)) +
##   geom_line() +
##   facet_wrap(~distr, scales = "free_y") +
##   coord_cartesian(ylim = c(0, 2.2)) +
##   labs(x = expression(theta), y = "") +
##   theme_bw()
## p1c <- ggplot(data = subset(gdat, distr == "Likelihood x Prior"), aes(x = x, y = value)) +
##   geom_line() +
##   facet_wrap(~distr, scales = "free_y") +
##   coord_cartesian(ylim = c(0, 0.22)) +
##   labs(x = expression(theta), y = "") +
##   theme_bw()
## 
## 
## 
## x <- seq(0, 1, 0.01)
## y <- dbeta(x, 1, 1)
## p <- dbinom(80, 100, x)
## dat2 <- data.frame(x, y, p, z = y * p)
## gdat2 <- dat2 %>% gather(y, p, z, key = "distr", value = "value")
## gdat2$distr <- factor(gdat2$distr)
## levels(gdat2$distr) <- c("Binomial likelih.", "Beta prior", "Likelihood x Prior")
## p2 <- ggplot(data = gdat2, aes(x = x, y = value)) +
##   geom_line() +
##   facet_wrap(~distr, scales = "free_y") +
##   labs(x = "Prob. of success", y = "") +
##   theme_bw()
## 
## p2a <- ggplot(data = subset(gdat2, distr == "Binomial likelih."), aes(x = x, y = value)) +
##   geom_line() +
##   facet_wrap(~distr, scales = "free_y") +
##   labs(x = expression(theta), y = "") +
##   theme_bw()
## p2b <- ggplot(data = subset(gdat2, distr == "Beta prior"), aes(x = x, y = value)) +
##   geom_line() +
##   facet_wrap(~distr, scales = "free_y") +
##   coord_cartesian(ylim = c(0, 2.2)) +
##   labs(x = expression(theta), y = "") +
##   theme_bw()
## p2c <- ggplot(data = subset(gdat2, distr == "Likelihood x Prior"), aes(x = x, y = value)) +
##   geom_line() +
##   facet_wrap(~distr, scales = "free_y") +
##   coord_cartesian(ylim = c(0, 0.22)) +
##   labs(x = expression(theta), y = "") +
##   theme_bw()
## 
## # gridExtra::grid.arrange(p1,p2,nrow=2)
## gridExtra::grid.arrange(p1a, p1b, p1c, p2a, p2b, p2c, nrow = 2)
## library(grid)
## grid.text(label = "a)", x = 0.05, y = 0.97, gp = gpar(fontsize = 20))
## grid.text(label = "b)", x = 0.39, y = 0.97, gp = gpar(fontsize = 20))
## grid.text(label = "c)", x = 0.71, y = 0.97, gp = gpar(fontsize = 20))
## 
## grid.text(label = "d)", x = 0.05, y = 0.47, gp = gpar(fontsize = 20))
## grid.text(label = "e)", x = 0.39, y = 0.47, gp = gpar(fontsize = 20))
## grid.text(label = "f)", x = 0.71, y = 0.47, gp = gpar(fontsize = 20))


## ---------------------------------------
# First we multiply the likelihood with the prior
plik1 <- function(theta) {
  dbinom(x = 80, size = 100, prob = theta) *
    dbeta(x = theta, shape1 = 4, shape2 = 2)
}
# Then we integrate (compute the area under the curve):
(MargLik1 <- integrate(f = plik1, lower = 0, upper = 1)$value)


## ----OccamFactor, echo=FALSE, fig.height=3, fig.width=5.1825,out.width = "100%", fig.cap="Shown are the schematic probabilities, p(Data), that each of three models assigns to different possible data. The total probability each model assigns to the data is equal to one, i.e., the areas under the curves of all three models are the same. Model 1 (violet) assigns all probability to a narrow range of data, and can predict this data with high probability (low complexity model). Model 3 (red) assigns its probability to a large range of different possible outcomes, but predicts each individual data with low probability (high complexity model). Model 2 (green) takes an intermediate position (intermediate complexity). The vertical dashed line (green) illustrates where the actual empirically observed data fall. The data most support model 2, since this model predicts the data with highest probability. The figure is closely designed after Figure 3.13 in Bishop (2006)."----
knitr::include_graphics("images/OccamFactor.png", dpi = 20)


## ---------------------------------------
plik2 <- function(theta) {
  dbinom(x = 80, size = 100, prob = theta) *
    dbeta(x = theta, shape1 = 1, shape2 = 1)
}
(MargLik2 <- integrate(f = plik2, lower = 0, upper = 1)$value)


## ---------------------------------------
plik3 <- function(a, b) {
  extraDistr::dbbinom(x = 80, size = 100, alpha = a, beta = b) *
    dlnorm(x = a, meanlog = 0, sdlog = 100) *
    dlnorm(x = b, meanlog = 0, sdlog = 100)
}
# Compute marginal likelihood by applying integrate twice
f <- function(b) integrate(function(a) plik3(a, b), lower = 0, upper = Inf)$value
# integrate requires a vectorized function:
(MargLik3 <- integrate(Vectorize(f), lower = 0, upper = Inf)$value)


## **Likelihood ratio vs Bayes Factor.**


## ---------------------------------------
priors1 <- c(
  prior(normal(2, 5), class = Intercept),
  prior(normal(0, 5), class = b),
  prior(normal(10, 5), class = sigma),
  prior(normal(0, 2), class = sd),
  prior(lkj(4), class = cor)
)


## ---- tidy = FALSE, message = FALSE-----
data(df_eeg)
df_eeg <- df_eeg %>% mutate(c_cloze = cloze - mean(cloze))


## ----BFmn400h, message = FALSE, results = "hide", eval = !file.exists("dataR/m_N400_h_linear.RDS")----
fit_N400_h_linear <- brm(n400 ~ c_cloze +
  (c_cloze | subj) + (c_cloze | item),
prior = priors1,
warmup = 2000,
iter = 20000,
cores = 4,
control = list(adapt_delta = 0.9),
save_pars = save_pars(all = TRUE),
data = df_eeg
)


## ---- echo= FALSE-----------------------
if (!file.exists("dataR/m_N400_h_linear.RDS")) {
  saveRDS(fit_N400_h_linear, "dataR/m_N400_h_linear.RDS")
} else {
  fit_N400_h_linear <- readRDS("dataR/m_N400_h_linear.RDS")
}


## ---------------------------------------
fixef(fit_N400_h_linear)


## ---- echo = FALSE----------------------
mf <- fixef(fit_N400_h_linear)["c_cloze", "Estimate"]
cl <- fixef(fit_N400_h_linear)["c_cloze", "Q2.5"]
ch <- fixef(fit_N400_h_linear)["c_cloze", "Q97.5"]


## ---- message = FALSE, results = "hide", eval = !file.exists("dataR/m_N400_h_null.RDS")----
fit_N400_h_null <- brm(n400 ~ 1 +
  (c_cloze | subj) + (c_cloze | item),
prior = priors1[priors1$class != "b", ],
warmup = 2000,
iter = 20000,
cores = 4,
control = list(adapt_delta = 0.9),
save_pars = save_pars(all = TRUE),
data = df_eeg
)

## ---- echo= FALSE-----------------------
if (!file.exists("dataR/m_N400_h_null.RDS")) {
  saveRDS(fit_N400_h_null, "dataR/m_N400_h_null.RDS")
} else {
  fit_N400_h_null <- readRDS("dataR/m_N400_h_null.RDS")
}


## ---- eval = any(!file.exists("dataR/margLogLik_linear.RDS", "dataR/margLogLik_null.RDS"))----
## margLogLik_linear <- bridge_sampler(fit_N400_h_linear, silent = TRUE)
## margLogLik_null <- bridge_sampler(fit_N400_h_null, silent = TRUE)

## ---- echo= FALSE, cache = FALSE--------
if (!file.exists("dataR/margLogLik_linear.RDS")) {
  saveRDS(margLogLik_linear, "dataR/margLogLik_linear.RDS")
} else {
  margLogLik_linear <- readRDS("dataR/margLogLik_linear.RDS")
}
if (!file.exists("dataR/margLogLik_null.RDS")) {
  saveRDS(margLogLik_null, "dataR/margLogLik_null.RDS")
} else {
  margLogLik_null <- readRDS("dataR/margLogLik_null.RDS")
}


## ---------------------------------------
(BF_ln <- bayes_factor(margLogLik_linear, margLogLik_null))


## ---------------------------------------
exp(margLogLik_linear$logml - margLogLik_null$logml)


## ---------------------------------------
priors_vague <- c(
  prior(normal(2, 5), class = Intercept),
  prior(normal(0, 500), class = b),
  prior(normal(10, 5), class = sigma),
  prior(normal(0, 2), class = sd),
  prior(lkj(4), class = cor)
)


## ---- message = FALSE, results = "hide", eval = !file.exists("dataR/m_N400_h_linearVague.RDS")----
fit_N400_h_linear_vague <- brm(n400 ~ c_cloze +
  (c_cloze | subj) + (c_cloze | item),
prior = priors_vague,
warmup = 2000,
iter = 20000,
cores = 4,
control = list(adapt_delta = 0.9),
save_pars = save_pars(all = TRUE),
data = df_eeg
)


## ---- echo= FALSE-----------------------
if (!file.exists("dataR/m_N400_h_linearVague.RDS")) {
  saveRDS(fit_N400_h_linear_vague, "dataR/m_N400_h_linearVague.RDS")
} else {
  fit_N400_h_linear_vague <- readRDS("dataR/m_N400_h_linearVague.RDS")
}


## ---------------------------------------
posterior_summary(fit_N400_h_linear_vague, variable = "b_c_cloze")


## ---- eval = any(!file.exists("dataR/margLogLik_linearVague.RDS", "dataR/margLogLik_nullVague.RDS"))----
## margLogLik_linear_vague <- bridge_sampler(fit_N400_h_linear_vague, silent = TRUE)


## ---- echo= FALSE, cache = FALSE--------
if (!file.exists("dataR/margLogLik_linearVague.RDS")) {
  saveRDS(margLogLik_linear_vague, "dataR/margLogLik_linearVague.RDS")
} else {
  margLogLik_linear_vague <- readRDS("dataR/margLogLik_linearVague.RDS")
}


## ---- eval = TRUE-----------------------
(BF_lnVague <- bayes_factor(margLogLik_linear_vague, margLogLik_null))


## ---------------------------------------
1 / BF_lnVague[[1]]


## ---- results = "hide" , eval = !file.exists("dataR/BFs.RDS")----
## prior_sd <- c(1, 1.5, 2, 2.5, 5, 8, 10, 20, 40, 50, 100)
## BF <- c()
## for (i in 1:length(prior_sd)) {
##   psd <- prior_sd[i]
##   # for each prior we fit the model
##   fit <- brm(n400 ~ c_cloze + (c_cloze | subj) + (c_cloze | item),
##     prior =
##       c(
##         prior(normal(2, 5), class = Intercept),
##         set_prior(paste0("normal(0,", psd, ")"), class = "b"),
##         prior(normal(10, 5), class = sigma),
##         prior(normal(0, 2), class = sd),
##         prior(lkj(4), class = cor)
##       ),
##     warmup = 2000,
##     iter = 20000,
##     cores = 4,
##     control = list(adapt_delta = 0.9),
##     save_pars = save_pars(all = TRUE),
##     data = df_eeg
##   )
##   # for each model we run a brigde sampler
##   lml_linear_beta <- bridge_sampler(fit, silent = TRUE)
##   # we store the Bayes factor compared to the null model
##   BF <- c(BF, bayes_factor(lml_linear_beta, lml_null)$bf)
## }
## BFs <- tibble(beta_sd = prior_sd, BF)

## ---- echo= FALSE-----------------------
if (!file.exists("dataR/BFs.RDS")) {
  saveRDS(BFs, "dataR/BFs.RDS")
} else {
  BFs <- readRDS("dataR/BFs.RDS")
}


## ----BFpriorsX, fig.cap="Prior sensitivity analysis for the Bayes factor", echo=FALSE----
breaks <- c(1 / 100, 1 / 50, 1 / 20, 1 / 10, 1 / 3, 1, 3, 5, 10, 20, 50, 100)
ggplot(BFs, aes(x = beta_sd, y = BF)) +
  geom_point(size = 2) +
  geom_line() +
  geom_hline(yintercept = 1, linetype = "dashed") +
  scale_x_continuous("Normal prior width (SD)\n") +
  scale_y_log10("BF10", breaks = breaks, labels = MASS::fractions(breaks)) +
  coord_cartesian(ylim = c(1 / 100, 100)) +
  annotate("text", x = 30 * 2, y = 30, label = "Evidence in favor of one H1", size = 5) +
  annotate("text", x = 30 * 2, y = 1 / 30, label = "Evidence in favor of H0", size = 5) +
  theme(axis.text.y = element_text(size = 8)) +
  ggtitle("Bayes factors")


## **Bayesian interpretation of additive smoothing**


## ---------------------------------------
df_eeg <- df_eeg %>%
  mutate(
    scloze = (cloze_ans + 1) / (N + 2),
    c_logscloze = log(scloze) - mean(log(scloze))
  )


## ---------------------------------------
df_eeg <- df_eeg %>%
  mutate(c_logscloze = scale(c_logscloze) * sd(c_cloze))


## ---- message = FALSE, results = "hide", eval = !file.exists("dataR/m_N400_h_log.RDS")----
fit_N400_h_log <- brm(n400 ~ c_logscloze +
  (c_logscloze | subj) + (c_logscloze | item),
prior = priors1,
warmup = 2000,
iter = 20000,
cores = 4,
control = list(adapt_delta = 0.9),
save_pars = save_pars(all = TRUE),
data = df_eeg
)

## ---- echo= FALSE-----------------------
if (!file.exists("dataR/m_N400_h_log.RDS")) {
  saveRDS(fit_N400_h_log, "dataR/m_N400_h_log.RDS")
} else {
  fit_N400_h_log <- readRDS("dataR/m_N400_h_log.RDS")
}


## ---- eval = any(!file.exists("dataR/margLogLik_log.RDS"))----
## margLogLik_log <- bridge_sampler(fit_N400_h_log, silent = TRUE)

## ---- echo= FALSE-----------------------
if (!file.exists("dataR/margLogLik_log.RDS")) {
  saveRDS(margLogLik_log, "dataR/margLogLik_log.RDS")
} else {
  margLogLik_log <- readRDS("dataR/margLogLik_log.RDS")
}


## ---------------------------------------
(BF_log_lin <- bayes_factor(margLogLik_log, margLogLik_linear))


## ---------------------------------------
data("df_BF")
str(df_BF)


## ----cTabXMeans, echo=FALSE, message=FALSE, results = "asis"----
tableBF <- df_BF %>%
  group_by(F) %>%
  summarize(N = length(pDV), M = mean(pDV)) %>%
  as.data.frame()
names(tableBF) <- c("Factor A", "N data", "Means")
apa_table(tableBF,
  placement = "b", digits = 2,
  caption = "Summary statistics per condition for the simulated data."
)


## ---- echo=TRUE-------------------------
contrasts(df_BF$F) <- c(-0.5, +0.5)


## ---- echo=TRUE, message=FALSE, results="hide"----
# set prior
priors_logit1 <- c(
  prior(normal(0, 0.1), class = Intercept),
  prior(normal(0, 0.5), class = b)
)
# Bayesian GLM: H0
fit_pDV_H0 <- brm(pDV ~ 1,
  data = df_BF,
  family = bernoulli(link = "logit"),
  prior = priors_logit1[-2, ],
  save_pars = save_pars(all = TRUE)
)
# Bayesian GLM: H1
fit_pDV_H1 <- brm(pDV ~ 1 + F,
  data = df_BF,
  family = bernoulli(link = "logit"),
  prior = priors_logit1,
  save_pars = save_pars(all = TRUE)
)
# Bridge sampling
mLL_binom_H0 <- bridge_sampler(fit_pDV_H0, silent = TRUE)
mLL_binom_H1 <- bridge_sampler(fit_pDV_H1, silent = TRUE)


## ---- echo=TRUE, message=FALSE, results="hide"----
priors_logit2 <- c(
  prior(normal(2, 0.1), class = Intercept),
  prior(normal(0, 0.5), class = b)
)
# Bayesian GLM: H0
fit_pDV_H0_2 <- brm(pDV ~ 1,
  data = df_BF,
  family = bernoulli(link = "logit"),
  prior = priors_logit2[-2, ],
  save_pars = save_pars(all = TRUE)
)
# Bayesian GLM: H1
fit_pDV_H1_2 <- brm(pDV ~ 1 + F,
  data = df_BF,
  family = bernoulli(link = "logit"),
  prior = priors_logit2,
  save_pars = save_pars(all = TRUE)
)
# Bridge sampling
mLL_binom_H0_2 <- bridge_sampler(fit_pDV_H0_2, silent = TRUE)
mLL_binom_H1_2 <- bridge_sampler(fit_pDV_H1_2, silent = TRUE)


## ---- echo=TRUE-------------------------
(BF_binom_H1_H0 <- bayes_factor(mLL_binom_H1, mLL_binom_H0))
(BF_binom_H1_H0_2 <- bayes_factor(mLL_binom_H1_2, mLL_binom_H0_2))


## ----pupilposstan, echo = FALSE---------
pupil_pos <- system.file("stan_models", "pupil_pos.stan", package = "bcogsci")


## NA

## ---- message = FALSE-------------------
data("df_pupil")
df_pupil <- df_pupil %>%
  mutate(c_load = load - mean(load),
         c_trial = trial - mean(trial))
ls_pupil <- list(
  p_size = df_pupil$p_size,
  c_load = df_pupil$c_load,
  c_trial = df_pupil$c_trial,
  N = nrow(df_pupil)
)
pupil_pos <- system.file("stan_models", "pupil_pos.stan", package = "bcogsci")
fit_pupil_int_pos <- stan(
  file = pupil_pos,
  data = ls_pupil,
  warmup = 1000,
  iter = 20000,
  control = list(adapt_delta = .95)
)


## ----pupilnullstan, echo = FALSE--------
pupil_null <- system.file("stan_models", "pupil_null.stan", package = "bcogsci")


## NA

## ---- message = FALSE-------------------
pupil_null <- system.file("stan_models", "pupil_null.stan", package = "bcogsci")
fit_pupil_int_null <- stan(
  file = pupil_null,
  data = ls_pupil,
  warmup = 1000,
  iter = 20000
)


## ----BFpupil , eval = !file.exists("dataR/BF_att.RDS")----
lml_pupil <- bridge_sampler(fit_pupil_int_pos, silent = TRUE)
lml_pupil_null <- bridge_sampler(fit_pupil_int_null, silent = TRUE)
BF_att <- bridgesampling::bf(lml_pupil, lml_pupil_null)


## ----echo = FALSE-----------------------
if (!file.exists("dataR/BF_att.RDS")) {
  saveRDS(BF_att, "dataR/BF_att.RDS")
} else {
  BF_att <- readRDS("dataR/BF_att.RDS")
}


## ---------------------------------------
BF_att


## ---- echo=FALSE, message=FALSE, results = "hide", eval = !file.exists("dataR/m_N400_h_null2.RDS")----
## m_N400_h_null2 <- brm(n400 ~ 1 + (ccloze | subject) + (ccloze | item),
##   prior = priors1[-2, ],
##   # default settings
##   # warmup  = 1000,
##   # iter    = 2000,
##   cores = 4,
##   control = list(adapt_delta = 0.9),
##   save_pars = save_pars(all = TRUE),
##   data = eeg_data
## )
## lml_null2 <- bridge_sampler(m_N400_h_null2, silent = TRUE)

## ---- echo= FALSE-----------------------
if (!file.exists("dataR/m_N400_h_null2.RDS")) {
  saveRDS(m_N400_h_null2, "dataR/m_N400_h_null2.RDS")
} else {
  m_N400_h_null2 <- readRDS("dataR/m_N400_h_null2.RDS")
}
if (!file.exists("dataR/lml_null2.RDS")) {
  saveRDS(lml_null2, "dataR/lml_null2.RDS")
} else {
  lml_null2 <- readRDS("dataR/lml_null2.RDS")
}


## ---- echo=FALSE, message = FALSE, results = "hide" , eval = !file.exists("dataR/BFs2.RDS")----
## prior_sd <- c(1, 1.5, 2, 2.5, 5, 8, 10, 20, 40, 50, 100)
## BFs2 <- map_dfr(prior_sd, function(psd) {
##   gc()
##   # for each prior we fit the model
##   fit <- brm(n400 ~ ccloze + (ccloze | subject) + (ccloze | item),
##     prior =
##       c(
##         prior(normal(2, 5), class = Intercept),
##         set_prior(paste0("normal(0,", psd, ")"), class = "b"),
##         prior(normal(10, 5), class = sigma),
##         prior(normal(0, 2), class = sd),
##         prior(lkj(4), class = cor)
##       ),
##     # default settings
##     # warmup  = 1000,
##     # iter    = 2000,
##     cores = 4,
##     control = list(adapt_delta = 0.9),
##     save_pars = save_pars(all = TRUE),
##     data = eeg_data
##   )
##   # for each model we run a brigde sampler
##   lml_linear_beta <- bridge_sampler(fit, silent = TRUE)
##   # we store the Bayes factor compared to the null model
##   tibble(beta_sd = psd, BF = bayes_factor(lml_linear_beta, lml_null2)$bf)
## })

## ---- results = "hide", echo=FALSE , eval = !file.exists("dataR/BFs3.RDS"), echo=FALSE----
## prior_sd <- c(1, 1.5, 2, 2.5, 5, 8, 10, 20, 40, 50, 100)
## BFs3 <- map_dfr(prior_sd, function(psd) {
##   gc()
##   # for each prior we fit the model
##   fit <- brm(n400 ~ ccloze + (ccloze | subject) + (ccloze | item),
##     prior =
##       c(
##         prior(normal(2, 5), class = Intercept),
##         set_prior(paste0("normal(0,", psd, ")"), class = "b"),
##         prior(normal(10, 5), class = sigma),
##         prior(normal(0, 2), class = sd),
##         prior(lkj(4), class = cor)
##       ),
##     # default settings
##     # warmup  = 1000,
##     # iter    = 2000,
##     cores = 4,
##     control = list(adapt_delta = 0.9),
##     save_pars = save_pars(all = TRUE),
##     data = eeg_data
##   )
##   # for each model we run a brigde sampler
##   lml_linear_beta <- bridge_sampler(fit, silent = TRUE)
##   # we store the Bayes factor compared to the null model
##   tibble(beta_sd = psd, BF = bayes_factor(lml_linear_beta, lml_null2)$bf)
## })

## ---- echo= FALSE-----------------------
if (!file.exists("dataR/BFs2.RDS")) {
  saveRDS(BFs2, "dataR/BFs2.RDS")
} else {
  BFs2 <- readRDS("dataR/BFs2.RDS")
}
if (!file.exists("dataR/BFs3.RDS")) {
  saveRDS(BFs3, "dataR/BFs3.RDS")
} else {
  BFs3 <- readRDS("dataR/BFs3.RDS")
}

## ---- echo=FALSE, results = "hide" , eval = !file.exists("dataR/BFs1.RDS")----
## prior_sd <- c(1, 1.5, 2, 2.5, 5, 8, 10, 20, 40, 50, 100)
## BFs1 <- map_dfr(prior_sd, function(psd) {
##   gc()
##   # for each prior we fit the model
##   fit <- brm(n400 ~ ccloze + (ccloze | subject) + (ccloze | item),
##     prior =
##       c(
##         prior(normal(2, 5), class = Intercept),
##         set_prior(paste0("normal(0,", psd, ")"), class = "b"),
##         prior(normal(10, 5), class = sigma),
##         prior(normal(0, 2), class = sd),
##         prior(lkj(4), class = cor)
##       ),
##     warmup = 2000,
##     iter = 20000,
##     cores = 4,
##     control = list(adapt_delta = 0.9),
##     save_pars = save_pars(all = TRUE),
##     data = eeg_data
##   )
##   # for each model we run a brigde sampler
##   lml_linear_beta <- bridge_sampler(fit, silent = TRUE)
##   # we store the Bayes factor compared to the null model
##   tibble(beta_sd = psd, BF = bayes_factor(lml_linear_beta, margLogLik_null)$bf)
## })

## ---- echo= FALSE-----------------------
if (!file.exists("dataR/BFs1.RDS")) {
  saveRDS(BFs1, "dataR/BFs1.RDS")
} else {
  BFs1 <- readRDS("dataR/BFs1.RDS")
}


## ---- echo=FALSE, results = "hide", echo=FALSE , eval = !file.exists("dataR/BFsX.RDS")----
## prior_sd <- c(1, 1.5, 2, 2.5, 5, 8, 10, 20, 40, 50, 100)
## BFsX <- data.frame()
## for (i in 1:20) {
##   BFsXX <- map_dfr(prior_sd, function(psd) {
##     gc()
##     # for each prior we fit the model
##     fit <- brm(n400 ~ ccloze + (ccloze | subject) + (ccloze | item),
##       prior =
##         c(
##           prior(normal(2, 5), class = Intercept),
##           set_prior(paste0("normal(0,", psd, ")"), class = "b"),
##           prior(normal(10, 5), class = sigma),
##           prior(normal(0, 2), class = sd),
##           prior(lkj(4), class = cor)
##         ),
##       # default settings
##       # warmup  = 1000,
##       # iter    = 2000,
##       cores = 4,
##       control = list(adapt_delta = 0.9),
##       save_pars = save_pars(all = TRUE),
##       data = eeg_data
##     )
##     # for each model we run a brigde sampler
##     lml_linear_beta <- bridge_sampler(fit, silent = TRUE)
##     # we store the Bayes factor compared to the null model
##     tibble(beta_sd = psd, BF = bayes_factor(lml_linear_beta, lml_null2)$bf)
##   })
##   BFsXX$iter <- i
##   BFsX <- rbind(BFsX, BFsXX)
## }

## ---- echo= FALSE-----------------------
if (!file.exists("dataR/BFsX.RDS")) {
  saveRDS(BFsX, "dataR/BFsX.RDS")
} else {
  BFsX <- readRDS("dataR/BFsX.RDS")
}


## ----BFpriors2, echo=FALSE, message=FALSE, fig.cap="Effect of the number of samples on a prior sensitivity analysis for the Bayes factor. Grey lines show 20 runs with default number of iterations (2000).", fig.height=6, fig.width=7----

BFs12 <- rbind(
  cbind(BFs, iter = "Many iterations (20000); run 1"),
  cbind(BFs1, iter = "Many iterations (20000); run 2"),
  cbind(BFs2, iter = "Default iterations (2000); run 1"),
  cbind(BFs3, iter = "Default iterations (2000); run 2")
)
BFs12$iter <- factor(BFs12$iter)
tmpYY <- (as.numeric(BFs12$iter) / 2) %% 1
BFs12$beta_SD <- BFs12$beta_sd + tmpYY - 0.25
breaks <- c(1 / 1000, 1 / 500, 1 / 200, 1 / 100, 1 / 50, 1 / 20, 1 / 10, 1 / 3, 1, 3, 5, 10, 20, 50, 100, 200, 500, 1000)
if (FALSE) {
  ggplot(BFs12, aes(x = beta_SD, y = BF, shape = iter, linetype = iter)) +
    geom_point(size = 2) +
    geom_line() +
    geom_hline(yintercept = 1, linetype = "dashed") +
    scale_x_continuous("Normal prior width (SD)\n") +
    scale_y_log10("BF10", breaks = breaks, labels = MASS::fractions(breaks)) +
    scale_shape_discrete(name = "") +
    scale_linetype_discrete(name = "") +
    coord_cartesian(ylim = c(1 / 1000, 1000)) +
    annotate("text", x = 38 * 2, y = 200, label = "Evidence in favor of H1", size = 5) +
    annotate("text", x = 38 * 2, y = 1 / 200, label = "Evidence in favor of H0", size = 5) +
    theme(
      axis.text.y = element_text(size = 8),
      legend.position = c(0.25, 0.25),
      legend.background = element_blank()
    ) +
    ggtitle("Bayes factors")
}

ggplot() +
  geom_line(data = BFsX, aes(x = beta_sd, y = BF, group = iter), colour = "grey") +
  geom_point(data = BFs12, aes(x = beta_SD, y = BF, shape = iter, linetype = iter), size = 2) +
  geom_line(data = BFs12, aes(x = beta_SD, y = BF, shape = iter, linetype = iter)) +
  geom_hline(yintercept = 1, linetype = "dashed") +
  scale_x_continuous("Normal prior width (SD)\n") +
  scale_y_log10("BF10", breaks = breaks, labels = MASS::fractions(breaks)) +
  scale_shape_discrete(name = "") +
  scale_linetype_discrete(name = "") +
  coord_cartesian(ylim = c(1 / 1000, 1000)) +
  annotate("text", x = 38 * 2, y = 200, label = "Evidence in favor of H1", size = 5) +
  annotate("text", x = 38 * 2, y = 1 / 200, label = "Evidence in favor of H0", size = 5) +
  theme(
    axis.text.y = element_text(size = 8),
    legend.position = c(0.25, 0.25),
    legend.background = element_blank()
  ) +
  ggtitle("Bayes factors")


## ---- echo=FALSE------------------------
#----------------------------------------
# load data and functions
#----------------------------------------
load("data/DataAll1.rda")
# name <- "wagersE4"
name <- "lagoE1"
# unique(dat$expt)
fakedata <- subset(dat, expt == name)
fakedata$subj <- factor(fakedata$subj)
fakedata$item <- factor(fakedata$item)
Nsj <- length(unique(fakedata$subj))
Nit <- length(unique(fakedata$item))
fakedata$subj <- as.numeric(fakedata$subj)
fakedata$item <- as.numeric(fakedata$item)


## ---- echo=FALSE------------------------
nsim <- 500
priorsHypothesis <- matrix(NA, nrow = nsim, ncol = 2)
priorsHypothesis[, 1] <- seq(0, 1, length = nsim)
priorsHypothesis[, 2] <- 1 - priorsHypothesis[, 1]


## ---- echo=FALSE------------------------
priorsLagoPost <- c(
  # fixed effects
  set_prior("normal( 6.02  ,0.0570 )", class = "Intercept"),
  set_prior("normal(-0.0284,0.00754)", class = "b"),
  # SD parameters items
  set_prior("normal(0.04,0.02)", class = "sd", coef = "Intercept", group = "item"),
  set_prior("normal(0.02,0.01)", class = "sd", coef = "x", group = "item"),
  # SD parameters subjects
  set_prior("normal(0.31,0.04)", class = "sd", coef = "Intercept", group = "subj"),
  set_prior("normal(0.03,0.02)", class = "sd", coef = "x", group = "subj"),
  # residual variance + correlation
  set_prior("normal(0.41,0.01)", class = "sigma"),
  set_prior("lkj(2)", class = "cor")
)


## ---- echo=FALSE, eval=!file.exists("dataR/SBC_BF_lagoE1x_hypSamp.RDS")----
## u <- runif(nsim)
## hypothesis_samples <- (u > priorsHypothesis[, 1]) / apply(priorsHypothesis, 1, sum)

## ---- echo=FALSE------------------------
if (!file.exists("dataR/SBC_BF_lagoE1x_hypSamp.RDS")) {
  saveRDS(hypothesis_samples, "dataR/SBC_BF_lagoE1x_hypSamp.RDS")
} else {
  hypothesis_samples <- readRDS("dataR/SBC_BF_lagoE1x_hypSamp.RDS")
}


## ---- echo=FALSE, eval=!file.exists("dataR/SBC_BF_lagoE1x_parSamp.RDS")----
## beta0 <- beta1 <- sigma_u0 <- sigma_u1 <- sigma_w0 <-
##   sigma_w1 <- rho_u <- rho_w <- sigma <- NA
## rtfakemat <- matrix(NA, nrow(fakedata), nsim)
## set.seed(123)
## source("functions/SimFromPrior.R")
## for (i in 1:nsim) { # i <- 1
##   tmp <- -1
##   while (tmp < 0) {
##     tmp <- SimFromPrior(priorsLagoPost, class = "Intercept", coef = "")
##   }
##   beta0[i] <- tmp
##   beta1[i] <- SimFromPrior(priorsLagoPost, class = "b")
##   sigma_u0[i] <- rnorm(1, 0.31, 0.04) # subjects
##   sigma_u1[i] <- rnorm(1, 0.03, 0.02)
##   sigma_w0[i] <- rnorm(1, 0.04, 0.02) # items
##   sigma_w1[i] <- rnorm(1, 0.02, 0.01)
##   rho_u[i] <- SimFromPrior(priorsLagoPost, class = "cor") # subjects
##   rho_w[i] <- SimFromPrior(priorsLagoPost, class = "cor") # items
##   sigma[i] <- SimFromPrior(priorsLagoPost, class = "sigma")
## }


## ---- echo=FALSE, eval=!file.exists("dataR/SBC_BF_lagoE1x_parSamp.RDS")----
## beta1[hypothesis_samples == 0] <- 0

## ---- echo=FALSE------------------------
if (!file.exists("dataR/SBC_BF_lagoE1x_parSamp.RDS")) {
  trueParameters <- data.frame(beta0, beta1, sigma_u0, sigma_u1, sigma_w0, sigma_w1, rho_u, rho_w, sigma)
  saveRDS(trueParameters, "dataR/SBC_BF_lagoE1x_parSamp.RDS")
} else {
  trueParameters <- readRDS("dataR/SBC_BF_lagoE1x_parSamp.RDS")
}

beta0 <- trueParameters$beta0
beta1 <- trueParameters$beta1
sigma_u0 <- trueParameters$sigma_u0
sigma_u1 <- trueParameters$sigma_u1
sigma_w0 <- trueParameters$sigma_w0
sigma_w1 <- trueParameters$sigma_w1
rho_u <- trueParameters$rho_u
rho_w <- trueParameters$rho_w
sigma <- trueParameters$sigma


## ---- echo=FALSE, eval=!file.exists("dataR/SBC_BF_lagoE1x_fakeDat.RDS")----
## source("functions/genfake.R")
## for (i in 1:nsim) {
##   rtfakemat[, i] <- genfake(fakedata, Nsj, Nit,
##     beta0 = beta0[i],
##     beta1 = beta1[i],
##     sigma_u0 = sigma_u0[i], # subjects
##     sigma_u1 = sigma_u1[i],
##     sigma_w0 = sigma_w0[i], # items
##     sigma_w1 = sigma_w1[i],
##     rho_u = rho_u[i],
##     rho_w = rho_w[i],
##     sigma = sigma[i]
##   )
## }

## ---- echo=FALSE------------------------
if (!file.exists("dataR/SBC_BF_lagoE1x_fakeDat.RDS")) {
  saveRDS(rtfakemat, "dataR/SBC_BF_lagoE1x_fakeDat.RDS")
} else {
  rtfakemat <- readRDS("dataR/SBC_BF_lagoE1x_fakeDat.RDS")
}


## ----SBCBF3, echo=FALSE, eval=!file.exists("dataR/SBC_BF_lagoE1x.RDS")----
## BF10_SBC <- c()
## FIX.EF <- data.frame()
## for (i in 1:nsim) {
##   fakedata$fakert <- rtfakemat[, i]
##   # estimate model for alternative hypothesis
##   brm1 <- brm(fakert ~ x + (1 + x | subj) + (1 + x | item), fakedata,
##     family = lognormal(), prior = priorsLagoPost, cores = 4,
##     save_pars = save_pars(all = TRUE),
##     warmup = 2000, iter = 10000,
##     control = list(adapt_delta = 0.99, max_treedepth = 15)
##   )
##   lml_Full <- bridge_sampler(brm1, silent = TRUE)
##   rm(brm1)
##   # estimate model for null hypothesis
##   brm0 <- brm(fakert ~ 1 + (1 + x | subj) + (1 + x | item), fakedata,
##     family = lognormal(), prior = priorsLagoPost[-2, ], cores = 4,
##     save_pars = save_pars(all = TRUE),
##     warmup = 2000, iter = 10000,
##     control = list(adapt_delta = 0.99, max_treedepth = 15)
##   )
##   lml_Null <- bridge_sampler(brm0, silent = TRUE)
##   rm(brm0)
##   BF10_SBC <- c(BF10_SBC, bayes_factor(lml_Full, lml_Null)$bf)
## }

## ---- echo=FALSE------------------------
if (!file.exists("dataR/SBC_BF_lagoE1x.RDS")) {
  saveRDS(BF10_SBC, "dataR/SBC_BF_lagoE1x.RDS")
} else {
  BF10_SBC <- readRDS("dataR/SBC_BF_lagoE1x.RDS")
}


## ---- echo=FALSE------------------------
postModelRat <- BF10_SBC * priorsHypothesis[, 2] / priorsHypothesis[, 1]


## ---- echo=FALSE------------------------
postModelProbsH1 <- postModelRat / (postModelRat + 1)
postModelProbsH0 <- 1 / (postModelRat + 1)


## ----SBC3plot, fig=TRUE, include=TRUE, echo=FALSE, cache=FALSE, fig.width=6, fig.height=5, fig.cap = "Posterior probabilities for the H0 are plotted as a function of prior probabilities for the H0. If the approximation of the Bayes factor using bridge sampling is unbiased, then the data should be aligned along the diagonal (see dashed black line). The thick black line is a prediction from a local regression analysis. The points are average posterior probabilities as a function of a priori selected hypotheses for 50 simulation runs each. Errorbars represent 95 percent confidence intervals.", message=FALSE----
prob <- data.frame(
  postH0 = postModelProbsH0 * 100,
  priH0 = priorsHypothesis[, 1] * 100,
  priH0s = (1 - hypothesis_samples) * 100,
  sim = 1:nsim
)
prob$simC <- (floor((prob$sim - 1) / nsim * 10) + 0.5) * (nsim / 10)
# table(prob$simC)
probP <- prob %>%
  group_by(simC) %>%
  summarize(
    postM = mean(postH0), postSE = sd(postH0) / sqrt(n()),
    postCI = sd(postH0) / sqrt(n()) * qt(0.975, n()),
    priM = mean(priH0s), priSE = sd(priH0s) / sqrt(n()),
    priCI = sd(priH0s) / sqrt(n()) * qt(0.975, n())
  )
ggplot() +
  geom_abline(intercept = 0, slope = 1, linetype = 2) +
  geom_smooth(data = prob, aes(x = priH0, y = postH0), colour = "black") +
  geom_point(data = probP, aes(x = priM, y = postM)) +
  geom_errorbar(
    data = probP,
    aes(x = priM, ymin = postM - postCI, ymax = postM + postCI), colour = "black"
  ) +
  geom_errorbarh(
    data = probP,
    aes(y = postM, xmin = priM - priCI, xmax = priM + priCI), colour = "black"
  ) +
  xlab("Prior probability for the H0") +
  ylab("Posterior probability for the H0") +
  theme_bw() +
  theme(aspect.ratio = 1 / 1)


## ----LoadPrepData, echo=FALSE-----------

## Lago et al 2015 data (all expts):
Lago <- read.csv("data/Lago.csv", header = T)

## Lago:
dat <- Lago
## critical region: not used because published paper found
## significant effects in postcrit region only
e1 <- subset(dat, Experiment == "Experiment1" & Region == "06v1")
e2 <- subset(dat, Experiment == "Experiment2" & Region == "06aux")
e3a <- subset(dat, Experiment == "Experiment3A" & Region == "06aux")
e3b <- subset(dat, Experiment == "Experiment3B" & Region == "aux")

nsubj_lagoe1 <- length(unique(e1$Subject))
nsubj_lagoe2 <- length(unique(e2$Subject))
nsubj_lagoe3a <- length(unique(e3a$Subject))
nsubj_lagoe3b <- length(unique(e3b$Subject))


## postcritical region:
poste1 <- subset(dat, Experiment == "Experiment1" & Region == "07prep")

## e1: a,b
#-(a) Ungram , singular attractor (interference condition)
# La *nota* que la chica escribieron en la clase alegró a su amiga
# The note that the girl wrotepl during class cheered her friend up
#-(b) Ungram , plural attractor (baseline condition)
# Las *notas* que la chica escribieron en la clase alegraron a su amiga
# The notes that the girl wrotepl during class cheered her friend up
poste1 <- subset(poste1, Condition %in% c("a", "b"))
poste1$Condition <- factor(poste1$Condition)
# poste1$x<-ifelse(poste1$Condition=="a",-1,1)
poste1$x <- ifelse(poste1$Condition == "a", -1, 1)
poste1$int <- ifelse(poste1$Condition == "a", "low", "high")
poste1 <- poste1[, c(1, 3, 8, 15, 14)]
poste1$expt <- factor("lagoE1")
lagoE1 <- poste1
colnames(lagoE1) <- c("subj", "item", "rt", "int", "x", "expt")


## ----SetPriors--------------------------
priors <- c(
  prior(normal(6, 0.5), class = Intercept),
  prior(normal(-0.03, 0.009), class = b),
  prior(normal(0, 0.5), class = sd),
  prior(normal(0, 1), class = sigma),
  prior(lkj(2), class = cor)
)


## ----RunModel1a, message=FALSE, echo=FALSE, results="hide", eval = any(!file.exists("dataR/lagoE1_m1.RDS", "dataR/lagoE1_h.RDS"))----
## 
## # run alternative model
## m1_lagoE1 <- brm(rt ~ 1 + x + (1 + x | subj) + (1 + x | item),
##   data = lagoE1,
##   family = lognormal(),
##   prior = priors,
##   warmup = 2000,
##   iter = 10000,
##   cores = 4,
##   save_pars = save_pars(all = TRUE),
##   control = list(
##     adapt_delta = 0.99,
##     max_treedepth = 15
##   )
## )
## # run null model
## m0_lagoE1 <- brm(rt ~ 1 + (1 + x | subj) + (1 + x | item),
##   data = lagoE1,
##   family = lognormal(),
##   prior = priors[-2, ],
##   warmup = 2000,
##   iter = 10000,
##   cores = 4,
##   save_pars = save_pars(all = TRUE),
##   control = list(
##     adapt_delta = 0.99,
##     max_treedepth = 15
##   )
## )
## # run bridge sampler
## lml_m1_lagoE1 <- bridge_sampler(m1_lagoE1, silent = TRUE)
## lml_m0_lagoE1 <- bridge_sampler(m0_lagoE1, silent = TRUE)
## # compute Bayes factor
## h_lagoE1 <- bayes_factor(lml_m1_lagoE1, lml_m0_lagoE1)


## ---- echo= FALSE-----------------------
if (!file.exists("dataR/lagoE1_m1.RDS")) {
  saveRDS(m1_lagoE1, "dataR/lagoE1_m1.RDS")
} else {
  m1_lagoE1 <- readRDS("dataR/lagoE1_m1.RDS")
}
if (!file.exists("dataR/lagoE1_h.RDS")) {
  saveRDS(h_lagoE1, "dataR/lagoE1_h.RDS")
} else {
  h_lagoE1 <- readRDS("dataR/lagoE1_h.RDS")
}


## ---------------------------------------
round(fixef(m1_lagoE1), 3)


## ---------------------------------------
h_lagoE1$bf


## ----PostPred, echo=TRUE, eval = !file.exists("dataR/m1_lageoE1_postPred.RDS")----
pred_lagoE1 <- posterior_predict(m1_lagoE1)

## ---- echo=FALSE------------------------
if (!file.exists("dataR/m1_lageoE1_postPred.RDS")) {
  saveRDS(pred_lagoE1, "dataR/m1_lageoE1_postPred.RDS")
} else {
  pred_lagoE1 <- readRDS("dataR/m1_lageoE1_postPred.RDS")
}


## ---- echo=FALSE------------------------
priors <- c(
  set_prior("normal(6, 0.5)", class = "Intercept"),
  set_prior("normal(-0.03, 0.009)", class = "b"),
  set_prior("normal(0, 0.5)", class = "sd"),
  set_prior("normal(0, 1)", class = "sigma"),
  set_prior("lkj(2)", class = "cor")
)


## ----runModelsBridge, message=FALSE, echo=FALSE, eval = !file.exists("dataR/LagoE1_PosPredModels.RDS")----
## 
## nsim <- 50 # 100
## m1_lagoE1_list <- h_lagoE1_list <- list()
## BF10_lagoE1 <- c()
## datT <- data.frame()
## FIX.EF <- as.data.frame(matrix(NA, nrow = nsim, ncol = 4))
## for (i in 1:nsim) {
##   print(i)
##   datTmp$rt <- pred_lagoE1[i, ]
##   m1_lagoE1_list <- brm(rt ~ 1 + x + (1 + x | subj) + (1 + x | item),
##     data = datTmp,
##     family = lognormal(),
##     prior = priors,
##     warmup = 2000,
##     iter = 10000,
##     cores = 4,
##     save_pars = save_pars(all = TRUE),
##     # sample_prior = TRUE,
##     control = list(
##       adapt_delta = 0.99,
##       max_treedepth = 15
##     )
##   )
##   m1_lagoE1_null <- brm(rt ~ 1 + (1 + x | subj) + (1 + x | item),
##     data = datTmp,
##     family = lognormal(),
##     prior = priors[-2, ],
##     warmup = 2000,
##     iter = 10000,
##     cores = 4,
##     save_pars = save_pars(all = TRUE),
##     # sample_prior = TRUE,
##     control = list(
##       adapt_delta = 0.99,
##       max_treedepth = 15
##     )
##   )
##   lml_Full <- bridge_sampler(m1_lagoE1_list, silent = TRUE)
##   lml_Null <- bridge_sampler(m1_lagoE1_null, silent = TRUE)
##   BF10_lagoE1[i] <- bayes_factor(lml_Full, lml_Null)$bf
## 
##   FIX.EF[i, ] <- fixef(m1_lagoE1_list)[2, ]
## 
##   mTmp <- plyr::ddply(datTmp, "x", summarize, RT = mean(rt))$RT
##   datT <- rbind(datT, c(i, mTmp))
## }
## 
## names(FIX.EF) <- c("Estimate", "Est.Error", "Q2.5", "Q97.5")
## FIX.EF$Study <- 1:50
## 
## names(datT) <- c("simNr", "x1", "xm1")
## datT$dif <- datT$x1 - datT$xm1
## datT$BF10 <- BF10_lagoE1
## 
## datT <- cbind(datT, FIX.EF)
## # saveRDS(datT,"dataR/LagoE1_PosPredModels.RDS")

## ---- echo= FALSE-----------------------
if (!file.exists("dataR/LagoE1_PosPredModels.RDS")) {
  saveRDS(datT, "dataR/LagoE1_PosPredModels.RDS")
} else {
  datT <- readRDS("dataR/LagoE1_PosPredModels.RDS")
}


## ----plotBFdistrn, echo=FALSE, message=FALSE, fig.width=4*2.5, fig.height=4, fig.cap="Left panel: Histogram of Bayes factors (BF10) of the alternative model over the null model in 50 simulated data sets. The vertical solid black line shows equal evidence for both hypotheses; the dashed red line shows the Bayes factor computed from the empirical data; the horizontal error bar shows 95 percent of all Bayes factors. Right panel: Estimates of the facilitatory effect of retrieval interference and 95 percent credible intervals across all simulations (solid lines) and the empirically observed data (dashed line)."----

datT$logBF10 <- log10(datT$BF10)
qtBF <- quantile(datT$logBF10, c(0.025, 0.975))
breaks <- c(1 / 10, 1 / 3, 1, 3, 10)
p1 <- ggplot() +
  stat_bin(data = datT, aes(x = logBF10), geom = "bar") +
  geom_vline(xintercept = log10(h_lagoE1$bf), lty = 2, colour = "black") +
  geom_vline(xintercept = 0) +
  geom_errorbarh(aes(y = +0.5, xmin = qtBF[1], xmax = qtBF[2]), size = 1, height = 0.3) +
  scale_x_continuous(
    breaks = log10(breaks),
    labels = MASS::fractions(breaks)
  ) +
  scale_y_continuous(breaks = seq(0, 10, 2)) +
  labs(x = "BF10")
# gridExtra::grid.arrange(p1, p2, layout_matrix=lay)

datTp <- datT[, c("Study", "Estimate", "Q2.5", "Q97.5")]
datTp <- rbind(c(0, fixef(m1_lagoE1)[2, c("Estimate", "Q2.5", "Q97.5")]), datTp)
datTp$data <- ifelse(datTp$Study == 0, "Empirical data", "Simulated data")
idx <- order(datTp$Estimate)
datTp <- datTp[idx, ]
datTp$Study <- 1:nrow(datTp)

p2 <- ggplot(
  data = datTp,
  aes(x = Study, y = Estimate, colour = data, linetype = data)
) +
  geom_hline(yintercept = 0) +
  geom_point() +
  geom_errorbar(aes(ymin = Q2.5, ymax = Q97.5)) +
  scale_colour_manual(name = "", values = c("black", "black")) +
  scale_linetype_manual(name = "", values = c(2, 1)) +
  labs(y = "Estimate [95% CreInt]", x = "Simulated Study") +
  theme_bw()

# quartz(width=4*2.5, height=4)
lay <- rbind(c(1, 2, 2))
gridExtra::grid.arrange(p1, p2, layout_matrix = lay)


## ----BFregression, echo=FALSE, message=FALSE, fig.width=6, fig.heigth=4, fig.cap="Bayes factor (BF10) as a function of the estimate (with 95 percent credible intervals) of the facilitatory effect of retrieval interference across 50 simulated data sets. The prior is from a meta analysis."----

breaks <- c(1 / 10, 1 / 3, 1, 3, 10)
p1 <- ggplot(data = datT, aes(y = logBF10, x = Estimate)) +
  geom_point() +
  geom_smooth() +
  scale_y_continuous(
    breaks = log10(breaks),
    labels = MASS::fractions(breaks)
  ) +
  labs(x = "Difference in reading times [ms]", y = "BF10") +
  theme_bw()

breaks <- c(1 / 10, 1 / 3, 1, 3, 10)
ggplot(data = datT, aes(y = logBF10, x = Estimate)) +
  geom_errorbarh(aes(xmin = Q2.5, xmax = Q97.5), colour = "grey60") +
  geom_point() +
  geom_smooth() +
  scale_y_continuous(
    breaks = log10(breaks),
    labels = MASS::fractions(breaks)
  ) +
  labs(x = "Effect estimate [95% CreIv]", y = "BF10") +
  theme_bw()


## NA

## Is there evidence for the claim that subject relative clause are easier to process than object relative clauses?


## Is there evidence for the claim that sentences with subject relative clauses are easier to comprehend?


## Bayes factor and bounded parameters using Stan.

