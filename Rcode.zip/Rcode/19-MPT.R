## ---------------------------------------
rbinom(1, size = 10, prob = 0.5)


## ---------------------------------------
rbinom(5, size = 10, prob = 0.5)


## ---------------------------------------
(random_sample <- rmnom(1, size = 10, prob = c(0.1, 0.1, 0.8)))


## ---------------------------------------
rmnom(5, size = 10, prob = c(0.1, 0.1, 0.8))


## ---------------------------------------
rbern(5, prob = 0.5)
## equivalent rbinom command:
rbinom(5, size = 1, prob = 0.5)


## ---------------------------------------
rcat(5, prob = c(0.1, 0.1, 0.8), labels = c("yes", "no", "dontknow"))


## ---------------------------------------
rmnom(5, size = 1, prob = c(0.1, 0.1, 0.8))


## ---- tidy = FALSE----------------------
(true_theta <- tibble(theta_NR = .2, 
                     theta_Neologism = .1,
                     theta_Formal = .2,
                     theta_Mixed = .08,
                     theta_Correct =  1 -
  (theta_NR + theta_Neologism + theta_Formal + theta_Mixed)))
## The probabilities must sum to 1:
sum(true_theta)


## ---------------------------------------
N_trials <- 100
(ans_mn <- rmultinom(1, N_trials, true_theta))


## ----mpt-stan, echo = FALSE-------------
multinom <- system.file("stan_models", "multinom.stan", package = "bcogsci")
categorical <- system.file("stan_models", "categorical.stan", package = "bcogsci")
mpt_mnm <- system.file("stan_models", "mpt_mnm.stan", package = "bcogsci")
mpt_cat <- system.file("stan_models", "mpt_cat.stan", package = "bcogsci")
mpt_h <- system.file("stan_models", "mpt_h.stan", package = "bcogsci")


## NA

## ---- results = "hide", message = "FALSE"----
# Create a list:
# c(ans_mn) makes a vector out of the matrix ans_mn
data_mn <-  list(N_trials = N_trials,
                 ans = c(ans_mn)) 


## ---------------------------------------
str(data_mn)


## ----multinom, results = "hide", message = "FALSE"----
multinom <- system.file("stan_models",
                        "multinom.stan",
                        package = "bcogsci")
fit_mn <- stan(file = multinom, 
               data = data_mn)


## ---------------------------------------
print(fit_mn, pars = c("theta"))


## ----multin-posterior, message = FALSE, tidy = FALSE, fig.cap = "(ref:multin-posterior)"----
as.data.frame(fit_mn) %>%
  select(starts_with("theta")) %>%
  mcmc_recover_hist(true = unlist(true_theta)) +
  coord_cartesian(xlim = c(0, 1))


## NA

## ---- results = "hide", message = "FALSE", tidy = FALSE----
N_obs <- 100 
ans_cat <- rcat(N_obs, prob = as.matrix(true_theta))


## ---------------------------------------
data_cat <-  list(N_obs = N_obs,
                  w_ans = ans_cat)
str(data_cat)


## ----catmodel, message = FALSE, results = "hide"----
categorical <- system.file("stan_models",
                           "categorical.stan",
                           package = "bcogsci")
fit_cat <- stan(file = categorical, 
                data = data_cat)  


## ---------------------------------------
print(fit_cat, pars = c("theta"))


## ----cat-posterior, message = FALSE, tidy = FALSE, fig.cap = "Posterior distributions and true means of theta for the categorical model categorical.stan.", warning = FALSE----
as.data.frame(fit_cat) %>%
  select(starts_with("theta")) %>%
  mcmc_recover_hist(true = unlist(true_theta)) +
  coord_cartesian(xlim = c(0, 1))


## \usetikzlibrary{shapes,arrows,shadows,positioning}

## \begin{tikzpicture}

## \node[draw=black,rectangle,inner sep=3pt]  (a) {Attempt};

## \node (NR)  [below left= of a] {NR};

## \node[draw=black,rectangle,inner sep=3pt]  (LexSel)  [below right= of a] {Lexical Selection};

## \draw[->, very thick] (a.south) -- (NR.north) node[above] {$1-a$};

## \draw[->, very thick] (a.south) -- (LexSel.north) node[above] {$a$};

## \node[draw=black,rectangle,inner sep=3pt]  (phon1)  [below left= of LexSel] {Phonology};

## \node[draw=black,rectangle,inner sep=3pt]  (phon2)  [below right= of LexSel] {Phonology};

## \draw[->, very thick] (LexSel.south) -- (phon1.north) node[above] {$1-t$};

## \draw[->, very thick] (LexSel.south) -- (phon2.north) node[above] {$t$};

## 
## \node[draw=black,rectangle,inner sep=3pt]  (tword)  [below left= of phon1] {Target Word};

## \node  (mixed)  [below = of phon1] {Mixed};

## \draw[->, very thick] (phon1.south) -- (tword.north) node[above] {$1-f$};

## \draw[->, very thick] (phon1.south) -- (mixed.north) node[above] {$f$};

## 
## \node  (N1)  [below left= of tword] {Neologism};

## \node  (F1)  [below= of tword] {Formal};

## \draw[->, very thick] (tword.south) -- (N1.north) node[above] {$1-c$};

## \draw[->, very thick] (tword.south) -- (F1.north) node[above right] {$c$};

## 
## 
## \node[draw=black,rectangle,inner sep=3pt]  (tword2)  [below left= of phon2] {Target Word};

## \node  (correct)  [below right= of phon2] {Correct};

## \draw[->, very thick] (phon2.south) -- (tword2.north) node[above] {$1-f$};

## \draw[->, very thick] (phon2.south) -- (correct.north) node[above] {$f$};

## 
## \node  (N2)  [below = of tword2] {Neologism};

## \node  (F2)  [below right= of tword2] {Formal};

## \draw[->, very thick] (tword2.south) -- (N2.north) node[above left] {$1-c$};

## \draw[->, very thick] (tword2.south) -- (F2.north) node[above] {$c$};

## \end{tikzpicture}


## ---- message = FALSE, tidy = FALSE-----
# Probabilities of different answers
Pr_NR <- function(a, t, f, c)
    1 - a
Pr_Neologism <- function(a, t, f, c)
    a * (1 - t) * (1 - f) * (1 - c) + a * t * (1 - f) * (1 - c)
Pr_Formal <- function(a, t, f, c)
    a * (1 - t) * (1 - f) * c +  a * t * (1 - f) * c
Pr_Mixed <- function(a, t, f, c)
    a * (1 - t) * f
Pr_Correct <- function(a, t, f, c)
    a * t * f
# true underlying values for simulated data
a_true <- .75
t_true <- .9
f_true <- .8
c_true <- .1
# Probability of the different answers:
Theta <- tibble(NR = Pr_NR(a_true, t_true, f_true, c_true),
                Neologism = Pr_Neologism(a_true, t_true, f_true, c_true),
                Formal = Pr_Formal(a_true, t_true, f_true, c_true),
                Mixed = Pr_Mixed(a_true, t_true, f_true, c_true),
                Correct = Pr_Correct(a_true, t_true, f_true, c_true))
N_trials <- 200
(ans <- rmultinom(1, N_trials, c(Theta)))


## ----echo=FALSE-------------------------
mpt_h <- system.file("stan_models", "mpt_h.stan",  package = "bcogsci")


## NA

## ---- results = "hide", message = "FALSE"----
data_sMPT <-  list(N_trials = N_trials,
                   ans = c(ans)) 
mpt_mnm <- system.file("stan_models",
                       "mpt_mnm.stan",
                       package = "bcogsci")
fit_sMPT <- stan(file = mpt_mnm, data = data_sMPT)  


## ---------------------------------------
print(fit_sMPT, pars = c("a", "t", "f", "c"))


## ----sMPT-posterior, message = FALSE, tidy = FALSE, fig.cap = "Posterior distributions and true values of the parameters of the simple MPT model (mpt_mnm.stan)."----
as.data.frame(fit_sMPT) %>%
  select(c("a","t","f","c")) %>%
  mcmc_recover_hist(true = c(a_true, t_true, f_true, c_true)) +
  coord_cartesian(xlim = c(0, 1))


## ---------------------------------------
print(fit_sMPT, pars = c("theta"))


## ---------------------------------------
N_obs <- 50
complexity <- rnorm(N_obs, mean = 0, sd = 2)
## choose some hypothetical values:
alpha_f <- .3
# the negative sign indicates that
# increased complexity will lead to a reduced value of f
beta_f <- -.3
# f' as a linear function of complexity
f_prime <- alpha_f + complexity * beta_f
head(f_prime)
## probabilities f for each item
f_true <- plogis(f_prime)
head(f_true)


## ---------------------------------------
theta_NR_v <- rep(Pr_NR(a_true, t_true, f_true, c_true), N_obs)
theta_Neologism_v <- Pr_Neologism(a_true, t_true, f_true, c_true)
theta_Formal_v <- Pr_Formal(a_true, t_true, f_true, c_true)
theta_Mixed_v <- Pr_Mixed(a_true, t_true, f_true, c_true)
theta_Correct_v <- Pr_Correct(a_true, t_true, f_true, c_true)
theta_item <- matrix(
  c(theta_NR_v,
    theta_Neologism_v,
    theta_Formal_v,
    theta_Mixed_v,
    theta_Correct_v),
  ncol = 5)
dim(theta_item)
head(theta_item,n = 3)


## ---------------------------------------
sim_data_cx <- tibble(item = 1:N_obs,
                      complexity = complexity,
                      w_ans = c(rcat(N_obs,theta_item)))
sim_data_cx


## NA

## ---------------------------------------
# Data:
N_item <- 20
N_subj <- 30
N_obs <- N_item * N_subj 


## ---------------------------------------
subj <- rep(1:N_subj, each = N_item)
item <- rep(1:N_item, time = N_subj)


## ---------------------------------------
complexity <- rep(rnorm(N_item, 0, 2), times = N_subj)


## ---------------------------------------
(exp_sim <- tibble(subj = subj,
                  item = item,
                  complexity = complexity))


## ---------------------------------------
# New parameters, in log-odds space:
tau_u_a <- 1.1
## generate subject adjustments in log-odds space:
u_a <- rnorm(N_subj, 0, tau_u_a)
str(u_a)


## ---------------------------------------
## convert the intercept to log-odds space:
alpha_a <- qlogis(a_true)
## a_h' in log-odds space:
a_h_prime <-  alpha_a + u_a[subj]
## convert back to probability space
a_true_h <- plogis(a_h_prime)
str(a_true_h)


## ---------------------------------------
f_true <- plogis(alpha_f + complexity * beta_f)


## ---------------------------------------
# Aux. parameters that define the probabilities:
theta_NR_v_h <- Pr_NR(a_true_h, t_true, f_true, c_true) 
theta_Neologism_v_h <- Pr_Neologism(a_true_h, t_true, f_true, c_true)
theta_Formal_v_h <- Pr_Formal(a_true_h, t_true, f_true, c_true)
theta_Mixed_v_h <- Pr_Mixed(a_true_h, t_true, f_true, c_true)
theta_Correct_v_h <- Pr_Correct(a_true_h, t_true, f_true, c_true)
theta_h <- matrix(
  c(theta_NR_v_h,
    theta_Neologism_v_h,
    theta_Formal_v_h,
    theta_Mixed_v_h,
    theta_Correct_v_h),
  ncol = 5)
dim(theta_h)


## ---------------------------------------
# simulated data:
(sim_data_h <- mutate(exp_sim,
                      w_ans = rcat(N_obs,theta_h)))


## NA

## ---- results = "hide", message = "FALSE", tidy = FALSE----
sim_list_h <-  list(N_obs = nrow(sim_data_h),
                    w_ans = sim_data_h$w_ans,
                    N_subj = max(sim_data_h$subj),
                    subj = sim_data_h$subj,
                    complexity = sim_data_h$complexity)


## ---- results = "hide", message = "FALSE", eval = !file.exists("dataR/fit_h.RDS")----
mpt_h <- system.file("stan_models",
                     "mpt_h.stan",
                     package = "bcogsci")
fit_mpt_h <- stan(file = mpt_h, 
              data = sim_list_h, 
              control = list(adapt_delta = .9))  

## ---- echo= FALSE-----------------------
if(!file.exists("dataR/fit_mpt_h.RDS")){
  saveRDS(fit_mpt_h,"dataR/fit_mpt_h.RDS")
} else {
  fit_mpt_h <- readRDS("dataR/fit_mpt_h.RDS")
}


## ---- tidy = TRUE-----------------------
print(fit_mpt_h, pars=c("t", "c", "tau_u_a", "alpha_a", 
                        "alpha_f", "beta_f"))


## ---------------------------------------
as.data.frame(fit_mpt_h) %>%
  select(alpha_f, beta_f) %>%
  mutate(f_0 = plogis(alpha_f),
         f_1 = plogis(alpha_f + beta_f),
         diff_f = f_1 - f_0) %>%
  summarize(Estimate = mean(diff_f),
          `2.5%` = quantile(diff_f, 0.025),
          `97.5%` = quantile(diff_f, 0.975))


## ----mpt-h, message = FALSE, tidy = FALSE, fig.cap = "Posterior of the hierarchical MPT with true values as vertical lines (model `mpt_h.stan`).", tidy = FALSE----
as.data.frame(fit_mpt_h) %>%
  select(tau_u_a, alpha_a, t, alpha_f, beta_f, c) %>%
  mcmc_recover_hist(true = c(tau_u_a,
                             qlogis(a_true),
                             t_true, alpha_f,
                             beta_f, c_true)) 


## ----aggMPT-h, fig.cap = "Posterior predictive check for aggregated data in the hierarchical MPT model", fig.height = 2----
gen_data <- rstan::extract(fit_mpt_h)$pred_w_ans
ppc_bars(sim_list_h$w_ans, gen_data) +
  ggtitle ("Hierarchical model")


## ----pMPT-h, fig.height=8, fig.cap= "Individual subjects in the hierarchical MPT model."----
ppc_bars_grouped(sim_list_h$w_ans, 
                 gen_data, group = subj) +
  ggtitle ("By-subject plot for the hierarchical model")


## ----fit:aphasia-smpt-cat, message = FALSE, results = "hide", eval = !file.exists("dataR/fit_sh.RDS")----
mpt_cat <- system.file("stan_models",
                       "mpt_cat.stan",
                       package = "bcogsci")
fit_sh <- stan(file = mpt_cat, data = sim_list_h)  


## ---- echo= FALSE-----------------------
if(!file.exists("dataR/fit_sh.RDS")){
  saveRDS(fit_sh,"dataR/fit_sh.RDS")
} else {
  fit_sh <- readRDS("dataR/fit_sh.RDS")
}


## ----aggMPT-nh, fig.height =8, fig.cap = "Posterior predictive check for aggregated data in a non-hierarchical MPT model (mpt_cat.stan).", fig.height = 2----
gen_data_sMPT <- rstan::extract(fit_sh)$pred_w_ans
ppc_bars(sim_list_h$w_ans, gen_data_sMPT) +
  ggtitle ("Non-hierarchical model")


## ----pMPT, fig.height=8, fig.cap= "Individual subjects in the non-hierarchical MPT model (mpt_cat.stan)."----
ppc_bars_grouped(sim_list_h$w_ans, gen_data_sMPT, group = subj) +
  ggtitle ("By-subject plot for the non-hierarchical model")


## Modeling multiple categorical responses.


## An alternative MPT to model the picture recognition task.


## A simple MPT model that incorporates phonological complexity in the picture recognition task.


## A more hierarchical MPT.


## **Advanced**: Multinomial processing trees.


## \small

## \usetikzlibrary{shapes,arrows,shadows,positioning}

## \begin{tikzpicture}[

##         sibling distance=11em,

##         level distance = 4em,

##         every node/.style = {}]

## \node {Source A items}

## child { node [xshift=-5em]{$D_1$}

##   child { node {$d_1$}

##     child { node {Response $A$}}

##   }

##   child { node {$1 - d_1$}

##     child { node {$a$}

##       child { node {Response $A$}}

##     }

##     child { node [xshift=-5em]{$1 - a$}

##       child { node {Response $B$}}

##     }

##   }

## }

## child { node [xshift=5em] {$1-D_1$}

##   child { node {$b$}

##     child { node [xshift=5em]{$g$}

##       child { node {Response $A$}}

##     }

##     child { node {$1 - g$}

##       child { node {Response $B$}}

##     }

##   }

##   child { node [xshift=-.5em]{$1 - b$}

##     child { node [xshift=-.5em] {Response $N$}}

##   }

## };

## 
## \end{tikzpicture}

## 
## \begin{tikzpicture}[

##         sibling distance=11em,

##         level distance = 4em,

##         every node/.style = {}]

## \node {Source B items}

## child { node [xshift=-5em]{$D_2$}

##   child { node {$d_2$}

##     child { node {Response $A$}}

##   }

##   child { node {$1 - d_2$}

##     child { node {$a$}

##       child { node {Response $A$}}

##     }

##     child { node [xshift=-5em]{$1 - a$}

##       child { node {Response $B$}}

##     }

##   }

## }

## child { node [xshift=5em] {$1-D_2$}

##   child { node {$b$}

##     child { node [xshift=5em]{$g$}

##       child { node {Response $A$}}

##     }

##     child { node {$1 - g$}

##       child { node {Response $B$}}

##     }

##   }

##   child { node [xshift=-.5em]{$1 - b$}

##     child { node [xshift=-.5em]{Response $N$}}

##   }

## } ;

## \end{tikzpicture}

## 
## \begin{tikzpicture}[

##         sibling distance=11em,

##         level distance = 4em,

##         every node/.style = {}]

## \node {New items}

## child { node {$b$}

##   child { node [xshift=5em]{$g$}

##     child { node {Response $A$}}

##   }

##   child { node {$1 - g$}

##     child { node {Response $B$}}

##   }

## }

## child { node {$1 - b$}

##   child { node {Response $N$}}

## }

## ;

## 
## \end{tikzpicture}

## 

## ---- eval = FALSE----------------------
## cat(readLines(system.file("stan_models",
##                      "source.stan",
##                      package = "bcogsci")),
##     sep = "\n")

