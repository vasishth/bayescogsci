## **How do we get rid of the integral in the approximation of elpd?**


## ---------------------------------------
N <- 10000
y_data <- rbeta(N, 1, 3)
head(y_data)


## ---------------------------------------
# True distribution
p_t <- function(y) dbeta(y, 1, 3)
# Predictive distribution
p <- function(y) dbeta(y, 2, 2)
# Integration
integrand <- function(y) p_t(y) * log(p(y))
integrate(f = integrand, lower = 0, upper = 1)


## ---------------------------------------
1/N * sum(log(p(y_data)))


## **The cross-validation algorithm**


## ---------------------------------------
formula(fit_N400_sih)


## ----update-fit-sih, message = FALSE, return = "hide"----
fit_N400_sih_null <- update(fit_N400_sih, ~ . - c_cloze)


## ----loo-nested-------------------------
(loo_sih <- loo(fit_N400_sih))
(loo_sih_null <- loo(fit_N400_sih_null))


## ---- loocompare------------------------
loo_compare(loo_sih, loo_sih_null)


## ----diffpredacc, fig.cap = "Difference in predictive accuracy between a model including the effect of cloze and a null model. A larger (more positive) difference indicates an advantage for the model that includes the effect of cloze."----
df_eeg <- mutate(df_eeg,
  diff_elpd = loo_sih$pointwise[, "elpd_loo"] -
    loo_sih_null$pointwise[, "elpd_loo"]
)
ggplot(df_eeg, aes(x = cloze, y = diff_elpd)) +
  geom_point(alpha = .4, position = position_jitter(w = .001, h = 0))


## ----kfold-nested1, message = FALSE, results = "hide", eval = !file.exists("dataR/kfold_sih.RDS")----
kfold_sih <- kfold(fit_N400_sih,
                    folds = "stratified",
                    group = "subj")

## ---- echo= FALSE-----------------------
if(!file.exists("dataR/kfold_sih.RDS")){
  saveRDS(kfold_sih, "dataR/kfold_sih.RDS")
} else {
  kfold_sih <- readRDS("dataR/kfold_sih.RDS")
}

## ----kfold-nested2, message = FALSE, results = "hide", eval = !file.exists("dataR/kfold_sih_null.RDS")----
kfold_sih_null <- kfold(fit_N400_sih_null,
                         folds = "stratified",
                         group = "subj")

## ---- echo= FALSE-----------------------
if(!file.exists("dataR/kfold_sih_null.RDS")){
  saveRDS(kfold_sih_null, "dataR/kfold_sih_null.RDS")
} else {
  kfold_sih_null <- readRDS("dataR/kfold_sih_null.RDS")
}


## ---------------------------------------
kfold_sih
kfold_sih_null


## ---------------------------------------
loo_compare(kfold_sih, kfold_sih_null)


## ----lgo-nested1, message = FALSE, results = "hide", eval = !file.exists("dataR/lgo_sih.RDS")----
logo_sih <- kfold(fit_N400_sih,
                    group = "subj")

## ---- echo= FALSE-----------------------
if(!file.exists("dataR/lgo_sih.RDS")){
  saveRDS(logo_sih, "dataR/lgo_sih.RDS")
} else {
  logo_sih <- readRDS("dataR/lgo_sih.RDS")
}

## ----lgo-nested2, message = FALSE, results = "hide", eval = !file.exists("dataR/lgo_sih_null.RDS")----
logo_sih_null <- kfold(fit_N400_sih_null,
                         group = "subj")

## ---- echo= FALSE-----------------------
if(!file.exists("dataR/lgo_sih_null.RDS")){
  saveRDS(logo_sih_null, "dataR/lgo_sih_null.RDS")
} else {
  logo_sih_null <- readRDS("dataR/lgo_sih_null.RDS")
}


## ---------------------------------------
loo_compare(logo_sih, logo_sih_null)


## ---- message = FALSE-------------------
data("df_stroop")
df_stroop <- df_stroop %>%
  mutate(c_cond = if_else(condition == "Incongruent", 1, -1))


## ----stroopm2, message = FALSE, results = "hide", eval = !file.exists("dataR/fit_stroopm2.RDS")----
fit_stroop <- brm(RT ~ c_cond + (c_cond | subj),
  family = lognormal(),
  prior =
    c(
      prior(normal(6, 1.5), class = Intercept),
      prior(normal(0, 1), class = b),
      prior(normal(0, 1), class = sigma),
      prior(normal(0, 1), class = sd),
      prior(lkj(2), class = cor)
    ),
  data = df_stroop
)

## ---- echo= FALSE-----------------------
if(!file.exists("dataR/fit_stroopm2.RDS")){
  saveRDS(fit_stroop, "dataR/fit_stroopm2.RDS")
} else {
  fit_stroop <- readRDS("dataR/fit_stroopm2.RDS")
}


## ----  eval = !file.exists("dataR/loo_stroop_log.RDS")----
loo_stroop_log <- loo(fit_stroop)

## ---- echo= FALSE-----------------------
if(!file.exists("dataR/loo_stroop_log.RDS")){
  saveRDS(loo_stroop_log, "dataR/loo_stroop_log.RDS")
} else {
  loo_stroop_log <- readRDS("dataR/loo_stroop_log.RDS")
} 


## ---------------------------------------
loo_stroop_log 


## ---- echo= FALSE-----------------------
if(!file.exists("dataR/fit_stroopm2.RDS")){
  saveRDS(fit_stroop, "dataR/fit_stroopm2.RDS")
} else {
  fit_stroop <- readRDS("dataR/fit_stroopm2.RDS")
}


## ----stroopm2null, message = FALSE, results = "hide", eval = !file.exists("dataR/fit_stroopm2_normal.RDS")----
fit_stroop_normal <- brm(RT ~ c_cond + (c_cond | subj),
  family = gaussian(),
  prior =
    c(
      prior(normal(400, 600), class = Intercept),
      prior(normal(0, 100), class = b),
      prior(normal(0, 300), class = sigma),
      prior(normal(0, 300), class = sd),
      prior(lkj(2), class = cor)
    ),
  data = df_stroop
)

## ---- echo= FALSE-----------------------
if(!file.exists("dataR/fit_stroopm2_normal.RDS")){
  saveRDS(fit_stroop_normal, "dataR/fit_stroopm2_normal.RDS")
} else {
  fit_stroop_normal <- readRDS("dataR/fit_stroopm2_normal.RDS")
}


## ----  eval = !file.exists("dataR/loo_stroop_normal_bad.RDS")----
loo_stroop_normal <- loo(fit_stroop_normal)

## ---- echo= FALSE-----------------------
if(!file.exists("dataR/loo_stroop_normal_bad.RDS")){
  saveRDS(loo_stroop_normal, "dataR/loo_stroop_normal_bad.RDS")
} else {
  loo_stroop_normal <- readRDS("dataR/loo_stroop_normal_bad.RDS")
}


## ---------------------------------------
loo_stroop_normal


## ---- eval = !file.exists("dataR/loo_stroop_normal.RDS")----
loo_stroop_normal <- loo(fit_stroop_normal, reloo = TRUE)


## ---- echo= FALSE-----------------------
if(!file.exists("dataR/loo_stroop_normal.RDS")){
  saveRDS(loo_stroop_normal, "dataR/loo_stroop_normal.RDS")
} else {
  loo_stroop_normal <- readRDS("dataR/loo_stroop_normal.RDS")
}


## ---------------------------------------
loo_stroop_normal


## ---------------------------------------
loo_compare(loo_stroop_log, loo_stroop_normal)


## ----diffpredacclog, fig.cap = "Difference in predictive accuracy between a Stroop model with a log-normal likelihood vs. a model with a normal likelihood. A larger (more positive) difference indicates an advantage for the model with the log-normal likelihood."----
df_stroop <- mutate(df_stroop,
  diff_elpd = loo_stroop_log$pointwise[, "elpd_loo"] -
    loo_stroop_normal$pointwise[, "elpd_loo"]
)
ggplot(df_stroop, aes(x = RT, y = diff_elpd)) +
  geom_point(alpha = .4)



## ----diffpredacclog2, fig.cap = "Difference in predictive accuracy between a Stroop model with a log-normal likelihood vs. a model with a normal likelihood for observations smaller than 2 seconds. A larger (more positive) difference indicates an advantage for the model with the log-normal likelihood."----
ggplot(df_stroop, aes(x = RT, y = diff_elpd)) +
  geom_point(alpha = .3) +
  geom_hline(yintercept = 0, linetype = "dashed")+
  coord_cartesian(xlim = c(0, 2000), ylim = c(-10, 10)) 


## ---- message = FALSE-------------------
df_pupil <- df_pupil %>%
  mutate(c_load = load - mean(load),
         c_trial = load - mean(trial))
ls_pupil <- list(
  c_load = df_pupil$c_load,
  c_trial= df_pupil$c_trial,
  p_size = df_pupil$p_size,
  N = nrow(df_pupil)
)


## ---- echo = FALSE----------------------
pupil_model_cv <- system.file("stan_models",
  "pupil_model_cv.stan",
  package = "bcogsci"
)


## NA

## NA

## ---------------------------------------
pupil_model_cv <- system.file("stan_models",
                              "pupil_model_cv.stan",
                              package = "bcogsci")
pupil_null <- system.file("stan_models",
                          "pupil_null.stan",
                          package = "bcogsci")


## ---- message = FALSE-------------------
fit_pupil_int_pos_ll <- stan(
  file = pupil_model_cv,
  iter = 3000,
  data = ls_pupil
)
fit_pupil_int_null_ll <- stan(
  file = pupil_null,
  iter = 3000,
  data = ls_pupil
)


## ---- message = FALSE-------------------
(loo_pos <- loo(fit_pupil_int_pos_ll))
(loo_null <- loo(fit_pupil_int_null_ll))


## ---------------------------------------
loo_compare(loo_pos, loo_null)


## ---------------------------------------
df_pupil$fold <- kfold_split_random(K = 10, N = nrow(df_pupil))
# Show number of obs for each fold:
df_pupil %>%
  group_by(fold) %>%
  count() %>%
  print(n=10)


## ---------------------------------------
pupil_stanmodel <- stan_model(pupil_model_cv)
pupil_null_stanmodel <- stan_model(pupil_null)
log_pd_kfold <- matrix(nrow = 6000, ncol = nrow(df_pupil))
log_pd_null_kfold <- matrix(nrow = 6000, ncol = nrow(df_pupil))


## ---- message = FALSE, results = "hide", eval = !file.exists("dataR/log_pd_kfold.RDS")----
# Loop over the folds
for(k in 1:10){
  # Training set for k
  df_pupil_train <- df_pupil %>%
    filter(fold != k)
  ls_pupil_train <- list(
    c_load = df_pupil_train$c_load,
    c_trial= df_pupil_train$c_trial,
    p_size = df_pupil_train$p_size,
    N = nrow(df_pupil_train)
  )
  # Held out set for k
   df_pupil_ho <- df_pupil %>%
    filter(fold == k)
  ls_pupil_ho <- list(
    c_load = df_pupil_ho$c_load,
    c_trial= df_pupil_ho$c_trial,
    p_size = df_pupil_ho$p_size,
    N = nrow(df_pupil_ho)
  )
  # Train the models
  fit_train <- sampling(pupil_stanmodel,
                                     iter = 3000,
                                     data = ls_pupil_train)
  fit_null_train <- sampling(pupil_null_stanmodel,
                                     iter = 3000,
                                     data = ls_pupil_train)
  # Generated quantities based on the posterior from the training set
  # and the data from the held out set 
  gq_ho <- gqs(pupil_stanmodel,
                     draws = as.matrix(fit_train),
                     data = ls_pupil_ho)
  gq_null_ho <- gqs(pupil_null_stanmodel,
                        draws = as.matrix(fit_null_train),
                        data = ls_pupil_ho)
  # Extract log likelihood which represents
  # the pointwise predictive density
  log_pd_kfold[, df_pupil$fold == k] <-
    extract_log_lik(gq_ho)
  log_pd_null_kfold[, df_pupil$fold == k] <-
    extract_log_lik(gq_null_ho)
}

## ---- echo= FALSE-----------------------
if(!file.exists("dataR/log_pd_kfold.RDS")){
  saveRDS(log_pd_kfold, "dataR/log_pd_kfold.RDS")
  saveRDS(log_pd_null_kfold, "dataR/log_pd_null_kfold.RDS")
} else {
  log_pd_kfold <- readRDS("dataR/log_pd_kfold.RDS")
  log_pd_null_kfold <- readRDS("dataR/log_pd_null_kfold.RDS")
}


## ---------------------------------------
(elpd_pupil_kfold <- elpd(log_pd_kfold))
(elpd_pupil_null_kfold <- elpd(log_pd_null_kfold))


## ---------------------------------------
loo_compare(elpd_pupil_kfold, elpd_pupil_null_kfold)


## Predictive accuracy of the linear and the logarithm effect of cloze probability.


## Lognormal model in Stan

