## ---------------------------------------
N <- 10000
mu <- .002
sigma <- .0004
rt <- 1/rnorm(N, mu, sigma)
c(mean(rt), sd(rt), min(rt), max(rt))


## ----recnormalhist, echo = FALSE, fig.cap = "(ref:recnormalhist)", message = FALSE----
ggplot(tibble(rt=rt), aes(rt)) + geom_histogram()


## ---- echo = FALSE----------------------
normal_recrt <- system.file("stan_models", "normal_recrt.stan", package = "bcogsci")


## NA

## ---- results = "hide", message = FALSE----
normal_recrt <- system.file("stan_models",
                            "normal_recrt.stan",
                            package = "bcogsci")
fit_rec <- stan(normal_recrt, data = list(N = N, recRT = 1/rt))


## ---------------------------------------
print(fit_rec, pars = c("mu", "sigma"), digits = 4)


## ---- echo = FALSE----------------------
recnormal_rt <- system.file("stan_models", "recnormal_rt.stan", package = "bcogsci")


## NA

## ---- results = "hide", message = FALSE----
recnormal_rt <- system.file("stan_models",
                            "recnormal_rt.stan",
                            package = "bcogsci")
fit_rec <- stan(recnormal_rt, data = list(N = N, RT = rt)) 


## ---------------------------------------
print(fit_rec, pars = c("mu", "sigma"), digits = 4)


## ---- echo = FALSE----------------------
recnormal_rt_f <- system.file("stan_models",
                            "recnormal_rt_f.stan",
                            package = "bcogsci")


## NA

## ---- results = "hide", message = FALSE----
recnormal_rt_f <- system.file("stan_models",
                            "recnormal_rt_f.stan",
                            package = "bcogsci")
fit_rec <- stan(recnormal_rt_f, data = list(N = N, RT = rt)) 


## ---------------------------------------
print(fit_rec, pars = c("mu", "sigma"), digits = 4)


## ---- message = FALSE-------------------
ppc_dens_overlay(rt, yrep = extract(fit_rec)$rt_pred[1:500, ]) +
  coord_cartesian(xlim = c(0, 2000))


## ---- message = FALSE-------------------
post_rec <- as.data.frame(fit_rec) %>%
  select("mu", "sigma")
mcmc_recover_hist(post_rec, true = c(mu, sigma))


## ---- results = "hide", message = FALSE----
data("df_spacebar")
fit_rec_sb <- stan(recnormal_rt_f,
                data = list(N = nrow(df_spacebar),
                            RT = df_spacebar$rt)) 


## ---------------------------------------
print(fit_rec_sb, pars = c("mu", "sigma"), digits = 4)


## ---- message = FALSE-------------------
ppc_dens_overlay(df_spacebar$rt, yrep = extract(fit_rec_sb)$rt_pred[1:500, ]) +
  coord_cartesian(xlim = c(0, 2000))


## ---- echo = FALSE----------------------
recnormal_sbc <- system.file("stan_models",
                            "recnormal_sbc.stan",
                            package = "bcogsci")


## NA

## ---- eval = FALSE----------------------
## recnormal_sbc <- system.file("stan_models",
##                             "recnormal_sbc.stan",
##                             package = "bcogsci")
## output_sbc <- sbc(recnormal_sbc, data = list(N = 100,
##                                          mu_s_loc = 2,
##                                          mu_s_scale = 2,
##                                          sigma_s_loc = log(.5),
##                                          sigma_s_scale = 1),
##               M = 500,
##               refresh = 0)

