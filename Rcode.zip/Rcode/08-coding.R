## ---- echo=TRUE-------------------------
data("df_contrasts1")
df_contrasts1
str(df_contrasts1)


## ---- echo=FALSE------------------------
table1 <- df_contrasts1 %>% group_by(F) %>% # Table for main effect F
  summarize(N = n(), M = mean(DV), SD = sd(DV), SE = round(SD / sqrt(N), 1))
table1a <- as.data.frame(table1)
names(table1a) <- c("Factor", "N data", "Est. means", "Std. dev.", "Std. errors")
(GM <- mean(table1$M)) # Grand Mean


## ----cTab1Means, echo=FALSE, results = "asis"----
apa_table(table1a,
  placement = "b", digits = 1,
  caption = "Summary statistics per condition for the simulated data."
)


## ----cFig1Means, fig=TRUE, include=TRUE, echo=FALSE, cache=FALSE, fig.width=4, fig.height=3.6, fig.cap = "Means and standard errors of the simulated dependent variable (e.g., response times in seconds) in two conditions F1 and F2."----
(plot1 <- qplot(x = F, y = M, group = 1, data = table1, geom = c("point", "line")) +
  geom_errorbar(aes(max = M + SE, min = M - SE), width = 0) +
  # scale_y_continuous(breaks=c(250,275,300)) +
  scale_y_continuous(breaks = seq(0, 1, .2)) + coord_cartesian(ylim = c(0, 1)) +
  labs(y = "Mean Response Time [sec]", x = "Factor F") +
  theme_bw())


## ----fitmodel, echo=TRUE, message=FALSE, results="hide"----
fit_F <- brm(DV ~ 1 + F,
  data = df_contrasts1,
  family = gaussian(),
  prior = c(
    prior(normal(0, 2), class = Intercept),
    prior(normal(0, 2), class = sigma),
    prior(normal(0, 1), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_F)


## ---- echo=TRUE-------------------------
contrasts(df_contrasts1$F)


## ---- echo=TRUE-------------------------
df_contrasts1$Fb <- factor(df_contrasts1$F,
  levels = c("F2", "F1")
)
contrasts(df_contrasts1$Fb)


## ---- echo=TRUE, message=FALSE, results="hide"----
fit_Fb <- brm(DV ~ 1 + Fb,
  data = df_contrasts1,
  family = gaussian(),
  prior = c(
    prior(normal(0, 2), class = Intercept),
    prior(normal(0, 2), class = sigma),
    prior(normal(0, 1), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_Fb)


## ---- echo=TRUE, message=FALSE, results="hide"----
contrasts(df_contrasts1$F) <- c(-0.5, +0.5)
fit_mSum <- brm(DV ~ 1 + F,
  data = df_contrasts1,
  family = gaussian(),
  prior = c(
    prior(normal(0, 2), class = Intercept),
    prior(normal(0, 2), class = sigma),
    prior(normal(0, 1), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_mSum)


## ---- echo=TRUE-------------------------
contrasts(df_contrasts1$F)


## ---- echo=TRUE, message=FALSE, results="hide"----
fit_mCM <- brm(DV ~ -1 + F,
  data = df_contrasts1,
  family = gaussian(),
  prior = c(
    prior(normal(0, 2), class = sigma),
    prior(normal(0, 2), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_mCM)


## ---------------------------------------
df_postSamp <- as_draws_df(fit_mCM)
str(df_postSamp)


## ---------------------------------------
df_postSamp$b_dif <- df_postSamp$b_FF2 - df_postSamp$b_FF1


## ---------------------------------------
c(
  Estimate = mean(df_postSamp$b_dif),
  quantile(df_postSamp$b_dif, p = c(0.025, 0.975))
)


## ---- echo=TRUE-------------------------
data("df_contrasts2")
head(df_contrasts2)


## ---- echo=FALSE------------------------
table.word <- df_contrasts2 %>%
  group_by(F) %>%
  summarise(
    N = length(DV), M = mean(DV),
    SD = sd(DV), SE = sd(DV) / sqrt(N)
  )
table.word1 <- as.data.frame(table.word)
names(table.word1) <- c(
  "Factor", "N data",
  "Est. means", "Std. dev.", "Std. errors"
)


## ----cTab2Means, echo=FALSE, results = "asis"----
apa_table(table.word1,
  placement = "b", digits = 1,
  caption = "Summary statistics per condition for the simulated data."
)


## ---- echo=TRUE-------------------------
HcSum <- rbind(
  cH00 = c(adjectives = 1 / 3, nouns = 1 / 3, verbs = 1 / 3),
  cH01 = c(adjectives = +2 / 3, nouns = -1 / 3, verbs = -1 / 3),
  cH02 = c(adjectives = -1 / 3, nouns = +2 / 3, verbs = -1 / 3)
)
fractions(t(HcSum))


## ---- echo=TRUE-------------------------
ginv2 <- function(x) { # define a function to make the output nicer
  MASS::fractions(provideDimnames(MASS::ginv(x),
    base = dimnames(x)[2:1]
  ))
}


## ---- echo=TRUE-------------------------
(XcSum <- ginv2(HcSum))


## ---- echo=TRUE-------------------------
fractions(cbind(1, contr.sum(3)))


## ---- echo=TRUE, message=FALSE, results="hide"----
contrasts(df_contrasts2$F) <- XcSum[, 2:3]
fit_Sum <- brm(DV ~ 1 + F,
  data = df_contrasts2,
  family = gaussian(),
  prior = c(
    prior(normal(500, 100), class = Intercept),
    prior(normal(0, 100), class = sigma),
    prior(normal(0, 100), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_Sum)


## ----loadHypr---------------------------
HcSum <- hypr(
  b1 = adjectives ~ (adjectives + nouns + verbs) / 3,
  b2 = nouns ~ (adjectives + nouns + verbs) / 3,
  levels = c("adjectives", "nouns", "verbs")
)
HcSum


## ---------------------------------------
contr.hypothesis(HcSum)


## ---- echo=TRUE-------------------------
contrasts(df_contrasts2$F) <- contr.hypothesis(HcSum)


## ---- echo=TRUE-------------------------
data("df_contrasts3")


## ---- echo=FALSE, message=FALSE---------
table3 <- df_contrasts3 %>%
  group_by(F) %>%
  summarize(N = length(DV), M = mean(DV), SD = sd(DV), SE = SD / sqrt(N))
(GM <- mean(table3$M)) # Grand Mean
table3a <- as.data.frame(table3)
names(table3a) <- c("Factor", "N data", "Est. means", "Std. dev.", "Std. errors")


## ----helmertsimdatFig, fig=TRUE, include=TRUE, echo=FALSE, cache=FALSE, fig.width=4.7, fig.height=3.4, fig.cap = "Means and error bars (showing standard errors) for a simulated dataset with one between-subjects factor with four levels."----
(plot2 <- qplot(x = F, y = M, group = 1, data = table3, geom = c("point", "line")) +
  geom_errorbar(aes(max = M + SE, min = M - SE), width = 0) +
  # scale_y_continuous(breaks=c(250,275,300)) +
  labs(y = "Mean DV", x = "Factor F") +
  theme_bw())


## ----echo=FALSE,cTab3Means, results = "asis"----
apa_table(table3a,
  placement = "b", digits = 1,
  caption = "Summary statistics per condition for the simulated data."
)


## ---- echo=TRUE-------------------------
HcRep <- hypr(
  c2vs1 = F2 ~ F1, 
  c3vs2 = F3 ~ F2, 
  c4vs3 = F4 ~ F3,
  levels = c("F1", "F2", "F3", "F4")
)
HcRep


## ---- echo=TRUE-------------------------
MASS::fractions(MASS::contr.sdif(4))


## ---- echo=TRUE, message=FALSE, results="hide"----
contrasts(df_contrasts3$F) <- contr.hypothesis(HcRep)
fit_Rep <- brm(DV ~ 1 + F,
  data = df_contrasts3,
  family = gaussian(),
  prior = c(
    prior(normal(20, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_Rep)


## ---------------------------------------
HcHel <- hypr(
  b1 = F2 ~ F1,
  b2 = F3 ~ (F1 + F2) / 2,
  b3 = F4 ~ (F1 + F2 + F3) / 3,
  levels = c("F1", "F2", "F3", "F4")
)
HcHel


## ---------------------------------------
contr.helmert(4)


## ---- echo=TRUE-------------------------
contrasts(df_contrasts3$F) <- contr.hypothesis(HcHel)
fit_Hel <- brm(DV ~ 1 + F,
  data = df_contrasts3,
  family = gaussian(),
  prior = c(
    prior(normal(20, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_Hel)


## **Treatment contrast with intercept as the grand mean.**


## ---------------------------------------
HcTrGM <- hypr(
  b0 = ~ (F1 + F2 + F3 + F4) / 4,
  b1 = F2 ~ F1,
  b2 = F3 ~ F1,
  b3 = F4 ~ F1,
  levels = c("F1", "F2", "F3", "F4")
)
HcTrGM


## ---- echo=TRUE-------------------------
contrasts(df_contrasts3$F) <- contr.hypothesis(HcTrGM)
fit_TrGM <- brm(DV ~ 1 + F,
  data = df_contrasts3,
  family = gaussian(),
  prior = c(
    prior(normal(20, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_TrGM)


## ---- echo=TRUE-------------------------
(contrasts(df_contrasts3$F) <- contr.hypothesis(HcRep)) # contrast matrix
covars <- model.matrix(~ 1 + F, df_contrasts3) # design matrix
(covars <- as.data.frame(covars))


## ---- echo=TRUE-------------------------
df_contrasts3[, c("Fc2vs1", "Fc3vs2", "Fc4vs3")] <- covars[, 2:4]


## ---- echo=TRUE, message=FALSE, results="hide"----
fit_m3 <- brm(DV ~ 1 + Fc2vs1 + Fc3vs2 + Fc4vs3,
  data = df_contrasts3,
  family = gaussian(),
  prior = c(
    prior(normal(20, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_m3)


## ---- echo=TRUE-------------------------
Xpol <- contr.poly(4)
(contrasts(df_contrasts3$F) <- Xpol)

## ---- echo=TRUE, message=FALSE, results="hide"----
fit_Pol <- brm(DV ~ 1 + F,
  data = df_contrasts3,
  family = gaussian(),
  prior = c(
    prior(normal(20, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_Pol)


## ---- echo=TRUE, message=FALSE, results="hide"----
df_contrasts3$F <- factor(df_contrasts3$F, ordered=TRUE)
fit_mo <- brm(DV ~ 1 + mo(F),
  data = df_contrasts3,
  family = gaussian(),
  prior = c(
    prior(normal(20, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---------------------------------------
summary(fit_mo)


## ----condmopol, out.width='48%', fig.show = "hold", fig.cap = "Conditional effects using the polinomial contrasts on the left side vs. assuming monotic effects on the right side.", tidy = FALSE, fig.width = 2.2, fig.height =2.2, warning = FALSE, message = FALSE----
conditional_effects(fit_Pol) 
conditional_effects(fit_mo)


## ----checkmopol, out.width='48%', fig.show = "hold", fig.cap = "Posterior predictive distributions by condition using the polynomial contrasts on the left side vs. assuming monotonic effects on the right side.", tidy = FALSE, fig.width = 2.2, fig.height =2.7, message = FALSE, warning = FALSE----
pp_check(fit_Pol, type = "violin_grouped", group = "F", y_draw = "points") +
  theme(legend.position = "bottom")+
  coord_cartesian(ylim = c(-55, 105))
pp_check(fit_mo, type = "violin_grouped", group = "F", y_draw = "points") +
  theme(legend.position = "bottom") +
  coord_cartesian(ylim = c(-55, 105))


## ---- echo=TRUE-------------------------
colSums(contr.treatment(4))


## ---- echo=TRUE-------------------------
colSums(contr.sdif(4))


## ---- echo=TRUE-------------------------
(Xsum <- cbind(F1 = c(1, 1, -1, -1),
               F2 = c(1, -1, 1, -1),
               F1xF2 = c(1, -1, -1, 1)))
cor(Xsum)


## ---- echo=TRUE-------------------------
cor(contr.sum(4))


## ---- echo=TRUE-------------------------
cor(contr.sdif(4))
cor(contr.treatment(4))


## ---------------------------------------
hypr(int = a ~ 0, b1 = b ~ a, b2 = c ~ a)
contr.treatment(c("a", "b", "c"))


## ---------------------------------------
hypr(b1 = m1 ~ m0, b2 = m2 ~ m0)


## ---------------------------------------
hypr(int = (m0 + m1 + m2) / 3 ~ 0, b1 = m1 ~ m0, b2 = m2 ~ m0)


## ---- echo=TRUE-------------------------
contrasts(df_contrasts2$F) <- contr.hypothesis(HcSum)
contrasts(df_contrasts2$F)


## ---- echo=TRUE-------------------------
fixef(fit_Sum)


## ---------------------------------------
df_postSamp_Sum <- as_draws_df(fit_Sum)
str(df_postSamp_Sum)


## ---- echo=TRUE-------------------------
contrasts(df_contrasts2$F)


## ---------------------------------------
df_postSamp_Sum$b_adjectives <-
  df_postSamp_Sum$b_Intercept + df_postSamp_Sum$b_FcH01


## ---------------------------------------
df_postSamp_Sum$b_nouns <-
  df_postSamp_Sum$b_Intercept + df_postSamp_Sum$b_FcH02


## ---------------------------------------
df_postSamp_Sum$b_verbs <-
  df_postSamp_Sum$b_Intercept - df_postSamp_Sum$b_FcH01 -
  df_postSamp_Sum$b_FcH02


## ---- results="hide", message=FALSE-----
postTab <- df_postSamp_Sum %>%
  # removes the meta data:
  as.data.frame() %>%
  select(b_adjectives, b_nouns, b_verbs) %>%
  # transform from wide to long with tidyr: 
  pivot_longer(cols = everything(),
               names_to = "condition",
               values_to = "samp") %>%
  group_by(condition) %>%
  summarize(
    post_mean = round(mean(samp)),
    `2.5%` = round(quantile(samp, p = 0.025)),
    `97.5%` = round(quantile(samp, p = 0.975))
  )

## ---- echo=TRUE-------------------------
postTab


## ---------------------------------------
conditional_effects(fit_Sum, robust = FALSE)[]


## ----cFigCond, fig=TRUE, include=TRUE, echo=TRUE, cache=FALSE, fig.width=4, fig.height=3.6, fig.cap = "Estimated condition means, computed from a brms model fitted with a sum contrast."----
conditional_effects(fit_Sum, robust = FALSE)


## ---- echo=TRUE-------------------------
df_postSamp_Sum$GM <-
  (df_postSamp_Sum$b_adjectives +
    df_postSamp_Sum$b_nouns +
    df_postSamp_Sum$b_verbs) / 3
df_postSamp_Sum$b_FcH03 <-
  df_postSamp_Sum$b_verbs - df_postSamp_Sum$GM
c(
  post_mean = mean(df_postSamp_Sum$b_FcH03),
  quantile(df_postSamp_Sum$b_FcH03, p = c(0.025, 0.975))
)


## ---- echo=TRUE-------------------------
contrasts(df_contrasts3$F) <- contr.hypothesis(HcRep)
contrasts(df_contrasts3$F)


## ---- echo=TRUE-------------------------
fixef(fit_Rep)


## ---- echo=TRUE-------------------------
df_postSamp_Rep <- as_draws_df(fit_Rep)
str(df_postSamp_Rep)


## ---- echo=TRUE-------------------------
df_postSamp_Rep$b_F1 <- df_postSamp_Rep$b_Intercept +
  -3 / 4 * df_postSamp_Rep$b_Fc2vs1 +
  -1 / 2 * df_postSamp_Rep$b_Fc3vs2 +
  -1 / 4 * df_postSamp_Rep$b_Fc4vs3


## ---- echo=TRUE-------------------------
df_postSamp_Rep$b_F2 <- df_postSamp_Rep$b_Intercept +
  1 / 4 * df_postSamp_Rep$b_Fc2vs1 +
  -1 / 2 * df_postSamp_Rep$b_Fc3vs2 +
  -1 / 4 * df_postSamp_Rep$b_Fc4vs3
df_postSamp_Rep$b_F3 <- df_postSamp_Rep$b_Intercept +
  1 / 4 * df_postSamp_Rep$b_Fc2vs1 +
  1 / 2 * df_postSamp_Rep$b_Fc3vs2 +
  -1 / 4 * df_postSamp_Rep$b_Fc4vs3
df_postSamp_Rep$b_F4 <- df_postSamp_Rep$b_Intercept +
  1 / 4 * df_postSamp_Rep$b_Fc2vs1 +
  1 / 2 * df_postSamp_Rep$b_Fc3vs2 +
  3 / 4 * df_postSamp_Rep$b_Fc4vs3


## ---- results="hide", message=FALSE-----
postTab <- df_postSamp_Rep %>%
  as.data.frame() %>%
  select(b_F1, b_F2, b_F3, b_F4) %>%
   pivot_longer(cols = everything(),
               names_to = "condition",
               values_to = "samp") %>%
  group_by(condition) %>%
  summarize(
    post_mean = round(mean(samp)),
    `2.5%` = round(quantile(samp, p = 0.025)),
    `97.5%` = round(quantile(samp, p = 0.975))
  ) 

## ---- echo=TRUE-------------------------
postTab


## ---------------------------------------
conditional_effects(fit_Rep, robust = FALSE)[]


## Contrast coding for a four-condition design


## ---------------------------------------
library(bcogsci)
data("df_persianE1")
dat1 <- df_persianE1
head(dat1)


## Helmert coding for a four-condition design.


## ---------------------------------------
library(bcogsci)
data("df_polarity")
head(df_polarity)


## ---------------------------------------
dat2 <- subset(df_polarity, times == "RRT")
head(dat2)


## Number of possible comparisions in a single model.

