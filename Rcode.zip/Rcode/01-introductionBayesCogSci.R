## ----lotp, fig.cap = "Illustration of law of total probability.", out.width = "80%", echo = FALSE, fig.align = "center"----
knitr::include_graphics("cc_figure/LOTP.png", dpi = 1000)


## ---------------------------------------
rbinom(10, n = 20, prob = 0.5)


## ----binomplot, fig.cap = "(ref:binomplot)", echo=FALSE, fig.show="hold", out.width="30%" , fig.width = 2.2, fig.height =2.2----

ggplot(tibble(x = c(0, 10)), aes(x)) +
   stat_function(fun = dbinom, geom = "col",
                 args = list(size = 10, prob = 0.5), n = 11) +
  xlab("Possible outcomes") +
  ylab("Probability") +
  ggtitle(expression(paste(theta, " = 0.5", sep = ""))) +
  scale_x_continuous(breaks = 0:10)


ggplot(tibble(x = c(0, 10)), aes(x)) +
   stat_function(fun = dbinom, geom = "col",
                 args = list(size = 10, prob = 0.1), n = 11) +
  xlab("Possible outcomes") +
  ylab("Probability") +
  ggtitle(expression(paste(theta, " = 0.1", sep = ""))) +
  scale_x_continuous(breaks = 0:10)


ggplot(tibble(x = c(0, 10)), aes(x)) +
   stat_function(fun = dbinom, geom = "col",
                 args = list(size = 10, prob = 0.9), n = 11) +
  xlab("Possible outcomes") +
  ylab("Probability") +
  ggtitle(expression(paste(theta, " = 0.9", sep = ""))) +
  scale_x_continuous(breaks = 0:10)


## ---- binomlik,echo=FALSE,fig.cap="The likelihood function for 7 successes out of 10."----
ggplot(tibble(prob = c(0, 1)), aes(prob)) +
   stat_function(fun = dbinom,
                 args = list(x = 7, size = 10)) +
  xlab("theta") +
  ylab("Likelihood") +
  geom_vline(xintercept = .7, linetype = "dashed") +
  annotate("text", x = .55, y =.05, label = "Max. value at: \n 0.7")+
  ggtitle("Likelihood function")



## ---- lawlargenos,echo=FALSE,fig.cap="The plot shows the estimate of the mean proportion of successes sampled from a Binomial distribution with true probability of success 0.5, with increasing sample sizes. As the sample size increases, the estimate converges to  the true value of 0.5."----
n<-seq(10,100000,by=50)

mean_store<-rep(NA,length(n))
for(i in 1:length(n)){
y<-rbinom(n[i],size=1,prob=0.5)
mean_store[i]<-mean(y)
}

mle<-data.frame(n=n,mean_store=mean_store)

ggplot(mle, aes(x=n, y=mean_store)) + 
  geom_line() + geom_point() +
  scale_x_log10()+ylim(0,1)+
  xlab("sample size n (log scale)")+ylab("estimate")+
  geom_hline(yintercept = 0.5)+
  ggtitle("The MLE  as a function of sample size")


## ----dnormexample1,echo=TRUE------------
dbinom(5, size = 10, prob = 0.5)


## ---------------------------------------
dbinom(5, size = 10, prob = c(0.1, 0.9))


## ----cdfbinom1,echo=TRUE----------------
## the cumulative probability of obtaining
## 0, 1, or 2 successes out of 10,
## with theta=0.5:
dbinom(0, size = 10, prob = 0.5) +
  dbinom(1, size = 10, prob = 0.5) +
  dbinom(2, size = 10, prob = 0.5)


## ---------------------------------------
sum(dbinom(0:2, size = 10, prob = 0.5))


## ----pbinomexample1,echo=TRUE-----------
pbinom(2, size = 10, prob = 0.5, lower.tail = TRUE)


## ----pbinomexample2,echo=TRUE-----------
pbinom(2, size = 10, prob = 0.5, lower.tail = FALSE)
## equivalently:
## sum(dbinom(3:10,size = 10, prob = 0.5))


## ---- binomcdf,echo=FALSE,fig.cap="The cumulative distribution function for a Binomial distribution assuming 10 trials, with 50% probability of success."----
## plot(0:10, pbinom(0:10, size = 10, prob = 0.5),
##   xlab = "Possible outcomes k",
##   ylab = "Prob. of k or less successes",
##   main = "Cumulative distribution function"
## )
ggplot(tibble(q = c(0, 10)), aes(q)) +
   stat_function(fun = pbinom, geom = "col",
                 args = list(size = 10, prob = 0.5), n = 11) +
  xlab("Possible outcomes k") +
  ylab("Probab. of k or less successes") +
  ggtitle("Cumulative distribution function") +
  scale_x_continuous(breaks = 0:10)




## ----qbinomexample,echo=TRUE------------
qbinom(0.37, size = 10, prob = 0.5)


## ----inverseCDFbinomial,echo=FALSE,fig.cap="The inverse CDF for the Binomial(size=10,prob=0.5)."----
probs <- seq(0,1,by=0.01)
invcdf<-data.frame(probs=probs,
                q=qbinom(probs, 
                            size = 10, 
                         prob = 0.5))

ggplot(invcdf, aes(x=probs, 
                   y=q)) + 
  geom_line() +
  xlim(0,1)+
  xlab("probability")+ylab("quantile")+
  ggtitle("Inverse CDF,  Binomial(size=10,prob=0.5)")+
  scale_y_continuous(breaks = seq(0, 10, by = 1))


## ----rbinomexample,echo=TRUE------------
rbinom(1, size = 10, prob = 0.5)


## ----rbinomexamplemean,echo=TRUE--------
(y <- rbinom(10, size = 1, prob = 0.5))
mean(y) * 10
sum(y)


## ----rbernoulliexample, echo=TRUE-------
rbern(n=10,prob=0.5)


## ---- normdistrn,echo=FALSE,fig.cap="The PDF, CDF, and inverse CDF for the $\\mathit{Normal}(\\mu=500,\\sigma=100)$." , fig.show="hold", out.width="30%", fig.width = 2.2, fig.height =2.2----
ggplot(tibble(x = c(200, 900)), aes(x)) +
   stat_function(fun = dnorm, 
                 args = list(mean = 500, sd = 100)) +
  xlab("y") +
  ylab("Density") +
  ggtitle("PDF")

ggplot(tibble(x = c(200, 900)), aes(x)) +
   stat_function(fun = pnorm, 
                 args = list(mean = 500, sd = 100)) +
  xlab("y") +
  ylab("Probability") +
  ggtitle("CDF")

ggplot(tibble(y = c(0, 1)), aes(y)) +
   stat_function(fun = qnorm, 
                 args = list(mean = 500, sd = 100)) +
  xlab("Probability") +
  ylab("y") +
  ggtitle("Inverse CDF")




## ----pnormexample-----------------------
pnorm(700, mean = 500, sd = 100) - pnorm(200, mean = 500, sd = 100)


## ----qnormexample-----------------------
qnorm(0.975, mean = 500, sd = 100)


## ----rnormexample-----------------------
y <- rnorm(10, mean = 500, sd = 100)
mean(y)
sd(y)


## ---------------------------------------
quantile(y, probs = c(0.025, 0.975))


## ---------------------------------------
## density:
dnorm(1, mean = 0, sd = 1)


## ---------------------------------------
pnorm(2, mean = 0, sd = 1) - pnorm(-2, mean = 0, sd = 1)


## ---------------------------------------
dbinom(2, size = 10, prob = 0.5)
pbinom(2, size = 10, prob = 0.5) - pbinom(1, size = 10, prob = 0.5)


## ---------------------------------------
pnorm(0, mean = 0, sd = 1, lower.tail = FALSE)
## alternatively:
1 - pnorm(0, mean = 0, sd = 1, lower.tail = TRUE)


## ---------------------------------------
pnorm(0, mean = 0, sd = 1, lower.tail = TRUE)


## ---------------------------------------
data("df_discreteagrmt")


## ----bivardiscrete,message="FALSE",warning=FALSE,results="asis",fig.cap="Example of a discrete bivariate distribution. In these data, in every trial, two pieces of information were collected: Likert responses and yes-no question responses. The random variable X represents Likert scale responses on a scale of 1-7. and the random variable Y represents 0, 1 (incorrect, correct) responses to comprehension questions.", echo = FALSE----

rating0 <- df_discreteagrmt %>% filter(accuracy == 0) %>%
  count(rating) %>%
  pull(n)
rating1 <- df_discreteagrmt %>% filter(accuracy == 1) %>%
  count(rating) %>%
  pull(n)
ratingsbivar <- tibble(`0` = rating0, `1` = rating1)
## function from the bivariate package:
gbvpmf(as.matrix(ratingsbivar)) %>%
  plot(arrows = FALSE)

rating0 <- df_discreteagrmt %>% filter(accuracy == 0) %>%
  count(rating) %>%
  pull(n)
rating1 <- df_discreteagrmt %>% filter(accuracy == 1) %>%
  count(rating) %>%
  pull(n)
ratingsbivar <- tibble(`0` = rating0, `1` = rating1)
## function from the bivariate package:
gbvpmf(as.matrix(ratingsbivar)) %>%
  plot(arrows = FALSE)

probs <- t(attr(gbvpmf(as.matrix(ratingsbivar)), "p"))
colnames(probs) <- paste("x=",1:7,sep="")
rownames(probs)<- paste("y=",0:1,sep="")


## ----discbivariatetabular,echo=FALSE, tidy = FALSE, results= "asis"----
kableExtra::kable(probs,
                  digits = 3, booktabs = TRUE, 
                  vline = "", # format="latex",
  caption = "The joint PMF for two random variables X and Y.")


## ---------------------------------------
# P(Y)
(PY <- rowSums(probs))
sum(PY) ## sums to 1
# P(X)
(PX <- colSums(probs))
sum(PX) ## sums to 1


## ----discbivariatetabularmarginal,echo=FALSE, tidy = FALSE, results= "asis"----
probs <- round(probs,3)
probs<-rbind(probs,round(PX,3))
probs<-cbind(probs,c(round(PY,3),""))
rownames(probs)[3]<-"P(X)"
colnames(probs)[8]<-"P(Y)"

kableExtra::kable(probs,
                  digits = 3, booktabs = TRUE, 
                  vline = "", # format="latex",
  caption = "The joint PMF for two random variables X and Y, along with the marginal distributions of X and Y.")


## ----marginalbarplot,echo=FALSE,fig.cap="The marginal distributions of the random variables X and Y, presented as barplots."----
op <- par(mfrow = c(1, 2), pty = "s")
barplot(PX, main = "P(X)")
barplot(PY, main = "P(Y)")


## ----discbivariatetabularconditional,echo=FALSE, tidy = FALSE, results= "asis"----
y0<-c("0.062",rep("",6))
y1<-rep("",7)
conddistrn<-rbind(y0,y1)
colnames(conddistrn)<-paste("x=",1:7,sep="")
rownames(conddistrn)<-c("p_X|Y(x|y=0)","p_X|Y(x|y=1)")

kableExtra::kable(conddistrn,
                  digits = 3, booktabs = TRUE, 
                  vline = "", # format="latex",
  caption = "A table for listing conditional distributions of X given Y.")


## ----zerocor,echo=FALSE,fig.cap="A bivariate Normal distribution with zero correlation. Shown are four plots: the top-right plot shows the three-dimensional bivariate density, the top-left plot the contour plot of the distribution (seen from above). The lower plots show the cumulative distribution function from two views, as a three-dimensional plot and as a contour plot."----
f1 <- nbvpdf(0, 0, 1, 1, 0)
# f1 %$% matrix.variances
plot(f1,
  all = TRUE, n = 20,
  main = "No correlation"
)


## ----negcor,echo=FALSE,fig.cap="A bivariate Normal distribution with a negative  correlation of -0.6. Shown are four plots: the top-right plot shows the three-dimensional bivariate density, the top-left plot the contour plot of the distribution (seen from above). The lower plots show the cumulative distribution function from two views, as a three-dimensional plot and as a contour plot."----
f3 <- nbvpdf(0, 0, 1, 1, -0.6)
# f1 %$% matrix.variances
plot(f3,
  all = TRUE, n = 20,
  main = "Correlation -0.6"
)


## ----poscor,echo=FALSE,fig.cap="A bivariate Normal distribution with a positive  correlation of 0.6. Shown are four plots: the top-right plot shows the three-dimensional bivariate density, the top-left plot the contour plot of the distribution (seen from above). The lower plots show the cumulative distribution function from two views, as a three-dimensional plot and as a contour plot."----
f2 <- nbvpdf(0, 0, 1, 1, 0.6)
# f1 %$% matrix.variances
plot(f2,
  all = TRUE, n = 20,
  main = "Correlation 0.6"
)


## ---------------------------------------
## define a variance-covariance matrix:
Sigma <- matrix(c(5^2, 5 * 10 * .6, 5 * 10 * .6, 10^2),
  byrow = FALSE, ncol = 2
)
## generate data:
u <- mvrnorm(
  n = 100,
  mu = c(0, 0),
  Sigma = Sigma
)
head(u, n = 3)


## ----poscordata,echo=FALSE,fig.cap="The relationship between two positively correlated random variables, generated by simulating data using the R function mvrnorm from the MASS library."----
ggplot(tibble(u_1 = u[, 1], u_2 = u[, 2]), aes(u_1, u_2)) +
  geom_point()


## ---------------------------------------
Sigma


## ---------------------------------------
## sds:
(sds <- c(5, 10))
## diagonal matrix:
(sd_diag <- diag(sds))
## correlation matrix:
(corrmatrix <- matrix(c(1, 0.6, 0.6, 1), ncol = 2))


## ---------------------------------------
sd_diag %*% corrmatrix %*% sd_diag


## ---------------------------------------
BinLik <- function(theta) {
  choose(10, 8) * theta^8 * (1 - theta)^2
}
integrate(BinLik, lower = 0, upper = 1)$value


## Practice using the ```pnorm``` function - Part 1


## Practice using the ```pnorm``` function - Part 2


## ----echo=FALSE-------------------------
mu <- round(rnorm(1, mean = 51, sd = 2), digits = 0)
sigma <- round(runif(1, min = 2, max = 4), digits = 0)

q <- round(runif(1, min = 40, max = 50))
q1 <- round(runif(1, min = 51, max = 60))


p1 <- round(pnorm(q, mean = mu, sd = sigma), digits = 3)
p2 <- round(1 - pnorm(q, mean = mu, sd = sigma), digits = 3)
p3 <- round(1 - pnorm(q1, mean = mu, sd = sigma), digits = 3)


## Practice using the ```pnorm``` function - Part 3


## Practice using the ```qnorm``` function - Part 1


## Practice using the ```qnorm``` function - Part 2


## Practice getting summaries from samples - Part 1


## ---------------------------------------
data_gen1 <- rnorm(1000, 300, 200)


## Practice getting summaries from samples - Part 2.


## ---------------------------------------
data_gen1 <- rtnorm(1000, 300, 200, a = 0)


## Practice with a variance-covariance matrix for a bivariate distribution.

