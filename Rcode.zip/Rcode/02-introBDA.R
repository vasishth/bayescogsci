## ----betas2, echo=FALSE,  fig.cap = "Examples of Beta distributions with different parameters.", tidy = FALSE, fig.height = 6----
## , fig.width = 2.1, fig.height = 2.1
ab <- tibble(
  a = c(
    seq(1, 10, 3),
    seq(10, 1, -3)
  ),
  b = c(seq(1, 10, 3), seq(1, 10, 3))
)
plots <- pmap(ab, function(a, b) {
  (ggplot(data = tibble(theta = c(0, 1)), aes(theta)) +
    stat_function(
      fun = dbeta,
      args = list(shape1 = a, shape2 = b)
    ) +
    ylab("density") +
      coord_cartesian(ylim = c(0, 5))+
    ggtitle(paste0("Beta(a = ", a, ", b = ", b,")")))
})

cowplot::plot_grid(plotlist= plots, ncol=2)


## ---------------------------------------
qbeta(c(0.025, 0.975), shape1 = 4, shape2 = 4)


## ---------------------------------------
qbeta(c(0.025, 0.975), shape1 = 10, shape2 = 10)


## ---------------------------------------
PostFun <- function(theta) {
  theta^83 * (1 - theta)^23
}
(AUC <- integrate(PostFun, lower = 0, upper = 1)$value)


## ---------------------------------------
PostFun <- function(theta) {
  theta^83 * (1 - theta)^23 / AUC
}
round(integrate(PostFun, lower = 0, upper = 1)$value, 2)


## ----postbeta-viz,echo=FALSE,fig.cap = "(ref:postbeta-viz)"----
## Likelihood
k <- 80
n <- 100
## Prior
a <- 4
b <- 4
binom_lh <- function(theta) {
dbinom(x=k, size =n, prob = theta)
}

K <- integrate(f = binom_lh, lower = 0, upper = 1)$value

binom_scaled_lh <- function(theta) 1/K * binom_lh(theta)
  
p_beta <- ggplot(data = tibble(theta = c(0, 1)), aes(theta)) +
  stat_function(
    fun = dbeta,
    args = list(shape1 = a, shape2 = b),
    aes(linetype = "Prior")
  ) +
  ylab("density") +
  stat_function(
    fun = dbeta,
    args = list(shape1 = k + a, shape2 = n - k + b), aes(linetype = "Posterior")
  ) +
  stat_function(
    fun = binom_scaled_lh,
    aes(linetype = "Scaled likelihood")
  ) +
  theme_bw() +
  theme(legend.title = element_blank())
p_beta


## ---------------------------------------
qbeta(c(0.025, 0.975), shape1 = 84, shape2 = 24)


## ----postbetavizvar, echo=FALSE,fig.cap = "The (scaled) likelihood, prior, and posterior in the Beta-Binomial conjugate example, for different uncertainties in the prior. The likelihood is scaled to integrate to 1 to make its comparison easier.  "----
## Likelihood
k <- 80
n <- 100

## Prior
ab <- list(
   c(a=2,b=2),
   c(a=3,b=3),
   c(a=6,b=6),
   c(a=21,b=21))
plots <- map(ab, function(p){
(ggplot(data = tibble(theta = c(0, 1)), aes(theta)) +
  stat_function(
    fun = dbeta,
    args = list(shape1 = p[1], shape2 = p[2]),
    aes(linetype = "Prior")
  ) +
  ylab("density") +
  stat_function(
    fun = dbeta,
    args = list(shape1 = k + p[1], shape2 = n - k + p[2]), aes(linetype = "Posterior")
  ) +
   stat_function(
    fun = binom_scaled_lh,
    aes(linetype = "Scaled likelihood")
  ) +
    theme(legend.position =  "none") +
    ggtitle(paste0("Prior:\nBeta(a = ", p[1], ", b = ", p[2],")")))
  })

legend <- cowplot::get_legend(
  # create some space to the left of the legend
  plots[[1]] + theme(legend.position = "bottom", legend.title = element_blank())
)
p <- cowplot::plot_grid(plots[[1]], plots[[2]], plots[[3]], plots[[4]], ncol = 2)

cowplot::plot_grid(p, cowplot::ggdraw(legend), ncol =1, rel_heights = c(0.9,0.1))



## Deriving Bayes' rule


## Conjugate forms 1


## Conjugate forms 2


## Conjugate forms 3


## Conjugate forms 4


## ---- echo=FALSE,eval=FALSE,fig.cap="\\label{fig1}The Gamma prior for the parameter theta."----
## x <- 0:200
## plot(x, dgamma(x, 10000 / 225, 100 / 225),
##   type = "l", lty = 1,
##   main = "Gamma prior", ylab = "density",
##   cex.lab = 2, cex.main = 2, cex.axis = 2
## )


## ---------------------------------------
### load data:
data <- c(115, 97, 79, 131)

a.star <- function(a, data) {
  return(a + sum(data))
}

b.star <- function(b, n) {
  return(b + n)
}

new.a <- a.star(10000 / 225, data)
new.b <- b.star(100 / 225, length(data))

### post. mean
(post.mean <- new.a / new.b)
### post. var:
(post.var <- new.a / (new.b^2))


## ---------------------------------------
new.data <- c(200)


## ---------------------------------------
new.a.2 <- a.star(new.a, new.data)
new.b.2 <- b.star(new.b, length(new.data))

### new mean
(new.post.mean <- new.a.2 / new.b.2)
### new var:
(new.post.var <- new.a.2 / (new.b.2^2))

