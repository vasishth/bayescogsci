## ---- message = FALSE-------------------
data("df_sbi")
(df_sbi <- df_sbi %>%
  mutate(study_id = 1:n()))


## ---------------------------------------
priors <- c(
  prior(normal(0, 100), class = Intercept),
  prior(normal(0, 100), class = sd)
)


## ----cache=TRUE, message = FALSE--------
fit_sbi <- brm(effect | resp_se(`SE`, sigma = FALSE) ~ 1
               + (1 | study_id),
  data = df_sbi,
  prior = priors,
  control = list(
    adapt_delta = .999,
    max_treedepth = 12
  )
)


## ---- eval = FALSE----------------------
## fit_sbi


## ---- echo = FALSE----------------------
short_summary(fit_sbi)


## **What happens if we set `sigma = TRUE`?**


## ----cache=TRUE, message = FALSE--------
priors2 <- c(
  prior(normal(0, 100), class = Intercept),
  prior(normal(0, 100), class = sigma)
)
fit_sbi_sigma <- brm(effect | resp_se(`SE`, sigma = TRUE) ~ 1,
  data = df_sbi,
  prior = priors2,
  control = list(
    adapt_delta = .999,
    max_treedepth = 12
  )
)


## ---- eval = TRUE-----------------------
posterior_summary(fit_sbi_sigma,
                  variable = c("b_Intercept", "sigma"))


## ----forest, fig.cap = "(ref:forest)"----
# First, change the format of the data
# so that it looks like the output of brms
df_sbi <- df_sbi %>%
  mutate(
    Q2.5 = effect - 2 * SE,
    Q97.5 = effect + 2 * SE,
    Estimate = effect,
    type = "original"
  )

# Extract the meta-analytical estimate:
df_Intercept <- posterior_summary(fit_sbi,
                                  variable = c("b_Intercept")) %>%
  as.data.frame() %>%
  mutate(publication = "M.A. estimate", type = "")

# For the pooled estimated effect of the individual studies
# we need to do the following:
# meta-analytical estimate (intercept) + adjustments:
# 1. extract the meta-analytical estimate:
intercept <- c(as_draws_df(fit_sbi)$b_Intercept)
# 2. extract the adjustments
adj_names <- paste0("r_study_id[",
                    unique(df_sbi$study_id),
                    ",Intercept]")
adj <- as.matrix(as_draws_df(fit_sbi)[adj_names])
# 3. add them:
by_study <- as_tibble(intercept + adj)
# Summarize them by getting a table with the mean and the
# quantiles for each column and then binding them.
df_model <- lapply(by_study, function(x) {
  tibble(
    Estimate = mean(x),
    Q2.5 = quantile(x, .025),
    Q97.5 = quantile(x, .975)
  )
}) %>%
  bind_rows() %>%
  # Add a column to identify the posteriors,
  # and another column to id the publication:
  mutate(
    type = "adjusted",
    publication = df_sbi$publication
  )
# Bind the original data,
# the adjusted estimates and the m.a. estimate:
bind_rows(df_sbi, df_model, df_Intercept) %>%
  # Plot:
  ggplot(aes(
    x = Estimate,
    y = publication,
    xmin = Q2.5,
    xmax = Q97.5,
    color = type
  )) +
  geom_point(position = position_dodge(.5)) +
  geom_errorbarh(position = position_dodge(.5)) +
  # Add the meta-analytical estimate and CrI
  geom_vline(xintercept = df_Intercept$Q2.5,
             linetype = "dashed",
             alpha = .3) +
  geom_vline(xintercept = df_Intercept$Q97.5,
             linetype = "dashed",
             alpha = .3) +
  geom_vline(xintercept = df_Intercept$Estimate,
             linetype = "dashed",
             alpha = .5) +
  scale_color_discrete(breaks = c("adjusted","original"))


## ---- echo = FALSE----------------------
ma0 <- system.file("stan_models",
                   "meta-analysis0.stan",
                   package = "bcogsci")


## NA

## ---- message=FALSE, results="hide"-----
ma0 <- system.file("stan_models",
                   "meta-analysis0.stan",
                   package = "bcogsci")
ls_sbi <- list(N = nrow(df_sbi),
               effect = df_sbi$effect,
               SE = df_sbi$SE,
               study_id = df_sbi$study_id)
fit_sbi0 <- stan(
  file = ma0,
  data = ls_sbi,
   control = list(
    adapt_delta = .999,
    max_treedepth = 12
  )
)


## ---------------------------------------
pairs(fit_sbi0, pars = c("zeta", "tau"))


## ---- echo = FALSE----------------------
ma1 <- system.file("stan_models",
                   "meta-analysis1.stan",
                   package = "bcogsci") 


## NA

## ---- message=FALSE, results="hide"-----
ma1 <- system.file("stan_models",
                   "meta-analysis1.stan",
                   package = "bcogsci") 
fit_sbi1 <- stan(
  file = ma1,
  data = ls_sbi,
   control = list(
    adapt_delta = .999,
    max_treedepth = 12
  )
)


## ---------------------------------------
print(fit_sbi1, pars = c("zeta", "tau"))


## ---- echo = FALSE----------------------
ma2 <- system.file("stan_models",
                   "meta-analysis2.stan",
                   package = "bcogsci")


## NA

## ---- message=FALSE, results="hide"-----
ma2 <- system.file("stan_models",
                   "meta-analysis2.stan",
                   package = "bcogsci")
fit_sbi2 <- stan(
  file = ma2,
  data = ls_sbi,
  control = list(adapt_delta = .9)
)


## ---------------------------------------
print(fit_sbi2, pars = c("zeta", "tau"))


## ---------------------------------------
data("df_VOTmandarin")
head(df_VOTmandarin)


## ----relmeanVOTvdur, fig.cap = "The relationship between mean voice onset time and centered mean vowel duration",  message = FALSE----
ggplot(df_VOTmandarin, aes(y = meanVOT, x = c_meanvdur)) +
  geom_point() +
  geom_smooth(method = "lm")


## ----votbrms, message = FALSE, eval = TRUE----
priors <- c(
  prior(normal(0, 200), class = Intercept),
  prior(normal(0, 10), class = b),
  prior(normal(0, 50), class = sigma)
)
fit_mvot <- brm(meanVOT ~ c_meanvdur,
  data = df_VOTmandarin,
  family = gaussian(),
  prior = priors
)


## ----lmplotstanplot2, message = FALSE, eval = TRUE,fig.cap = "The posterior distribution of the slope in the linear model, modeling the effect of centered mean vowel duration on mean voice onset time."----
mcmc_plot(fit_mvot, variable = "^b_c_meanvdur", regex = TRUE, type = "hist")


## ---------------------------------------
priors_me <- c(
  prior(normal(50, 50), class = Intercept),
  prior(normal(0, 10), class = b),
  prior(normal(0, 10), class = meanme),
  prior(normal(0, 30), class = sdme),
  prior(normal(0, 30), class = sigma)
)


## ----fitmemodel ,message=FALSE, results = "hide"----
fit_mvotme <- brm(meanVOT | resp_se(seVOT, sigma = TRUE) ~
                    me(c_meanvdur, sevdur),
                  data = df_VOTmandarin,
                  family = gaussian(),
                  prior = priors_me,
                  control = list(max_treedepth = 15,
                                 adapt_delta = .99999),
                  iter = 5000
                  )


## ---- eval = FALSE----------------------
## fit_mvotme

## ---- echo = FALSE----------------------
short_summary(fit_mvotme)


## ----meplotstanplot, echo=FALSE,message = FALSE,fig.cap = "The posterior distribution of the slope in the measurement error model, modeling the effect of centered mean vowel duration on mean voice onset time."----
mcmc_plot(fit_mvotme, variable = "^bsp", regex = TRUE, type = "hist")


## ---- echo = FALSE----------------------
me <- system.file("stan_models",
                   "me.stan",
                   package = "bcogsci")


## NA

## ---- message=FALSE, results="hide", cache = FALSE, warning= FALSE, eval = !file.exists("dataR/fitmvotme.RDS")----
me <- system.file("stan_models",
                   "me.stan",
                   package = "bcogsci")
ls_me <- list(N = nrow(df_VOTmandarin),
              y = df_VOTmandarin$meanVOT,
              SE_y = df_VOTmandarin$seVOT,
              x = df_VOTmandarin$c_meanvdur,
              SE_x = df_VOTmandarin$sevdur)
fit_mvotme_stan <- stan(
  file = me,
  data = ls_me,
     control = list(max_treedepth = 15,
                    adapt_delta = .99999),
  iter = 5000
)

## ---- echo= FALSE-----------------------
if(!file.exists("dataR/fitmvotme.RDS")){
  saveRDS(fit_mvotme_stan, "dataR/fitmvotme.RDS")
} else {
  fit_mvotme_stan <- readRDS("dataR/fitmvotme.RDS")
}


## ---------------------------------------
print(fit_mvotme_stan , pars = c("alpha", "beta", "sigma"))


## Meta-analysis data of picture-word interference data


## ---------------------------------------
data("df_buerki")
head(df_buerki)
df_buerki <- subset(df_buerki, se > 0.60)


## Measurement error model for English VOT data


## ---------------------------------------
data("df_VOTenglish")
head(df_VOTenglish)

