## ---- echo=FALSE, message=FALSE---------
data("df_contrasts4")
table4 <- df_contrasts4 %>% group_by(A, B) %>% # plot interaction
  summarize(N = length(DV), M = mean(DV), SD = sd(DV), SE = SD / sqrt(N))
GM <- mean(table4$M) # Grand Mean

table4a <- as.data.frame(table4)
names(table4a) <- c(
  "Factor A", "Factor B", "N data",
  "Means", "Std. dev.", "Std. errors"
)


## ----twobytwosimdatFig, fig=TRUE, include=TRUE, echo=FALSE, cache=FALSE, fig.width=5, fig.height=3, fig.cap = "Means and error bars (showing standard errors) for a simulated data set with a two-by-two  between-subjects factorial design."----
(plot2 <- qplot(x = A, y = M, group = B, linetype = B, shape = B, data = table4, geom = c("point", "line")) +
  labs(y = "Dependent variable", x = "Factor A", colour = "Factor B", linetype = "Factor B", shape = "Factor B") +
  geom_errorbar(aes(max = M + SE, min = M - SE), width = 0))


## ----cTab4Means, echo=FALSE, results = "asis"----
# apa_table(table4a, placement="b", digits=1,
#    caption="Summary statistics per condition for the simulated data.")
kable(table4a,
  digits = 1, booktabs = TRUE, vline = "", # format="latex",
  caption = "Summary statistics per condition for the simulated data."
)


## ---- echo=TRUE, message=FALSE----------
# define sum contrasts:
contrasts(df_contrasts4$A) <- contr.sum(2)
contrasts(df_contrasts4$B) <- contr.sum(2)
# frequentist LM
fit_AB_mr.sum <- lm(DV ~ 1 + A * B, data = df_contrasts4)

## ---- echo=TRUE, message=FALSE, results="hide"----
# Bayesian LM
fit_AB.sum <- brm(DV ~ 1 + A * B,
  data = df_contrasts4,
  family = gaussian(),
  prior = c(
    prior(normal(20, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_AB.sum)


## ----table18, echo=FALSE, eval=TRUE, results="asis"----
tab18 <- data.frame(round(coef(summary(fit_AB_mr.sum)), 3))
names(tab18) <- c("Estimate", "Std. Error", "t", "p")
tab18 <- cbind(Predictor = row.names(tab18), tab18)
row.names(tab18) <- NULL
# apa_table(tab18, placement="!htbp", caption="Regression analysis with sum contrasts.")
# apa_table(apa_print(fit_AB_mr.sum, digits=0, est_name="Estimate")$table, placement="h",
#    caption="Regression analysis with sum contrasts.")
kable(tab18, booktabs = T, vline = "", caption = "Regression analysis with sum contrasts.") # format="latex",


## ---- echo=FALSE------------------------
ginv2 <- function(x) { # define a function to make the output nicer
  fractions(provideDimnames(ginv(x), base = dimnames(x)[2:1]))
}


## ---- echo=TRUE, message=FALSE----------
t(fractions(HcInt <- rbind(
  A = c(F1 = 1 / 4, F2 = 1 / 4, F3 = -1 / 4, F4 = -1 / 4),
  B = c(F1 = 1 / 4, F2 = -1 / 4, F3 = 1 / 4, F4 = -1 / 4),
  AxB = c(F1 = 1 / 4, F2 = -1 / 4, F3 = -1 / 4, F4 = 1 / 4)
)))
(XcInt <- ginv2(HcInt))
contrasts(df_contrasts3$F) <- XcInt

## ---- echo=TRUE, message=FALSE, results="hide"----
fit_F4.sum <- brm(DV ~ 1 + F,
  data = df_contrasts3,
  family = gaussian(),
  prior = c(
    prior(normal(20, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_F4.sum)


## ---- echo=TRUE, message=FALSE----------
hAxB <- hypr(
  A = (F1 + F2) / 2 ~ (F3 + F4) / 2,
  B = (F1 + F3) / 2 ~ (F2 + F4) / 2,
  AxB = (F1 - F2) / 2 ~ (F3 - F4) / 2
)
hAxB
contrasts(df_contrasts3$F) <- contr.hypothesis(hAxB)

## ---- echo=TRUE, message=FALSE, results="hide"----
fit_F4hypr <- brm(DV ~ 1 + F,
  data = df_contrasts3,
  family = gaussian(),
  prior = c(
    prior(normal(20, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_F4hypr)


## ---------------------------------------
A <- ifelse(df_contrasts3$F %in% c("F1", "F2"), -1, 1)
B <- ifelse(df_contrasts3$F %in% c("F1", "F3"), -1, 1)


## ---------------------------------------
AxB <- A * B


## ---------------------------------------
A <- ifelse(df_contrasts3$F %in% c("F1", "F2"), -1 / 2, 1 / 2)
B <- ifelse(df_contrasts3$F %in% c("F1", "F3"), -1 / 2, 1 / 2)
## scale has changed:
(AxB <- A * B)
## same scale as main effects:
(AxB <- A * B * 2)


## ---- echo=TRUE, message=FALSE----------
t(fractions(HcNes <- rbind(
  B = c(F1 = 1 / 2, F2 = -1 / 2, F3 = 1 / 2, F4 = -1 / 2),
  B1xA = c(F1 = -1, F2 = 0, F3 = 1, F4 = 0),
  B2xA = c(F1 = 0, F2 = -1, F3 = 0, F4 = 1)
)))
(XcNes <- ginv2(HcNes))
contrasts(df_contrasts3$F) <- XcNes

## ---- echo=TRUE, message=FALSE, results="hide"----
fit_Nest <- brm(DV ~ 1 + F,
  data = df_contrasts3,
  family = gaussian(),
  prior = c(
    prior(normal(20, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_Nest)


## ---- echo=TRUE, message=FALSE, results="hide"----
contrasts(df_contrasts4$A) <- c(-0.5, +0.5)
contrasts(df_contrasts4$B) <- c(+0.5, -0.5)
fit_Nest2 <- brm(DV ~ 1 + B / A,
  data = df_contrasts4,
  family = gaussian(),
  prior = c(
    prior(normal(20, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_Nest2)


## ---- echo=TRUE, message=FALSE----------
hNest <- hypr(
  B = (F1 + F3) / 2 ~ (F2 + F4) / 2,
  B1xA = F3 ~ F1,
  B2xA = F4 ~ F2
)
hNest
contrasts(df_contrasts3$F) <- contr.hypothesis(hNest)

## ---- echo=TRUE, message=FALSE, results="hide"----
fit_NestHypr <- brm(DV ~ 1 + F,
  data = df_contrasts3,
  family = gaussian(),
  prior = c(
    prior(normal(20, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_NestHypr)


## ---- echo=TRUE, message=FALSE----------
hNest2 <- hypr(
  A = (F1 + F2) / 2 ~ (F3 + F4) / 2,
  A1xB = F2 ~ F1,
  A2xB = F4 ~ F3
)
hNest2
contrasts(df_contrasts3$F) <- contr.hypothesis(hNest2)

## ---- echo=TRUE, message=FALSE, results="hide"----
fit_Nest2Hypr <- brm(DV ~ 1 + F,
  data = df_contrasts3,
  family = gaussian(),
  prior = c(
    prior(normal(20, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_Nest2Hypr)


## ---- echo=TRUE, message=FALSE----------
contrasts(df_contrasts4$A) <- contr.treatment(2)
contrasts(df_contrasts4$B) <- contr.treatment(2)
XcTr <- df_contrasts4 %>%
  group_by(A, B) %>%
  summarise() %>%
  model.matrix(~ 1 + A * B, .) %>%
  as.data.frame() %>%
  as.matrix()
rownames(XcTr) <- c("A1_B1", "A1_B2", "A2_B1", "A2_B2")
XcTr


## ---- echo=TRUE-------------------------
htr <- hypr() # initialize empty hypr object
cmat(htr) <- XcTr # assign contrast matrix to hypr object
htr # look at the resulting hypothesis matrix


## ---- echo=TRUE-------------------------
t(ginv2(XcTr))


## ---- echo=TRUE, message=FALSE----------
contrasts(df_contrasts4$A) <- contr.sum(2)
contrasts(df_contrasts4$B) <- contr.sum(2)
XcSum <- df_contrasts4 %>%
  group_by(A, B) %>%
  summarise() %>%
  model.matrix(~ 1 + A * B, .) %>%
  as.data.frame() %>%
  as.matrix()
rownames(XcSum) <- c("A1_B1", "A1_B2", "A2_B1", "A2_B2")

hsum <- hypr() # initialize empty hypr object
cmat(hsum) <- XcSum # assign contrast matrix to hypr object
hsum # look at the resulting hypothesis matrix


## ---- echo=TRUE-------------------------
data("df_contrasts5")
str(df_contrasts5)


## ---- echo=TRUE-------------------------
(contrasts(df_contrasts5$F) <- c(-0.5, +0.5))


## ---- echo=TRUE, message=FALSE, results="hide"----
fit_RT_F <- brm(RT ~ 1 + F,
  data = df_contrasts5,
  family = gaussian(),
  prior = c(
    prior(normal(200, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_RT_F)


## ---- echo=FALSE, message=FALSE, results="hide"----
tab5 <- df_contrasts5 %>%
  group_by(F) %>%
  summarize(M = mean(RT), SE = sd(RT) / sqrt(n()))

## ----figRTF, fig=TRUE, include=TRUE, echo=FALSE, cache=FALSE, fig.width=2.5, fig.height=3, fig.cap = "Means and error bars (showing standard errors) for a simulated data set of response times for two different groups of subjects, who have obtained a training in lexical decisions (F2) versus have obtained a control training (F1)."----
(plot_RT <- ggplot(data = tab5, aes(x = F, y = M, ymin = M - SE, ymax = M + SE)) +
  ## geom_bar(stat = "identity") +
  geom_errorbar(width = 0.2) +
  labs(y = "Response times [ms]", x = "Group (F)"))


## ---- echo=TRUE, message=FALSE----------
df_contrasts5 %>%
  group_by(F) %>%
  summarize(M.IQ = mean(IQ))


## ---- echo=TRUE, message=FALSE, results="hide"----
df_contrasts5$IQ.c <- df_contrasts5$IQ - mean(df_contrasts5$IQ)
fit_RT_F_IQ <- brm(RT ~ 1 + F + IQ.c,
  data = df_contrasts5,
  family = gaussian(),
  prior = c(
    prior(normal(200, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_RT_F_IQ)


## ----figRTFIQ, fig=TRUE, include=TRUE, echo=FALSE, cache=FALSE, message=FALSE, fig.width=4.5, fig.height=3, fig.cap = "Response times as a function of individual IQ for two groups with a lexical decision training (F2) versus a control training (F1). Points indicate individual subjects, and lines with error bands indicate linear regression lines."----
(plot_RT_IQ <- ggplot(data = df_contrasts5, aes(x = IQ, y = RT, colour = F, linetype = F)) +
  geom_point() +
  geom_smooth(method = "lm") +
  labs(y = "Response times [ms]"))


## ---- echo=TRUE, message=FALSE, results="hide"----
fit_RT_FxIQ <- brm(RT ~ 1 + F * IQ.c,
  data = df_contrasts5,
  family = gaussian(),
  prior = c(
    prior(normal(200, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_RT_FxIQ)


## ---- echo=TRUE-------------------------
data("df_contrasts6")
levels(df_contrasts6$F) <- c("simple", "complex")
str(df_contrasts6)


## ----figRTFxIQ, fig=TRUE, include=TRUE, echo=FALSE, cache=FALSE, message=FALSE, fig.width=4.5, fig.height=3, fig.cap = "Response times as a function of individual IQ for two groups performing a simple versus a complex task. Points indicate individual subjects, and lines with error bands indicate linear regression lines."----
(plot_RTxIQ <- ggplot(data = df_contrasts6, aes(x = IQ, y = RT, colour = F, linetype = F)) +
  geom_point() +
  geom_smooth(method = "lm") +
  labs(y = "Response times [ms]"))


## ---- echo=TRUE, message=FALSE, results="hide"----
contrasts(df_contrasts6$F) <- c(-0.5, +0.5)
df_contrasts6$IQ.c <- df_contrasts6$IQ - mean(df_contrasts6$IQ)
fit_RT_FxIQ2 <- brm(RT ~ 1 + F * IQ.c,
  data = df_contrasts6,
  family = gaussian(),
  prior = c(
    prior(normal(200, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_RT_FxIQ2)


## ---- echo=TRUE, message=FALSE, results="hide"----
fit_RT_FnIQ2 <- brm(RT ~ 1 + F / IQ.c,
  data = df_contrasts6,
  family = gaussian(),
  prior = c(
    prior(normal(200, 50), class = Intercept),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 50), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_RT_FnIQ2)


## ---------------------------------------
df_postSamp_RT_FxIQ2 <- as_draws_df(fit_RT_FxIQ2)
str(df_postSamp_RT_FxIQ2)


## ---- echo=TRUE-------------------------
contrasts(df_contrasts6$F)


## ---------------------------------------
df_postSamp_RT_FxIQ2$b_IQ.c_simple <-
  df_postSamp_RT_FxIQ2$b_IQ.c - 0.5 * df_postSamp_RT_FxIQ2$`b_F1:IQ.c`


## ---------------------------------------
df_postSamp_RT_FxIQ2$b_IQ.c_complex <-
  df_postSamp_RT_FxIQ2$b_IQ.c + 0.5 * df_postSamp_RT_FxIQ2$`b_F1:IQ.c`


## ---------------------------------------
c(
  IQc.c_simple = mean(df_postSamp_RT_FxIQ2$b_IQ.c_simple),
  IQc.c_complex = mean(df_postSamp_RT_FxIQ2$b_IQ.c_complex)
)


## ---------------------------------------
data("df_contrasts7")
str(df_contrasts7)


## ----cTab7Means, echo=FALSE, message=FALSE, results = "asis"----
table7 <- df_contrasts7 %>% group_by(A, B) %>% # plot interaction
  summarize(N = length(pDV), M = mean(pDV))
GM <- mean(table7$M) # Grand Mean
table7a <- as.data.frame(table7)
names(table7a) <- c(
  "Factor A", "Factor B", "N data",
  "Means"
)
# apa_table(table7a, placement="b", digits=2,
#    caption="Summary statistics per condition for the simulated data.")
kable(table7a, booktabs = T, vline = "", digits = 2, caption = "Summary statistics per condition for the simulated data.") # format="latex",


## ---- echo=TRUE, message=FALSE, results="hide"----
contrasts(df_contrasts7$A) <- c(-0.5, +0.5)
contrasts(df_contrasts7$B) <- c(-0.5, +0.5)
fit_pDV_AB.sum <- brm(pDV ~ 1 + A * B,
  data = df_contrasts7,
  family = bernoulli(link = "logit"),
  prior = c(
    prior(normal(0, 3), class = Intercept),
    prior(normal(0, 3), class = b)
  )
)

## ---- echo=TRUE-------------------------
fixef(fit_pDV_AB.sum)


## ---------------------------------------
ME_A <- ifelse(df_contrasts7$A == "A1", 1, -1)
ME_B <- ifelse(df_contrasts7$B == "B1", 1, -1)


## ---- echo=TRUE, message=FALSE, results="hide"----
tab7 <- df_contrasts7 %>%
  group_by(A, B) %>%
  summarize() %>%
  model.matrix(~ A * B, data = .) %>%
  as.data.frame()
row.names(tab7) <- c("A1_B1", "A1_B2", "A2_B1", "A2_B2")

## ---- echo=TRUE-------------------------
tab7


## ---- echo=TRUE-------------------------
df_postSamp_pDV <- as_draws_df(fit_pDV_AB.sum)
str(df_postSamp_pDV)


## ---- echo=TRUE-------------------------
df_postSamp_pDV$A1_B1 <-
  1 * df_postSamp_pDV$b_Intercept +
  -0.5 * df_postSamp_pDV$b_A1 +
  -0.5 * df_postSamp_pDV$b_B1 +
  +0.25 * df_postSamp_pDV$`b_A1:B1`

df_postSamp_pDV$A1_B2 <-
  1 * df_postSamp_pDV$b_Intercept +
  -0.5 * df_postSamp_pDV$b_A1 +
  +0.5 * df_postSamp_pDV$b_B1 +
  -0.25 * df_postSamp_pDV$`b_A1:B1`
df_postSamp_pDV$A2_B1 <-
  1 * df_postSamp_pDV$b_Intercept +
  +0.5 * df_postSamp_pDV$b_A1 +
  -0.5 * df_postSamp_pDV$b_B1 +
  -0.25 * df_postSamp_pDV$`b_A1:B1`
df_postSamp_pDV$A2_B2 <-
  1 * df_postSamp_pDV$b_Intercept +
  +0.5 * df_postSamp_pDV$b_A1 +
  +0.5 * df_postSamp_pDV$b_B1 +
  +0.25 * df_postSamp_pDV$`b_A1:B1`


## ---- echo=TRUE-------------------------
colMeans(as.data.frame(df_postSamp_pDV)[, c("A1_B1", "A1_B2", "A2_B1", "A2_B2")])


## ---- echo=TRUE-------------------------
df_postSamp_pDV$p_A1_B1 <- plogis(df_postSamp_pDV$A1_B1)
df_postSamp_pDV$p_A1_B2 <- plogis(df_postSamp_pDV$A1_B2)
df_postSamp_pDV$p_A2_B1 <- plogis(df_postSamp_pDV$A2_B1)
df_postSamp_pDV$p_A2_B2 <- plogis(df_postSamp_pDV$A2_B2)


## ---- echo=TRUE-------------------------
colMeans(as.data.frame(df_postSamp_pDV)[, c(
  "p_A1_B1", "p_A1_B2",
  "p_A2_B1", "p_A2_B2"
)])


## ---------------------------------------
conditional_effects(fit_pDV_AB.sum, robust = FALSE)[]


## ----figpDV, fig=TRUE, include=TRUE, echo=TRUE, cache=FALSE, fig.width=3.5, fig.height=3, fig.cap = "(ref:figpDv)"----
plot(conditional_effects(fit_pDV_AB.sum, effects = "A:B", robust = FALSE))[[1]] + 
  labs(
    y = "Success probability"
  )


## ANOVA coding for a four-condition design.


## ---------------------------------------
library(bcogsci)
data("df_persianE1")
dat1 <- df_persianE1
head(dat1)


## ANOVA and nested comparisons in a $2\times 2\times 2$ design


## ---------------------------------------
library(bcogsci)
data("df_dillonrep")

