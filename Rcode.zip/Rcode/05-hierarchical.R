## **Finitely exchangeable random variables**


## %% hierarchical model:

## \begin{tikzpicture}

## 
## \matrix[matrix of math nodes, column sep=20pt, row sep=20pt] (mat)

## {

##     & \theta, \tau & \\

##     \theta_1 & \ldots & \theta_N \\

##     y_{1} & \ldots & y_{N} \\

##     & \sigma & \\

## };

## 
## \foreach \column in {1, 3}

## {

##     \draw[->,>=latex] (mat-1-2) -- (mat-2-\column);

##     \draw[->,>=latex] (mat-2-\column) -- (mat-3-\column);

##     \draw[<-,>=latex] (mat-3-\column) -- (mat-4-2);

## }

## 
## \node[anchor=east] at ([xshift =-40pt]mat-2-1)

## {~~~Partial pooling: $\theta_n \sim \text{N}(\theta, \tau)$};

## \node[anchor=east] at ([xshift =-40pt]mat-3-1)

## {$y_{n} \sim \text{N}(\theta_n, \sigma)$};

## 
## \end{tikzpicture}

## 

## %% independent (no pooling) model:

## \begin{tikzpicture}

## 
## \matrix[matrix of math nodes, column sep=20pt, row sep=20pt] (mat)

## {

## %    & \theta, \tau & \\

##     \theta_1 & \ldots & \theta_N \\

##     y_{1} & \ldots & y_{N} \\

##     \sigma_1 & \ldots & \sigma_N\\

## };

## 
## \foreach \column in {1, 3}

## {

##     \draw[->,>=latex] (mat-1-1) -- (mat-2-1);

##     \draw[->,>=latex] (mat-1-3) -- (mat-2-3);

##     \draw[->,>=latex] (mat-3-1) -- (mat-2-1);

##     \draw[->,>=latex] (mat-3-3) -- (mat-2-3);

## 
## }

## 
## \node[anchor=east] at ([xshift =-40pt]mat-3-1)

## {~~~~~~~No pooling: $y_{n} \sim \text{N}(\theta_n, \sigma_n)$};

## 
## \end{tikzpicture}

## 

## %% complete pooling model:

## 
## \begin{tikzpicture}

## 
## \matrix[matrix of math nodes, column sep=20pt, row sep=20pt] (mat)

## {

## %    & \theta, \tau & \\

##      & \theta &  \\

##     y_{1} & \ldots & y_{N} \\

##      & \sigma & \\

## };

## 
## \foreach \column in {1, 3}

## {

##     \draw[->,>=latex] (mat-1-2) -- (mat-2-1);

##     \draw[->,>=latex] (mat-1-2) -- (mat-2-3);

##     \draw[->,>=latex] (mat-3-2) -- (mat-2-1);

##     \draw[->,>=latex] (mat-3-2) -- (mat-2-3);

## 
## }

## 
## \node[anchor=east] at ([xshift =-40pt]mat-3-2)

## {Complete pooling: $y_{n} \sim \text{N}(\theta, \sigma)$};

## 
## \end{tikzpicture}

## 

## ---- echo = FALSE----------------------
N400_c <- c("Cz", "CP1", "CP2", "P3", "Pz", "P4", "POz")


## ----N400noun, results = "hold",fig.height= 4.5, fig.cap =  "(ref:N400noun)", echo = FALSE, warning = FALSE----
noun_s <- readRDS("data/noun_s.RDS") %>%
  mutate(
    constraint = ifelse(cond %in% c(0, 1),
      "Constraining", "Non-constraining"
    ),
    completion = ifelse(cond %in% c(0, 2), "a", "b"),
    predictability = case_when(
      cond == 0 ~ "high",
      cond == 1 ~ "low",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(
    channel == "neg", .time >= -1.6, .time <= 2.2,
    constraint == "Constraining"
  )

noun_s %>%
  ggplot(aes(x = .time, y = mean_s, linetype = predictability)) +
  labs(linetype = "Predictability", fill = "", color = "", x = "Time (s)", y = "Amplitude (\u03BCV)") +
  scale_x_continuous(limits = c(-.1, .8)) +
  coord_cartesian(xlim = c(-.1, .8), clip = "off") +
  geom_line(size = .5, na.rm = TRUE) +
  geom_vline(xintercept = .3, linetype = "dashed", color = "gray") +
  geom_vline(xintercept = .5, linetype = "dashed", color = "gray")


## ---- echo = FALSE----------------------
# hack:
select <- dplyr::select


## ---- message = FALSE-------------------
data("df_eeg")
(df_eeg <- df_eeg %>%
  mutate(c_cloze = cloze - mean(cloze)))
# Number of subjects
df_eeg %>%
  distinct(subj) %>%
  count()


## ----histn400, fig.cap="Histogram of the N400 averages for every trial, overlaid is a density plot of a normal distribution.", message=FALSE, fold = TRUE----
df_eeg %>% ggplot(aes(n400)) +
  geom_histogram(
    binwidth = 4,
    colour = "gray",
    alpha = .5,
    aes(y = ..density..)
  ) +
  stat_function(fun = dnorm, args = list(
    mean = mean(df_eeg$n400),
    sd = sd(df_eeg$n400)
  )) +
  xlab("Average voltage in microvolts for 
       the N400 spatiotemporal window")


## ---------------------------------------
samples <- extraDistr::rtnorm(20000, mean = 0, sd = 50, a = 0)
c(mean = mean(samples), sd = sd(samples))



## ---------------------------------------
quantile(samples, probs = c(0.025, .975))
# Analytically:
# c(qtnorm(.025, 0, 50, a = 0), qtnorm(.975, 0, 50, a = 0))


## ---- message = FALSE, results = "hide"----
fit_N400_cp <- brm(n400 ~ c_cloze,
  prior =
    c(
      prior(normal(0, 10), class = Intercept),
      prior(normal(0, 10), class = b, coef = c_cloze),
      prior(normal(0, 50), class = sigma)
    ),
  data = df_eeg
)


## ---- eval = FALSE----------------------
## fit_N400_cp


## ---- echo = FALSE----------------------
short_summary(fit_N400_cp)


## ----figurefitN400cp, fig.cap="(ref:figurefitN400cp)"----
plot(fit_N400_cp)


## ---- message = FALSE, results = "hide"----
fit_N400_np <- brm(n400 ~ 0 + factor(subj) + c_cloze:factor(subj),
  prior =
    c(
      prior(normal(0, 10), class = b),
      prior(normal(0, 50), class = sigma)
    ),
  data = df_eeg
)


## ---------------------------------------
# parameter name of beta by subject:
ind_effects_np <- paste0(
  "b_factorsubj",
  unique(df_eeg$subj), ":c_cloze"
)
beta_across_subj <- as_draws_df(fit_N400_np) %>% 
  #removes the meta data from the object
  as.data.frame() %>%
  select(ind_effects_np) %>%
    rowMeans()

# Calculate the average of these estimates
(grand_av_beta <- tibble(
  mean = mean(beta_across_subj),
  lq = quantile(beta_across_subj, c(.025)),
  hq = quantile(beta_across_subj, c(.975))
))


## ----message = FALSE--------------------
# make a table of beta's by subject
beta_by_subj <- posterior_summary(fit_N400_np,
  variable = ind_effects_np
) %>%
  as.data.frame() %>%
  mutate(subject = 1:n()) %>%
  ## reorder plot by magnitude of mean:
  arrange(Estimate) %>%
  mutate(subject = factor(subject, levels = subject))


## ----nopooling,fig.height=9.5, message=FALSE, fig.cap="(ref:nopooling)"----
# plot:
ggplot(
  beta_by_subj,
  aes(x = Estimate, xmin = Q2.5, xmax = Q97.5, y = subject)
) +
  geom_point() +
  geom_errorbarh() +
  geom_vline(xintercept = grand_av_beta$mean) +
  geom_vline(xintercept = grand_av_beta$lq, linetype = "dashed") +
  geom_vline(xintercept = grand_av_beta$hq, linetype = "dashed") +
  xlab("By-subject effect of cloze probability in microvolts")


## **Some important (and sometimes confusing) points:**


## ---- message = FALSE, results = "hide"----
prior_v <-
  c(
    prior(normal(0, 10), class = Intercept),
    prior(normal(0, 10), class = b, coef = c_cloze),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 20), class = sd, coef = Intercept, group = subj),
    prior(normal(0, 20), class = sd, coef = c_cloze, group = subj)
  )
fit_N400_v <- brm(n400 ~ c_cloze + (c_cloze || subj),
  prior = prior_v,
  data = df_eeg
)



## ----eval=FALSE-------------------------
## fit_N400_v


## ----plotfitN400v,fig.cap="(ref:plotfitN400v)"----
plot(fit_N400_v, N = 6)


## ----partialpooling, fig.cap = "(ref:partialpooling)", fig.height=9.5,message=FALSE,warning=FALSE----
# make a table of u_2s
ind_effects_v <- paste0("r_subj[", unique(df_eeg$subj), 
                        ",c_cloze]")
u_2_v <- posterior_summary(fit_N400_v, variable = ind_effects_v) %>%
  as_tibble() %>%
  mutate(subj = 1:n()) %>%
  ## reorder plot by magnitude of mean:
  arrange(Estimate) %>%
  mutate(subj = factor(subj, levels = subj))
# We plot:
ggplot(
  u_2_v,
  aes(x = Estimate, xmin = Q2.5, xmax = Q97.5, y = subj)
) +
  geom_point() +
  geom_errorbarh() +
  xlab("By-subject adjustment to the slope in microvolts")



## ---------------------------------------
# Extract parameter estimates from the no pooling model:
par_np <- posterior_summary(fit_N400_np, variable = ind_effects_np) %>%
  as_tibble() %>%
  mutate(
    model = "No pooling",
    subj = unique(df_eeg$subj)
  )

# For the hierarchical model, the code is more complicated
# because we want the effect (beta) + adjustment.
# Extract the overall group level effect:
beta <- c(as_draws_df(fit_N400_v)$b_c_cloze)
# Extract the individual adjustments:
ind_effects_v <- paste0("r_subj[", unique(df_eeg$subj), ",c_cloze]")
adjustment <- as_draws_matrix(fit_N400_v, variable = ind_effects_v)
# Get the by subject effects in a data frame where each adjustment
# is in each column.
# Remove all the draws meta data by using as.data.frame
by_subj_effect <- as.data.frame(beta + adjustment)
# Summarize them by getting a table with the mean and the
# quantiles for each column and then binding them.
par_h <- lapply(by_subj_effect, function(x) {
  tibble(
    Estimate = mean(x),
    Q2.5 = quantile(x, .025),
    Q97.5 = quantile(x, .975)
  )
}) %>%
  bind_rows() %>%
  # Add a column to identify that the model,
  # and one with the subject labels:
  mutate(
    model = "Hierarchical",
    subj = unique(df_eeg$subj)
  )

# The mean and 95% CI of both models in one data frame:
by_subj_df <- bind_rows(par_h, par_np) %>%
  arrange(Estimate) %>%
  mutate(subj = factor(subj, levels = unique(.data$subj))) 


## ----comparison, message=FALSE, fig.height=9.5, fig.cap= "(ref:comparison)"----
ggplot(
  by_subj_df,
  aes(
    ymin = Q2.5, ymax = Q97.5, x = subj, y = Estimate, color = model,
    shape = model
  )
) +
  geom_errorbar(position = position_dodge(1)) +
  geom_point(position = position_dodge(1)) +
  # We'll also add the mean and 95% CrI of the overall difference
  # to the plot:
  geom_hline(
    yintercept =
      posterior_summary(fit_N400_v,
                        variable = "b_c_cloze")[, "Estimate"]
  ) +
  geom_hline(
    yintercept =
      posterior_summary(fit_N400_v,
                        variable = "b_c_cloze")[, "Q2.5"],
    linetype = "dotted", size = .5
  ) +
  geom_hline(
    yintercept =
      posterior_summary(fit_N400_v,
                        variable = "b_c_cloze")[, "Q97.5"],
    linetype = "dotted", size = .5
  ) +
  xlab("N400 effect of predictability") +
  coord_flip()



## ----lkjviz,echo=FALSE, fig.cap ="(ref:lkjviz)", message= FALSE,warning=FALSE,results="asis",fig.height=11,cache=TRUE, fig.width =4, fig.height=3,fig.show='hold', out.width='48%'----
## https://github.com/rmcelreath/rethinking/blob/1def057174071beb212532d545bc2d8c559760a2/R/distributions.r
# onion method correlation matrix
dlkjcorr <- function(x, eta = 1, log = FALSE) {
  ll <- det(x)^(eta - 1)
  if (log == FALSE) ll <- exp(ll)
  return(ll)
}

# Simplified for a 2 x 2 matrix
dlkjcorr2 <- function(rho, eta = 1) {
  map_dbl(rho, ~ matrix(c(1, .x, .x, 1), ncol = 2) %>%
    dlkjcorr(., eta))
}

ggplot(tibble(rho = c(-.99, .99)), aes(rho)) +
  stat_function(fun = dlkjcorr2, geom = "line", args = list(eta = 1)) +
  ylab("density") +
  ggtitle("eta = 1")

ggplot(tibble(rho = c(-.99, .99)), aes(rho)) +
  stat_function(fun = dlkjcorr2, geom = "line", args = list(eta = 2)) +
  ylab("density") +
  ggtitle("eta = 2")

ggplot(tibble(rho = c(-.99, .99)), aes(rho)) +
  stat_function(fun = dlkjcorr2, geom = "line", args = list(eta = 4)) +
  ylab("density") +
  ggtitle("eta = 4")

ggplot(tibble(rho = c(-.99, .99)), aes(rho)) +
  stat_function(fun = dlkjcorr2, geom = "line", args = list(eta = .9)) +
  ylab("density") +
  ggtitle("eta = .9")


## ---- message = FALSE, results = "hide"----
prior_h <- c(
  prior(normal(0, 10), class = Intercept),
  prior(normal(0, 10), class = b, coef = c_cloze),
  prior(normal(0, 50), class = sigma),
  prior(normal(0, 20),
    class = sd, coef = Intercept,
    group = subj
  ),
  prior(normal(0, 20),
    class = sd, coef = c_cloze,
    group = subj
  ),
  prior(lkj(2), class = cor, group = subj)
)
fit_N400_h <- brm(n400 ~ c_cloze + (c_cloze | subj),
  prior = prior_h,
  data = df_eeg
)



## ----plotfitN400h,fig.cap="(ref:plotfitN400h)"----
plot(fit_N400_h, N = 6)


## ---- eval = FALSE----------------------
## prior_sih_full <-
##   c(
##     prior(normal(0, 10), class = Intercept),
##     prior(normal(0, 10), class = b, coef = c_cloze),
##     prior(normal(0, 50), class = sigma),
##     prior(normal(0, 20),
##       class = sd, coef = Intercept,
##       group = subj
##     ),
##     prior(normal(0, 20),
##       class = sd, coef = c_cloze,
##       group = subj
##     ),
##     prior(lkj(2), class = cor, group = subject),
##     prior(normal(0, 20),
##       class = sd, coef = Intercept,
##       group = item
##     ),
##     prior(normal(0, 20),
##       class = sd, coef = c_cloze,
##       group = item
##     ),
##     prior(lkj(2), class = cor, group = item)
##   )
## 
## fit_N400_sih <- brm(n400 ~ c_cloze + (c_cloze | subj) +
##   (c_cloze | item),
## prior = prior_sih_full,
## data = df_eeg
## )
## 


## ---- message = FALSE, results = "hide"----
prior_sih <-
  c(
    prior(normal(0, 10), class = Intercept),
    prior(normal(0, 10), class = b),
    prior(normal(0, 50), class = sigma),
    prior(normal(0, 20), class = sd),
    prior(lkj(2), class = cor)
  )

fit_N400_sih <- brm(n400 ~ c_cloze + (c_cloze | subj) +
  (c_cloze | item),
prior = prior_sih,
data = df_eeg
)


## ---- eval = FALSE----------------------
## fit_N400_sih


## ----fitN400sih, fig.height = 11,fig.cap="(ref:fitN400sih)"----
plot(fit_N400_sih, N = 9)


## **The Matrix Formulation of Hierarchical Models (the Laird-Ware form)**


## ----ppcheckdens, fig.cap ="(ref:ppcheckdens)"----
pp_check(fit_N400_sih, ndraws = 50, type = "dens_overlay")


## ---- echo = FALSE, eval = FALSE--------
## # the function is already in bayesplot(?)
## ppc_dens_overlay_grouped <-
##   function(y, yrep, ..., size = 0.25, alpha = 0.7, trim = FALSE,
##            bw = "nrd0", adjust = 1, kernel = "gaussian", n_dens = 1024, group) {
##     bayesplot:::check_ignored_arguments(...)
##     data <- ppc_data(y, yrep, group = group)
##     ggplot(data) +
##       aes_(x = ~value) +
##       stat_density(aes_(
##         group = ~rep_id,
##         color = "yrep"
##       ),
##       data = function(x) {
##         dplyr::filter(
##           x,
##           !.data$is_y
##         )
##       }, geom = "line", position = "identity", size = size,
##       alpha = alpha, trim = trim, bw = bw, adjust = adjust,
##       kernel = kernel, n = n_dens
##       ) +
##       stat_density(aes_(color = "y"),
##         data = function(x) dplyr::filter(x, .data$is_y), geom = "line",
##         position = "identity", lineend = "round", size = 1, trim = trim,
##         bw = bw, adjust = adjust, kernel = kernel, n = n_dens
##       ) +
##       bayesplot:::scale_color_ppc_dist() +
##       bayesplot_theme_get() +
##       xlab(bayesplot:::y_label()) +
##       bayesplot:::dont_expand_axes() +
##       yaxis_title(FALSE) +
##       xaxis_title(FALSE) +
##       yaxis_text(FALSE) +
##       yaxis_ticks(FALSE) +
##       facet_wrap(~group)
##   }


## ----postpreddensbysubj, fig.cap ="(ref:postpreddensbysubj)" , message= FALSE,fig.height=11, echo = TRUE----
ppc_dens_overlay_grouped(df_eeg$n400,
  yrep =
    posterior_predict(fit_N400_sih,
      ndraws = 100
    ),
  group = df_eeg$subj
) +
  xlab("Signal in the N400 spatiotemporal window")


## ----postpredsumbysubj, fig.cap ="(ref:postpredsumbysubj)", message= FALSE, fig.height=11----
pp_check(fit_N400_sih,
  type = "stat_grouped",
  ndraws = 1000,
  group = "subj",
  stat = "sd"
)


## ---- message = FALSE, results = "hide"----
prior_s <- c(
  prior(normal(0, 10), class = Intercept),
  prior(normal(0, 10), class = b),
  prior(normal(0, 20), class = sd),
  prior(lkj(2), class = cor),
  prior(normal(0, log(50)), class = Intercept, dpar = sigma),
  prior(normal(0, 5),
    class = sd, group = subj,
    dpar = sigma
  )
)
fit_N400_s <- brm(bf(
  n400 ~ c_cloze + (c_cloze | subj) + (c_cloze | item),
  sigma ~ 1 + (1 | subj)
),
prior = prior_s,
data = df_eeg
)


## ---------------------------------------
posterior_summary(fit_N400_sih, variable = "b_c_cloze")


## ---------------------------------------
posterior_summary(fit_N400_s, variable = "b_c_cloze")


## ----postpreddensbysubj2, fig.cap ="(ref:postpreddensbysubj2)" , message= FALSE, fig.height=11----
ppc_dens_overlay_grouped(df_eeg$n400,
  yrep =
    posterior_predict(fit_N400_s,
      ndraws = 100
    ),
  group = df_eeg$subj
) +
  xlab("Signal in the N400 spatiotemporal window")



## ----postpredsumbysubj2, fig.cap ="(ref:postpredsumbysubj2)", message= FALSE, fig.height=11, echo = FALSE----
pp_check(fit_N400_s,
  type = "stat_grouped",
  ndraws = 1000,
  group = "subj",
  stat = "sd"
)


## ----stroopdata, message = FALSE--------
data("df_stroop")
(df_stroop <- df_stroop %>%
  mutate(c_cond = if_else(condition == "Incongruent", 1, -1)))


## ----stroopm1, message = FALSE, results = "hide", eval = !file.exists("dataR/fit_stroopm1.RDS")----
fit_stroop <- brm(RT ~ c_cond + (c_cond | subj),
  family = lognormal(),
  prior =
    c(
      prior(normal(6, 1.5), class = Intercept),
      prior(normal(0, .01), class = b),
      prior(normal(0, 1), class = sigma),
      prior(normal(0, 1), class = sd),
      prior(lkj(2), class = cor)
    ),
  iter = 4000,
  data = df_stroop
)


## ----echo = FALSE-----------------------
if (!file.exists("dataR/fit_stroopm1.RDS")) {
  saveRDS(fit_stroop, "dataR/fit_stroopm1.RDS")
} else {
  fit_stroop <- readRDS("dataR/fit_stroopm1.RDS")
}


## ---- plotfit_stroop,fig.height = 11,fig.cap="The posterior distributions "----
posterior_summary(fit_stroop, variable = "b_c_cond")


## ----priorposteriordiscrepancy,fig.height=11,fig.cap="(ref:priorposteriordiscrepancy)", fig.height = 5----
sample_b_post <- as_draws_df(fit_stroop)$b_c_cond
# We generate samples from the prior as well:
N <- length(sample_b_post)
sample_b_prior <- rnorm(N, 0, .01)
samples <- tibble(
  sample = c(sample_b_post, sample_b_prior),
  distribution = c(rep("posterior", N), rep("prior", N))
)
ggplot(samples, aes(x = sample, fill = distribution)) +
  geom_density(alpha = .5)



## ----stroopfits, message = FALSE, results = "hide", eval = !file.exists("_bookdown_files/df_beta_stroop.RDS"), echo = FALSE----
sds <- c(0.001, 0.01, 0.05, 0.1, 1, 2)
df_beta_stroop <- map_dfr(sds, function(sd) {
  priorb <- paste0("normal(0, ", sd, ")")
  fit <- brm(RT ~ c_cond + (c_cond | subj),
    family = lognormal(),
    prior =
      c(
        prior(normal(6, 1.5), class = Intercept),
        prior_string(priorb, class = "b"),
        prior(normal(0, 1), class = sigma),
        prior(normal(0, 1), class = sd),
        prior(lkj(2), class = cor)
      ),
    iter = 4000,
    data = df_stroop
  )

  posterior_summary(fit, variable = "b_c_cond") %>%
    as_tibble() %>%
    mutate(prior = priorb)
})


## ---- echo = FALSE----------------------
if (!file.exists("_bookdown_files/df_beta_stroop.RDS")) {
  saveRDS(df_beta_stroop, "_bookdown_files/df_beta_stroop.RDS")
} else {
  df_beta_stroop <- readRDS("_bookdown_files/df_beta_stroop.RDS")
}


## ----priorsslopesmeansCIs,echo = FALSE, results = "asis"----

df_beta_stroop %>%
  select(-Est.Error) %>%
  select(prior, everything()) %>%
  kableExtra::kable(caption = "The summary (mean and 95\\% credible interval) for the posterior distribution of the slope in the model fit\\_stroop, given different priors on the slope parameter.")


## ----stroopfitsdiff, message = FALSE, results = "hide", eval = !file.exists("_bookdown_files/df_diffs_stroop.RDS"), echo = FALSE----
sds <- c(0.001, 0.01, 0.05, 0.1, 1, 2)
df_diffs_stroop <- map_dfr(sds, function(sd) {
  priorb <- paste0("normal(0, ", sd, ")")
  fit <- brm(RT ~ c_cond + (c_cond | subj),
    family = lognormal(),
    prior =
      c(
        prior(normal(6, 1.5), class = Intercept),
        prior_string(priorb, class = "b"),
        prior(normal(0, 1), class = sigma),
        prior(normal(0, 1), class = sd),
        prior(lkj(2), class = cor)
      ),
    iter = 4000,
    data = df_stroop
  )

  sample_a_post <- as_draws_df(fit)$b_Intercept
  sample_b_post <- as_draws_df(fit)$b_c_cond
  RT_diff <- exp(sample_a_post + sample_b_post) -
    exp(sample_a_post - sample_b_post)
  tibble(
   prior = priorb,
   `mean diff (ms)` = mean(RT_diff),
    Q2.5 = quantile(RT_diff, .025),
    Q97.5 = quantile(RT_diff, .975)
    
  )
})

## ---- echo = FALSE----------------------
if (!file.exists("_bookdown_files/df_diffs_stroop.RDS")) {
  saveRDS(df_diffs_stroop, "_bookdown_files/df_diffs_stroop.RDS")
} else {
  df_diffs_stroop <- readRDS("_bookdown_files/df_diffs_stroop.RDS")
}


## ---- meanrtdiffsummary,echo = FALSE, results = "asis"----
df_diffs_stroop %>%
  kableExtra::kable(escape = FALSE,
                    caption="A summary, under a range of priors, of the posterior distributions of the mean difference between the two conditions, back-transformed to the millisecond scale.")


## A hierarchical model of cognitive load on pupil size.


## ---------------------------------------
data("df_pupil_complete")
df_pupil_complete


## Are subject relatives easier to process than object relatives?


## ----open_grodneretal, message = FALSE----
data("df_gg05_rc")
df_gg05_rc


## ---------------------------------------
df_gg05_rc <- df_gg05_rc %>%
  mutate(c_cond = if_else(condition == "objgap", 1, -1))


## Relative clause processing in Mandarin Chinese


## ---------------------------------------
data("df_gibsonwu")
gibsonwu <- df_gibsonwu
data("df_gibsonwu2")
gibsonwu2 <- df_gibsonwu2


## Agreement attraction in comprehension


## ---------------------------------------
data("df_dillonE1")
dillonE1 <- df_dillonE1
head(dillonE1)


## Attentional blink


## ---------------------------------------
data("df_ab")
df_ab


## Is there a Stroop effect in accuracy?


## The grammaticality illusion


## ---------------------------------------
data("df_english")
english <- df_english
data("df_dutch")
dutch <- df_dutch

