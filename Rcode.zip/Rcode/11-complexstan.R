## ---- echo = FALSE----------------------
subj <- as.numeric(as.factor(df_eeg$subj))
Nobs <- length(nrow(df_eeg))
Nsubj <- length(unique(subj))
N <- nrow(df_eeg)


## ----hierarchical-stan, echo = FALSE----
hierarchical1 <- system.file("stan_models", "hierarchical1.stan", package = "bcogsci")
hierarchical2 <- system.file("stan_models", "hierarchical2.stan", package = "bcogsci")
hierarchical3 <- system.file("stan_models", "hierarchical3.stan", package = "bcogsci")
hierarchical_corr <- system.file("stan_models", "hierarchical_corr.stan", package = "bcogsci")
hierarchical_corr2 <- system.file("stan_models", "hierarchical_corr2.stan", package = "bcogsci")
hierarchical_corr_by <- system.file("stan_models", "hierarchical_corr_by.stan", package = "bcogsci")


## NA

## ---- message = FALSE-------------------
data("df_eeg")
df_eeg <- df_eeg %>%
  mutate(c_cloze = cloze - mean(cloze))
ls_eeg <- list(
  N = nrow(df_eeg),
  signal = df_eeg$n400,
  c_cloze = df_eeg$c_cloze,
  subj = df_eeg$subj,
  N_subj = max(df_eeg$subj)
)


## ---- message=FALSE, results="hide"-----
hierarchical1 <- system.file("stan_models",
  "hierarchical1.stan",
  package = "bcogsci"
)
fit_eeg1 <- stan(
  file = hierarchical1,
  data = ls_eeg
)


## ---------------------------------------
print(fit_eeg1, pars = c("alpha", "beta", "sigma", "tau_u"))


## NA

## ---- message=FALSE, results="hide"-----
hierarchical2 <- system.file("stan_models",
  "hierarchical2.stan",
  package = "bcogsci"
)
fit_eeg2 <- stan(
  file = hierarchical2,
  data = ls_eeg
)


## ---------------------------------------
print(fit_eeg2, pars = c("alpha", "beta", "tau_u", "sigma"))


## ----traceploteeg2, fig.cap ="(ref:traceploteeg2)"----
traceplot(fit_eeg2, pars = c("alpha", "beta", "tau_u", "sigma"))


## ----pairsfunnel, fig.cap = "(ref:pairsfunnel)"----
pairs(fit_eeg2, pars = c("tau_u[2]", "u[1,2]", "u[2,2]", "u[3,2]"))


## ----pairsblobs, fig.cap = "(ref:pairsblobs)"----
pairs(fit_eeg2, pars = c("tau_u[1]", "u[1,1]", "u[2,1]", "u[3,1]"))


## ----scatterpairs, fig.cap = "(ref:scatterpairs)"----
mcmc_pairs(as.array(fit_eeg2),
  pars = c("tau_u[2]", "u[1,2]"),
  transform = list(`tau_u[2]` = "log")
)


## **A simple non-centered re-parametrization**


## NA

## ---- message=FALSE, results="hide"-----
hierarchical3 <- system.file("stan_models",
  "hierarchical3.stan",
  package = "bcogsci"
)
fit_eeg3 <- stan(
  file = hierarchical3,
  data = ls_eeg
)


## ----traceploteeg3, fig.cap ="(ref:traceploteeg3)"----
print(fit_eeg3, pars = c("alpha", "beta", "tau_u", "sigma"))
traceplot(fit_eeg3, pars = c("alpha", "beta", "tau_u", "sigma"))


## ----pairstauu, fig.cap ="(ref:pairstauu)", fold = TRUE----
mcmc_pairs(as.array(fit_eeg3),
  pars = c("tau_u[2]", "u[1,2]"),
  transform = list(`tau_u[2]` = "log")
)


## ----pairstauz, fig.cap ="(ref:pairstauz)", fold = TRUE----
mcmc_pairs(as.array(fit_eeg3),
  pars = c("tau_u[2]", "z_u[1,2]"),
  transform = list(`tau_u[2]` = "log")
)


## NA

## ---- message=FALSE, results="hide"-----
hierarchical_corr <- system.file("stan_models",
  "hierarchical_corr.stan",
  package = "bcogsci"
)
fit_eeg_corr <- stan(
  file = hierarchical_corr,
  data = ls_eeg
)


## ---------------------------------------
print(fit_eeg_corr, pars = c("alpha", "beta", "tau_u", "sigma"))


## ----traceploteegcorr, fig.cap ="(ref:traceploteegcorr)", fold = TRUE----
traceplot(fit_eeg_corr, pars = c("alpha", "beta", "tau_u", "sigma"))


## **Cholesky factorization**


## ---------------------------------------
rho <- .8
# Correlation matrix
(rho_u <- matrix(c(1, rho, rho, 1), ncol = 2))

# Cholesky factor:
# (Transpose it so that it looks the same as in Stan)
(L_u <- t(chol(rho_u)))
# Verify that we recover rho_u,
# Recall that %*% indicates matrix multiplication
L_u %*% t(L_u)


## ---- R.options = list(width = 60)------
N_subj <- 10
(z_u1 <- rnorm(N_subj, 0, 1))
(z_u2 <- rnorm(N_subj, 0, 1))


## ---- R.options = list(width = 60)------
# matrix z_u
(z_u <- matrix(c(z_u1, z_u2), ncol = N_subj, byrow = TRUE))


## ---------------------------------------
L_u %*% z_u


## ---- R.options = list(width = 60)------
tau_u1 <- .2
tau_u2 <- .01
(diag_matrix_tau <- diag(c(tau_u1, tau_u2)))


## ---- R.options = list(width = 60)------
(u <- diag_matrix_tau %*% L_u %*% z_u)

# The rows are correlated ~.8
cor(u[1, ], u[2, ])

# The tau's can be recovered as well:
sd(u[1, ])
sd(u[2, ])


## NA

## ---- message=FALSE, results="hide"-----
hierarchical_corr2 <- system.file("stan_models",
  "hierarchical_corr2.stan",
  package = "bcogsci"
)
fit_eeg_corr2 <- stan(
  file = hierarchical_corr2,
  data = ls_eeg
)


## ---------------------------------------
print(fit_eeg_corr2,
  pars =
    c("alpha", "beta", "tau_u", "rho_u", "sigma", "L_u")
)


## ----traceploteegcorr2, fig.cap ="(ref:traceploteegcorr2)", fold = TRUE----
traceplot(fit_eeg_corr2,
  pars =
    c("alpha", "beta", "tau_u", "L_u", "sigma")
)


## ----posteegcorr2, fig.height=2, message=FALSE, fig.cap ="(ref:posteegcorr2)"----
mcmc_hist(as.data.frame(fit_eeg_corr2),
  pars = c("beta", "rho_u[1,2]")
)


## NA

## ---------------------------------------
df_eeg <- df_eeg %>%
  mutate(item = as.numeric(as.factor(item)))

ls_eeg <- list(
  N = nrow(df_eeg),
  signal = df_eeg$n400,
  c_cloze = df_eeg$c_cloze,
  subj = df_eeg$subj,
  item = df_eeg$item,
  N_subj = max(df_eeg$subj),
  N_item = max(df_eeg$item)
)


## ---- message=FALSE, results="hide"-----
hierarchical_corr_by <- system.file("stan_models",
  "hierarchical_corr_by.stan",
  package = "bcogsci"
)
fit_eeg_corr_by <- stan(
  file = hierarchical_corr_by,
  data = ls_eeg
)


## ---------------------------------------
print(fit_eeg_corr_by,
  pars =
    c("alpha", "beta", "sigma", "tau_u", "tau_w", "rho_u", "rho_w")
)


## Log-normal model in Stan


## By subject and by items hierarchical model with a log-normal likelihood.


## A hierarchical logistic regression with Stan.


## Distributional regression model of the effect of cloze probability on the N400

