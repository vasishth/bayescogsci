## ----yscores----------------------------
Y <- rnorm(n = 100, mean = 3, sd = 10)
head(Y)


## ---------------------------------------
up <- function(y, mu, sigma) {
  dnorm(x = mu, mean = 0, sd = 20) *
    dlnorm(x = sigma, mean = 3, sd = 1) *
    prod(dnorm(x = y, mean = mu, sd = sigma))
}


## ---------------------------------------
up(y = Y, mu = 0, sigma = 5)


## ----up, fig.cap = "(ref:up)" ,echo = FALSE, warning=FALSE----
mu <- seq(-40, 40, 1)
sigma <- seq(0.5, 40, 1)

dup <- expand.grid(mu, sigma) %>%
  as_tibble() %>%
  setNames(c("mu", "sigma")) %>%
  mutate(UP = map2_dbl(.data$mu, .data$sigma, ~ up(Y, .x, .y)))

lattice::wireframe(UP ~ mu * sigma, data = dup)


## ---------------------------------------
lookup(plogis)


## ----yscoresagain, eval = FALSE---------
## Y <- rnorm(n = 100, mean = 3, sd = 10)


## ----normal-stan, echo = FALSE----------
normal <- system.file("stan_models", "normal.stan", package = "bcogsci")
normal2 <- system.file("stan_models", "normal2.stan", package = "bcogsci")


## NA

## NA

## NA

## **What does `target` do?**


## ----stannormaldo, ref.label="stannormal", echo=FALSE, message = FALSE----


## ---- echo = FALSE----------------------
## extract(fit_score)$lp__[1]
mu <- extract(fit_score)$mu
sigma <- extract(fit_score)$sigma
addmu <- dnorm(x = mu[1], mean = 0, sd = 20, log = TRUE)
addsigma <- dlnorm(x = sigma[1], mean = 3, sd = 1, log = TRUE)
addY <- sum(dnorm(Y, mu[1], sigma[1], log = TRUE))
curr <- addmu + log(sigma[1])
h <- addY + log(sigma[1]) + addmu + addsigma


## NA

## NA

## ---------------------------------------
normal <- system.file("stan_models",
                      "normal.stan",
                      package = "bcogsci")


## ----stannormal, message=FALSE, eval = FALSE----
## lst_score_data <- list(y = Y, N = length(Y))
## # Fit the model with the default values of number of
## # chains and iterations: chains = 4, iter = 2000
## fit_score <- stan(
##   file = normal,
##   data = lst_score_data
## )
## # alternatively:
## # stan(file = "normal.stan", data = lst_score_data)


## ----traceplotmusigma, fig.cap= "(ref:traceplotmusigma)", fig.height=2----
traceplot(fit_score, pars = c("mu", "sigma"))


## ---------------------------------------
print(fit_score, pars = c("mu", "sigma"))


## ---- echo = FALSE----------------------
print.stanfit <- function(fit, pars, probs = c(0.025, 0.975), digits_summary = 2) {
  s <- summary(fit, pars = pars, probs = probs)$summary %>% {
    .[, !colnames(.) %in% c("se_mean", "sd"), drop = FALSE]
  }
  s[, "n_eff"] <- round(s[, "n_eff"], 0)
  print(round(s, digits_summary))
}


## ----mcmchist, fig.cap = "(ref:mcmchist)", message = FALSE----
df_fit_score <- as.data.frame(fit_score)
mcmc_hist(df_fit_score, pars = c("mu", "sigma"))


## ---------------------------------------
# extract from rstan is sometimes overwritten by
# a tidyverse version, we make sure that it's right one:
rstan::extract(fit_score) %>%
  str()
as.data.frame(fit_score) %>%
  str(list.len = 5)
as.array(fit_score) %>%
  str()


## ---- echo = FALSE----------------------
binomial_cloze <- system.file("stan_models",
  "binomial_cloze.stan",
  package = "bcogsci"
)


## NA

## ---- message=FALSE---------------------
lst_cloze_data <- list(k = 80, N = 100)
binomial_cloze <- system.file("stan_models",
                              "binomial_cloze.stan",
                              package = "bcogsci")
fit_cloze <- stan(
  file = binomial_cloze,
  data = lst_cloze_data
)


## ----posttheta, fig.cap = "(ref:posttheta)"----
print(fit_cloze, pars = c("theta"))
df_fit_cloze <- as.data.frame(fit_cloze)
mcmc_dens(df_fit_cloze, pars = "theta") +
  geom_vline(xintercept = mean(df_fit_cloze$theta))


## ----pupilstan, echo = FALSE------------
pupil_model <- system.file("stan_models",
  "pupil_model.stan",
  package = "bcogsci"
)


## NA

## ---- message = FALSE-------------------
df_pupil <- df_pupil %>%
  mutate(c_load = load - mean(load))


## ---- message = FALSE-------------------
ls_pupil <- list(
  p_size = df_pupil$p_size,
  c_load = df_pupil$c_load,
  N = nrow(df_pupil)
)
pupil_model <- system.file("stan_models",
  "pupil_model.stan",
  package = "bcogsci"
)
fit_pupil <- stan(pupil_model,
  data = ls_pupil
)


## ----traceplotreg, fig.height=2, fig.cap = "(ref:traceplotreg)"----
traceplot(fit_pupil, pars = c("alpha", "beta", "sigma"))


## ---------------------------------------
print(fit_pupil, pars = c("alpha", "beta", "sigma"))


## ----postreg, fig.cap = "(ref:postreg)", message = FALSE----
df_fit_pupil <- as.data.frame(fit_pupil)
mcmc_hist(fit_pupil, pars = c("alpha", "beta", "sigma"))


## ---------------------------------------
# We are using df_fit_pupil and not the "raw" Stanfit object.
mean(df_fit_pupil$beta > 0)


## ----pupilgenstan, echo = FALSE---------
pupil_gen <- system.file("stan_models",
                         "pupil_gen.stan",
                         package = "bcogsci")


## NA

## ---- message = FALSE-------------------
ls_pupil <- list(
  onlyprior = 0,
  p_size = df_pupil$p_size,
  c_load = df_pupil$c_load,
  N = nrow(df_pupil)
)
pupil_gen <- system.file("stan_models",
                         "pupil_gen.stan",
                         package = "bcogsci")
fit_pupil <- stan(file = pupil_gen, data = ls_pupil)


## ---------------------------------------
yrep_pupil <- extract(fit_pupil)$p_size_pred
dim(yrep_pupil)


## ----densoverlay, fig.cap = "(ref:densoverlay)"----
ppc_dens_overlay(df_pupil$p_size, yrep = yrep_pupil[1:50, ])


## ---- message = FALSE-------------------
ls_pupil_prior <- list(
  onlyprior = 1,
  p_size = df_pupil$p_size,
  # or: p_size = rep(0, nrow(df_pupil)),
  c_load = df_pupil$c_load,
  N = nrow(df_pupil)
)
prior_pupil <- stan(pupil_gen,
  data = ls_pupil_prior,
  control = list(adapt_delta = 0.90)
)


## ----priordensoverlay, fig.cap ="(ref:priordensoverlay)"----
yrep_prior_pupil <- extract(prior_pupil)$p_size_pred
ppc_dens_overlay(
  runif(ls_pupil_prior$N, 0, 1000),
  yrep_prior_pupil[1:50, ]
)


## **Matrix, vector, or array in Stan?**


## ----pupilintstan, echo = FALSE---------
pupil_int1 <- system.file("stan_models", "pupil_int1.stan", package = "bcogsci")


## NA

## ----pupilint2stan, echo = FALSE--------
pupil_int2 <- system.file("stan_models",
  "pupil_int2.stan",
  package = "bcogsci"
)


## NA

## ---------------------------------------
df_pupil <- df_pupil %>%
  mutate(
    c_trial = trial - mean(trial),
    c_load = load - mean(load)
  )
X <- model.matrix(~ 0 + c_load * c_trial, df_pupil)
ls_pupil_X <- list(
  p_size = df_pupil$p_size,
  X = X,
  K = ncol(X),
  N = nrow(df_pupil)
)


## ---- message = FALSE-------------------
pupil_int <- system.file("stan_models",
  "pupil_int.stan",
  package = "bcogsci"
)
fit_pupil_int <- stan(pupil_int,
  data = ls_pupil_X
)


## ---------------------------------------
print(fit_pupil_int, pars = c("alpha", "beta", "sigma"))


## ----pupilintbeta, fig.cap = "(ref:pupilintbeta)", message = FALSE----
df_fit_pupil_int <- as.data.frame(fit_pupil_int)
mcmc_intervals(fit_pupil_int,
  regex_pars = "beta",
  prob_outer = .95,
  prob = .8,
  point_est = "mean"
)


## ----recallstan, echo = FALSE-----------
recall <- system.file("stan_models",
  "recall.stan",
  package = "bcogsci"
)


## NA

## ----  message = FALSE, warning = FALSE----
df_recall <- df_recall %>%
  mutate(c_set_size = set_size - mean(set_size),
         c_trial = trial - mean(trial))


## ---------------------------------------
X <- model.matrix(~ 0 + c_set_size * c_trial, df_recall)
ls_recall <- list(
  correct = df_recall$correct,
  X = X,
  K = ncol(X),
  N = nrow(df_recall)
)


## ---- message = FALSE-------------------
recall <- system.file("stan_models",
                      "recall.stan",
                      package = "bcogsci")
fit_recall <- stan(
  file = recall,
  data = ls_recall
)


## ---------------------------------------
print(fit_recall, pars = c("alpha", "beta"))


## ----cri, fig.cap ="(ref:cri)", message = FALSE----
df_fit_recall <- as.data.frame(fit_recall)
mcmc_intervals(df_fit_recall,
  regex_pars = "beta",
  prob_outer = .95,
  prob = .8,
  point_est = "mean"
)


## ----recallpropstan, echo = FALSE-------
recall_prop <- system.file("stan_models",
  "recall_prop.stan",
  package = "bcogsci"
)


## NA

## ---- message = FALSE-------------------
recall_prop <- system.file("stan_models",
                           "recall_prop.stan",
                           package = "bcogsci")
fit_recall <- stan(
  file = recall_prop,
  data = ls_recall
)


## ----vaccdet, fig.cap = "Effect of set size, trial, and their interaction on the average accuracy of recall.", message = FALSE----
df_fit_recall <- as.data.frame(fit_recall) %>%
  rename(
    set_size = `change_acc[1]`,
    trial = `change_acc[2]`,
    interaction = `change_acc[3]`
  )
mcmc_intervals(df_fit_recall,
  pars = c("set_size", "trial", "interaction"),
  prob_outer = .95,
  prob = .8,
  point_est = "mean"
) +
  xlab("Change in accuracy")


## A very simple model.


## Incorrect Stan model.


## ---------------------------------------
N <- 500
df_sim <- tibble(
  rt = rlnorm(N, mean = 6, sd = .5),
  correct = rbern(N, prob = .85)
)


## ----incorrectstan, echo = FALSE--------
incorrect <- system.file("stan_models", "incorrect.stan", package = "bcogsci")


## NA

## ---- error = TRUE----------------------
ls_sim <- list(
  rt = df_sim$rt,
  correct = df_sim$correct
)
incorrect <- system.file("stan_models", "incorrect.stan", package = "bcogsci")
fit_sim <- stan(incorrect, data = ls_sim)


## Using Stan documentation.


## ----yscoresagain3, eval = FALSE--------
## Y <- rnorm(1000, mean = 3, sd = 10)


## The probit link function as an alternative to the logit function.


## Examining the position of the queued word on recall.


## The conjunction fallacy.


## ----  message = FALSE------------------
data("df_fallacy")
df_fallacy

