## ---- echo = FALSE, message=FALSE-------
lst_cloze_data <- list(k = 80, N = 100)
# Fit the model with the default values of number of chains and iterations
# chains = 4,    iter = 2000

bn <- system.file("stan_models", "binomial_cloze.stan", package = "bcogsci")
fit_cloze <- stan(
  file = bn, data = lst_cloze_data,
  warmup = 1000,
  iter = 21000
)


## ---- echo = FALSE----------------------
samples_theta <- rstan::extract(fit_cloze)$theta
some_samples <- toString(round(head(samples_theta, 20), 3))
df_fit_cloze <- data.frame(theta = samples_theta)
diff_means <- format(mean(samples_theta) - 84 / (84 + 24), digits = 1)
diff_var <- format(sd(samples_theta)^2 - 84 * 24 / ((84 + 24)^2 * (84 + 24 + 1)), digits = 1)


## ----betapost, fig.cap="(ref:betapost)",echo = FALSE----
ggplot(df_fit_cloze, aes(theta)) +
  geom_histogram(binwidth = .01, colour = "gray", alpha = .5, aes(y = ..density..)) +
  stat_function(fun = dbeta, color = "black", args = list(
    shape1 = 84,
    shape2 = 24
  ))


## ---- reading_noreading, message = FALSE----
data("df_spacebar")
df_spacebar


## ----m1visualize, fig.cap="Visualizing the button-press data.", fold = TRUE----
ggplot(df_spacebar, aes(rt)) +
  geom_density() +
  xlab("response times")+
  ggtitle("Button-press data")


## ---- message = FALSE, cache = TRUE-----
fit_press <- brm(rt ~ 1,
  data = df_spacebar,
  family = gaussian(),
  prior = c(
    prior(uniform(0, 60000), class = Intercept),
    prior(uniform(0, 2000), class = sigma)
  ),
  chains = 4,
  iter = 2000,
  warmup = 1000
)  


## ----warmup, fig.cap = "(ref:warmup)", echo = FALSE----
plot_all <- function(fit, xlab = 500, ylab = 100) {
  chains <- as.array(fit, inc_warmup = TRUE) %>%
    array_branch(margin  = 3)  %>%
    imap_dfr(~ .x %>%
               as_tibble() %>%
               mutate(iter  = 1:n()) %>%
    tidyr::pivot_longer(1:4, names_to = "chain", values_to = "value") %>%
    mutate(parameter = .y) 
    ) %>%
    mutate(parameter = ifelse(parameter == "b_Intercept", "mu", parameter)) %>%
    filter(parameter != "lp__")
  ## as.mcmc(fit, inc_warmup = TRUE) %>%
  ##   map_dfr(~ as.data.frame(.x) %>%
  ##     as_tibble() %>%
  ##     mutate(iter = 1:n()), .id = "chain") %>%
  ##   rename(mu = b_Intercept) %>%
  ##   dplyr::select(-`lp__`) %>%
  ##   tidyr::gather("parameter", "value", -iter, -chain)
  ggplot(chains, aes(x = iter, y = value, color = chain)) +
    geom_line() +
    facet_wrap(~parameter, ncol = 1) +
    geom_vline(xintercept = 1000, linetype = "dashed") +
    xlab("Iteration number") +
    ylab("Sample value") +
    annotate("text", x = xlab, y = ylab, color = "black", label = "Warm-up", size = 5.2)
}

plot_all(fit_press)


## ----warmup2, fig.cap = "(ref:warmup2)", echo = FALSE, message = FALSE, warning = FALSE----
data_mm <- tibble(rt = rnorm(500, c(5, 3000), c(5, 5)))
fit_press_bad <- brm(rt ~ 1,
  data = data_mm,
  family = gaussian(),
  prior = c(
    prior(uniform(0, 60000), class = Intercept),
    prior(uniform(0, 2000), class = sigma)
  ),
  chains = 4,
  iter = 2000,
  warmup = 1000
)

plot_all(fit_press_bad, ylab = 1000)


## ---------------------------------------
as_draws_df(fit_press) 


## ---------------------------------------
plot(fit_press)


## ---- results = "hold"------------------
fit_press
# posterior_summary(fit_press) is also useful


## ---------------------------------------
as_draws_df(fit_press)$b_Intercept %>% mean()
as_draws_df(fit_press)$b_Intercept %>% mean()
as_draws_df(fit_press)$b_Intercept %>% 
  quantile(c(0.025, .975))


## ---------------------------------------
normal_predictive_distribution <- function(mu_samples, sigma_samples, N_obs) {
  # empty data frame with headers:
  df_pred <- tibble(
    trialn = numeric(0),
    rt_pred = numeric(0),
    iter = numeric(0)
  )
  # i iterates from 1 to the length of mu_samples,
  # which we assume is identical to
  # the length of the sigma_samples:
  for (i in seq_along(mu_samples)) {
    mu <- mu_samples[i]
    sigma <- sigma_samples[i]
    df_pred <- bind_rows(
      df_pred,
      tibble(
        trialn = seq_len(N_obs), # 1, 2,... N_obs
        rt_pred = rnorm(N_obs, mu, sigma),
        iter = i
      )
    )
  }
  df_pred
}


## ---------------------------------------
N_samples <- 1000
N_obs <- nrow(df_spacebar)
mu_samples <- runif(N_samples, 0, 60000)
sigma_samples <- runif(N_samples, 0, 2000)
tic()
prior_pred <- normal_predictive_distribution(
  mu_samples = mu_samples,
  sigma_samples = sigma_samples,
  N_obs = N_obs
)
toc()
prior_pred


## **A more efficient prior predictive distribution function**


## ---------------------------------------
library(purrr)
# Define the function:
normal_predictive_distribution <- function(mu_samples,
                                           sigma_samples,
                                           N_obs) {
  map2_dfr(mu_samples, sigma_samples, function(mu, sigma) {
    tibble(
      trialn = seq_len(N_obs),
      rt_pred = rnorm(N_obs, mu, sigma)
    )
  }, .id = "iter") %>%
    # .id is always a string and
    # needs to be converted to a number
    mutate(iter = as.numeric(iter))
}
# Test it below:
tic()
prior_pred <- normal_predictive_distribution(
  mu_samples = mu_samples,
  sigma_samples = sigma_samples,
  N_obs = N_obs
)
toc()


## ----priorpred-simple, fig.cap = "(ref:priorpred-simple)", message = FALSE----
prior_pred %>%
  filter(iter <= 18) %>%
  ggplot(aes(rt_pred)) +
  geom_histogram() +
  facet_wrap(~iter, ncol = 3)


## ----priorpred-stats,fig.cap="(ref:priorpred-stats)", message = FALSE, echo = FALSE----
prior_pred %>%
  group_by(iter) %>%
  summarize(
    min_rt = min(rt_pred),
    max_rt = max(rt_pred),
    mean_rt = mean(rt_pred)
  ) %>%
  # we convert the previous data frame to a long one,
  # where min_rt, max_rt, average_rt are possible values
  # of the columns "stat"
  pivot_longer(
    cols = ends_with("rt"),
    names_to = "stat",
    values_to = "rt"
  ) %>%
  mutate(stat = factor(stat, levels = c("mean_rt", "min_rt", "max_rt"))) %>%
  ggplot(aes(rt)) +
  geom_histogram(binwidth = 500) +
  facet_wrap(~stat, ncol = 1)


## ---- message = FALSE, cache = TRUE-----
# We fit the model with the default setting of the sampler:
# 4 chains, 2000 iterations with half of them as warmup.
fit_press_unif <- brm(rt ~ 1,
  data = df_spacebar,
  family = gaussian(),
  prior = c(
    prior(uniform(-10^10, 10^10), class = Intercept),
    prior(uniform(0, 10^10), class = sigma)
  )
)


## ---- echo = FALSE----------------------
## Shorter output
print.brmsfit <- short_summary


## ---- eval = FALSE----------------------
## fit_press_unif


## ---- echo = FALSE----------------------
short_summary(fit_press_unif)


## ----postcomp, fig.cap="(ref:postcomp)", echo = FALSE----
fit_press_all <- bind_rows(
  as.data.frame(fit_press) %>%
    select(-lp__) %>%
    pivot_longer(everything(), names_to = "Parameter") %>%
    mutate(model = "fit_press"),
  as.data.frame(fit_press_unif) %>%
    select(-lp__) %>%
    pivot_longer(everything(), names_to = "Parameter") %>%
    mutate(model = "fit_press_unif")
)

ggplot(fit_press_all, aes(value, linetype = model)) +
  geom_density(bw = .4) +
  facet_wrap(. ~ Parameter, ncol = 2, scales = "free") +
  theme(legend.position = "bottom")


## ---- message = FALSE, cache = TRUE-----
fit_press_inf <- brm(rt ~ 1,
  data = df_spacebar,
  family = gaussian(),
  prior = c(
    prior(normal(400, 10), class = Intercept),
    # brms knows that SDs need to be bounded 
    # to exclude values below zero:
    prior(normal(100, 10), class = sigma)
  )
)


## ---- eval = FALSE----------------------
## fit_press_inf


## ---- echo = FALSE----------------------
short_summary(fit_press_inf)


## ---- message = FALSE, cache = TRUE-----
fit_press_reg <- brm(rt ~ 1,
  data = df_spacebar,
  family = gaussian(),
  prior = c(
    prior(normal(200, 100), class = Intercept),
    prior(normal(50, 50), class = sigma)
  )
)


## ---- eval = FALSE----------------------
## fit_press_reg


## ---- echo = FALSE----------------------
short_summary(fit_press_reg)


## ---------------------------------------
N_obs <- nrow(df_spacebar)
mu_samples <- as_draws_df(fit_press)$b_Intercept
sigma_samples <- as_draws_df(fit_press)$sigma
normal_predictive_distribution(
  mu_samples = mu_samples,
  sigma_samples = sigma_samples,
  N_obs = N_obs
)


## ----normalppc, fig.cap = "(ref:normalppc)", message = FALSE----
pp_check(fit_press, ndraws = 11, type = "hist")


## ----normalppc2, fig.cap = "(ref:normalppc2)" , message = FALSE----
pp_check(fit_press, ndraws = 100, type = "dens_overlay")


## ----logndemo,out.width="48%",fig.cap="Two log-normal distributions with the same parameters generated by either generating samples from a log-normal distribution or exponentiating samples from a normal distribution.", message=FALSE, fig.show = "hold", fig.width=3----
mu <- 6
sigma <- 0.5
N <- 500000
# Generate N random samples from a log-normal distribution
sl <- rlnorm(N, mu, sigma)
ggplot(tibble(samples = sl), aes(samples)) +
  geom_histogram(binwidth = 50) +
  ggtitle("Log-normal distribution\n") +
  coord_cartesian(ylim = c(0, 70000), xlim = c(0, 2000))
# Generate N random samples from a normal distribution,
# and then exponentiate them
sn <- exp(rnorm(N, mu, sigma))
ggplot(tibble(samples = sn), aes(samples)) +
  geom_histogram(binwidth = 50) +
  ggtitle("Exponentiated samples from\na normal distribution") +
  coord_cartesian(ylim = c(0, 70000), xlim = c(0, 2000))


## ---------------------------------------
N_samples <- 1000
N_obs <- nrow(df_spacebar)
mu_samples <- runif(N_samples, 0, 11)
sigma_samples <- runif(N_samples, 0, 1)
prior_pred_ln <- normal_predictive_distribution(
  mu_samples = mu_samples,
  sigma_samples = sigma_samples,
  N_obs = N_obs
) %>%
  mutate(rt_pred = exp(rt_pred))


## ----priorpredlogunif,fig.cap="(ref:priorpredlogunif)", message = FALSE, echo = FALSE----
prior_pred_ln %>%
  group_by(iter) %>%
  summarize(
    min_rt = min(rt_pred),
    max_rt = max(rt_pred),
    mean_rt = mean(rt_pred),
    median_rt = median(rt_pred)
  ) %>%
  pivot_longer(cols = ends_with("rt"), names_to = "stat", values_to = "rt") %>%
  mutate(stat = factor(stat, levels = c("mean_rt", "median_rt", "min_rt", "max_rt"))) %>%
  ggplot(aes(rt)) +
  scale_x_continuous("Response times in ms",
    trans = "log", breaks = c(0.001, 1, 10, 100, 1000, 10000, 100000)
  ) +
  geom_histogram() +
  facet_wrap(~stat, ncol = 1)


## ---------------------------------------
mean(rtnorm(100000, 0, 1, a = 0))


## ---------------------------------------
c(
  lower = exp(6 - 2 * 1.5),
  higher = exp(6 + 2 * 1.5)
)


## ---- results="hide", message= FALSE----
df_spacebar_ref <- df_spacebar %>%
  mutate(rt = runif(n(), 0, 10000))
fit_prior_press_ln <- brm(rt ~ 1,
  data = df_spacebar_ref,
  family = lognormal(),
  prior = c(
    prior(normal(6, 1.5), class = Intercept),
    prior(normal(0, 1), class = sigma)
  ),
  sample_prior = "only",
  control = list(adapt_delta = .9)
)


## ----priorpredcheck, eval = FALSE-------
## pp_check(fit_prior_press_ln, type = "stat", stat = "mean") +
##   coord_cartesian(xlim = c(0.001, 300000)) +
##   scale_x_continuous("Response times [ms]",
##     trans = "log",
##     breaks = c(0.001, 1, 100, 1000, 10000, 100000),
##     labels = c(
##       "0.001", "1", "100", "1000", "10000",
##       "100000"
##     )
##   ) +
##   ggtitle("Prior predictive distribution of means")


## ----priorpredlognorm, fig.cap="(ref:priorpredlognorm)", message = FALSE, tidy=FALSE, fig.height = 6, fig.show="hold", fold = TRUE----

p1 <- pp_check(fit_prior_press_ln, type = "stat", stat = "mean") +
  coord_cartesian(xlim = c(0.001, 300000)) +
  scale_x_continuous("Response times [ms]",
    trans = "log",
    breaks = c(0.001, 1, 100, 1000, 10000, 100000),
    labels = c(
      "0.001", "1", "100", "1000", "10000",
      "100000"
    )
  ) +
  ggtitle("Prior predictive distribution of means")
p2 <- pp_check(fit_prior_press_ln, type = "stat", stat = "min") +
  coord_cartesian(xlim = c(0.001, 300000)) +
  scale_x_continuous("Response times [ms]",
    trans = "log",
    breaks = c(0.001, 1, 100, 1000, 10000, 100000),
    labels = c(
      "0.001", "1", "100", "1000", "10000",
      "100000"
    )
  ) +
  ggtitle("Prior predictive distribution of minimum values")
p3 <- pp_check(fit_prior_press_ln, type = "stat", stat = "max") +
  coord_cartesian(xlim = c(0.001, 300000)) +
  scale_x_continuous("Response times [ms]",
    trans = "log",
    breaks = c(0.001, 1, 100, 1000, 10000, 100000),
    labels = c(
      "0.001", "1", "10", "1000", "10000",
      "100000"
    )
  ) +
  ggtitle("Prior predictive distribution of maximum values")
plot_grid(p1, p2, p3, nrow = 3, ncol =1)


## ---- message = FALSE, cache = TRUE-----
fit_press_ln <- brm(rt ~ 1,
  data = df_spacebar,
  family = lognormal(),
  prior = c(
    prior(normal(6, 1.5), class = Intercept),
    prior(normal(0, 1), class = sigma)
  )
)


## ---- eval = FALSE----------------------
## fit_press_ln


## ---- echo = FALSE----------------------
short_summary(fit_press_ln)


## ---- message = FALSE-------------------
estimate_ms <- exp(as_draws_df(fit_press_ln)$b_Intercept)


## ---------------------------------------
c(mean = mean(estimate_ms), quantile(estimate_ms, probs = c(.025, .975)))


## ----lognppc, message=FALSE, fig.cap="(ref:logppc)"----
pp_check(fit_press_ln, ndraws = 100)


## ---- eval = FALSE----------------------
## pp_check(fit_press, type = "stat", stat = "min")


## ----ppcheckmin,fig.cap="Distributions of minimum values in a posterior predictive check, using the normal and log-normal probability density functions. The minimum in the data is 110 ms.", fig.height = 3, fig.show="hold", message=FALSE, out.width = "45%", fig.width=4, echo = FALSE----
pp_check(fit_press, type = "stat", stat = "min") + ggtitle("Normal model")
pp_check(fit_press_ln, type = "stat", stat = "min") + ggtitle("Log-normal model")


## ----ppcheckmax,fig.cap="Distribution of maximum values in a posterior predictive check. The maximum in the data is 409 ms.", fig.show="hold", fig.height = 3, message=FALSE, out.width = "45%", fig.width=4, echo = FALSE----
pp_check(fit_press, type = "stat", stat = "max") + ggtitle("Normal model")
pp_check(fit_press_ln, type = "stat", stat = "max") + ggtitle("Log-normal model")


## A simple linear model.


## Revisiting the button-pressing example with different priors.


## Posterior predictive checks with a log-normal model.


## A skew normal distribution.

