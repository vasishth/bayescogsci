## ----globalmotionpng, fig.cap = "(ref:glob)", out.width = "100%", echo = FALSE, fig.align = "center"----
knitr::include_graphics("cc_figure/globalmotion.PNG", dpi =1000)


## ---- message = FALSE-------------------
data("df_dots") 
df_dots


## ----dfdots, message = FALSE, fig.cap = "(ref:dfdots)", fold = TRUE----
ggplot(df_dots, aes(rt)) +
  geom_histogram()


## ----dfaccrt, fig.cap = "(ref:dfaccrt)", fold = TRUE----
ggplot(df_dots, aes(x = factor(acc), y = rt)) +
  geom_point(position = position_jitter(width = .4, height = 0),
             alpha = .5) +
  facet_wrap(diff ~ emphasis) +
  xlab("Accuracy") +
  ylab("Response time")


## ---- eval = FALSE, echo = FALSE--------
## #to complete
## probs <- c(0, .1,.3,.5,.7,.9)
## 
## df_lp <- df_dots %>% group_by(diff, emphasis) %>%
##   mutate(q = cut(rt, breaks = quantile(rt, probs = probs), labels = probs[-1]))%>%
##   group_by(diff, emphasis, q) %>%
##   summarize(rt = max(rt), acc = mean(acc))
## 
## df_dots %>% group_by(diff, emphasis) %>%
##   mutate(art = mean(rt),
##          lrt = quantile(rt, .025),
##          hrt = quantile(rt, .975),
##          acc = mean(acc)) %>%
##   ggplot(aes(x = acc, y = art, ymin = lrt, ymax = hrt)) +
##   geom_point() +
##   facet_grid(~emphasis)
## +
##   geom_errorbar()
## 
## 
## 
## df_lp
## 
## df_dots %>% filter(diff == "easy", emphasis == "accuracy") %>% {quantile(.$rt, probs = probs)}
## 
## df_dots %>% group_by(diff, emphasis) %>%
##    mutate(rtq = quantile(rt, probs = .1)) %>%
##    filter(diff == "easy", emphasis == "accuracy")
## x <- 1:100
## x[ntile(1:100,4)==10]
## quantile(1:100)


## ---------------------------------------
N <- 1000
x <- c(rep(-.5, N/2), rep(.5, N/2))
# Parameters true values
alpha <- 5.8
beta <- 0.05
sigma <- .4
sigma2 <- .5
gamma <- 5.2
p_task <- .8
# Median time
c("engaged" = exp(alpha), "guessing" = exp(gamma))


## ---------------------------------------
z <- rbern(n = N, prob = p_task)
rt <- if_else(z == 1,
             rlnorm(N,
                    meanlog = alpha + beta * x,
                    sdlog = sigma),
             rlnorm(N, meanlog = gamma,
                    sdlog = sigma2))
df_dots_simdata1 <- tibble(trial = 1:N, x = x, rt = rt)


## ----simmix, fig.cap = "(ref:simmix)", message = FALSE----
ggplot(df_dots_simdata1, aes(rt)) +
  geom_histogram()


## ----mixtures-stan, echo = FALSE--------
mixture_rt <- system.file("stan_models", "mixture_rt.stan", package = "bcogsci")
mixture_rt2 <- system.file("stan_models", "mixture_rt2.stan", package = "bcogsci")
mixture_rtacc <- system.file("stan_models", "mixture_rtacc.stan", package = "bcogsci")
mixture_rtacc2 <- system.file("stan_models", "mixture_rtacc2.stan", package = "bcogsci")
mixture_h <- system.file("stan_models", "mixture_h.stan", package = "bcogsci")
mixture_h_gen <- system.file("stan_models", "mixture_h_gen.stan", package = "bcogsci")


## NA

## ---------------------------------------
ls_dots_simdata <- list(N = N,
                        rt = rt,
                        x = x) 


## ----fitmixture_rt, results = "hide", message = "FALSE", eval = TRUE----
mixture_rt <- system.file("stan_models",
                        "mixture_rt.stan",
                        package = "bcogsci")
fit_mix_rt <- stan(file = mixture_rt,
               data = ls_dots_simdata)   


## ---- echo= FALSE, eval = FALSE---------
## if(!file.exists("dataR/fit_mix_rt.RDS")){
##   saveRDS(fit_mix_rt, "dataR/fit_mix_rt.RDS")
## } else {
##   fit_mix_rt <- readRDS("dataR/fit_mix_rt.RDS")
## }


## ---------------------------------------
print(fit_mix_rt) 


## ----traceplotsmix1, fig.cap = "(ref:traceplotsmix1)"----
traceplot(fit_mix_rt) 


## ----dbeta, fold = TRUE, fig.cap = "(ref:dbeta)"----
plot(function(x) dbeta(x, 8, 2))


## NA

## ----fitmixture_rt2, results = "hide", message = "FALSE", eval = !file.exists("dataR/fit_mix_rt2.RDS")----
mixture_rt2 <- system.file("stan_models",
                        "mixture_rt2.stan",
                        package = "bcogsci")
fit_mix_rt2 <- stan(file = mixture_rt2, 
               data = ls_dots_simdata)  


## ---- echo= FALSE-----------------------
if(!file.exists("dataR/fit_mix_rt2.RDS")){
  saveRDS(fit_mix_rt2,"dataR/fit_mix_rt2.RDS")
} else {
  fit_mix_rt2 <- readRDS("dataR/fit_mix_rt2.RDS")
}


## ----traceplotsmix2, fig.cap = "(ref:traceplotsmix2)"----
print(fit_mix_rt2) 
traceplot(fit_mix_rt2) 


## ---------------------------------------
p_correct <- .999
acc <- ifelse(z, rbern(n = N, p_correct),
                  rbern(n = N, .5))
df_dots_simdata3 <- tibble(trial = 1:N,
                           x = x,
                           rt = rt,
                           acc = acc) %>%
  mutate(diff = if_else(x == .5, "hard", "easy"))


## ----simdata3, message = FALSE, fig.cap="(ref:simdata3)"----
ggplot(df_dots_simdata3, aes(x = factor(acc), y = rt)) +
  geom_point(position = position_jitter(width = .4, height = 0),
             alpha = .5) +
  facet_wrap(diff ~ .) +
  xlab("Accuracy") +
  ylab("Response time")


## NA

## ---------------------------------------
ls_dots_simdata <- list(N = N,
                        rt = rt,
                        x = x,
                        acc = acc)


## ----fitmixture_rtacc, results = "hide", message = "FALSE", eval = !file.exists("dataR/fit_mix_rtacc.RDS")----
mixture_rtacc <- system.file("stan_models",
                        "mixture_rtacc.stan",
                        package = "bcogsci")
fit_mix_rtacc <- stan(file = mixture_rtacc,
               data = ls_dots_simdata)  


## ---- echo= FALSE-----------------------
if(!file.exists("dataR/fit_mix_rtacc.RDS")){
  saveRDS(fit_mix_rtacc,"dataR/fit_mix_rtacc.RDS")
} else {
  fit_mix_rtacc <- readRDS("dataR/fit_mix_rtacc.RDS")
}


## ---------------------------------------
print(fit_mix_rtacc) 


## ---------------------------------------
Ns <- 1000 # number of samples for the plot
# Priors
p_btask <- rbeta(n = Ns, shape1 = 8, shape2 = 2)
beta_task <- rnorm(n = Ns, mean = 0, sd = 1)
# Predicted probability of being engaged
p_task_easy <- plogis(qlogis(p_btask) + .5 * beta_task)
p_task_hard <- plogis(qlogis(p_btask) + -.5 * beta_task)
# Predicted difference
diff_p_pred <- tibble(diff = p_task_easy - p_task_hard)


## ----emphasis, fig.cap ="(ref:emphasis)", message = FALSE----
diff_p_pred %>%
  ggplot(aes(diff)) +
  geom_histogram()


## ---------------------------------------
# New predictor
x2 <- rep(c(-.5, .5), N/2)
# Verify that the predictors are crossed:
predictors <- tibble(x, x2)
xtabs(~ x + x2, predictors)

# New true values
beta_task <- 0.5
p_btask <- .85
# Generate data:
alpha_task <- qlogis(p_btask)
p_task <- plogis(alpha_task + x2 * beta_task)
z <- rbern(n = N, prob = p_task)
rt <- ifelse(z,
             rlnorm(n = N, meanlog = alpha + beta * x, sdlog = sigma),
             rlnorm(n = N, meanlog = gamma, sdlog = sigma2))
acc <- ifelse(z, rbern(n = N, p_correct),
                  rbern(n = N, .5))

df_dots_simdata4 <- tibble(trial = 1:N,
                           x = x,
                           rt = rt,
                           acc = acc,
                           x2 = x2) %>%
  
  mutate(diff = if_else(x == .5, "hard", "easy"),
         emphasis = ifelse(x2 == .5, "accuracy", "speed"))


## ----taskinstr, fig.cap ="(ref:taskinstr)", message = FALSE----
ggplot(df_dots_simdata4, aes(x = factor(acc), y = rt)) +
  geom_point(position = position_jitter(width = .4, height = 0),
             alpha = .5) +
  facet_wrap(diff ~ emphasis) +
  xlab("Accuracy") +
  ylab("Response time")


## NA

## ----fitmixture_rtacc2pp, results = "hide", message = "FALSE", warnings = FALSE----
ls_dots_simdata <- list(N = N,
                        rt = rt,
                        x = x,
                        x2 = x2,
                        acc = acc,
                        onlyprior = 1) 
mixture_rtacc2 <- system.file("stan_models", 
                        "mixture_rtacc2.stan", 
                        package = "bcogsci")
fit_mix_rtacc2_priors <- stan(file = mixture_rtacc2,
                         data = ls_dots_simdata,
                         chains = 1, iter = 2000)   


## ----ppcmix4, message = FALSE, fig.cap = "(ref:ppcmix4)"----
rt_pred <- extract(fit_mix_rtacc2_priors)$rt_pred
ppc_dens_overlay(y = rt, yrep = rt_pred[1:100,]) +
  coord_cartesian(xlim = c(0, 10000)) 


## ----ppdiff, message = FALSE, fig.cap = "(ref:ppdiff)"----
meanrt_diff <- function(rt){
  mean(rt[x == .5]) -
    mean(rt[x == -.5])
} 
ppc_stat(rt,
         yrep = rt_pred,
         stat = meanrt_diff) 


## ---- echo = FALSE, eval = FALSE--------
## acc_pred <- extract(fit_mix_rtacc2_priors)$acc_pred


## ---------------------------------------
ls_dots_simdata <- list(N = N,
                        rt = rt,
                        x = x,
                        x2 = x2,
                        acc = acc,
                        onlyprior = 0) 

## ----fitmixture_rtacc2, results = "hide", message = "FALSE", eval = !file.exists("dataR/fit_mix_rtacc2.RDS")----
fit_mix_rtacc2 <- stan(file = mixture_rtacc2,
                  data = ls_dots_simdata)

## ---- echo= FALSE-----------------------
if(!file.exists("dataR/fit_mix_rtacc2.RDS")){
  saveRDS(fit_mix_rtacc2,"dataR/fit_mix_rtacc2.RDS")
} else {
  fit_mix_rtacc2 <- readRDS("dataR/fit_mix_rtacc2.RDS")
}


## ---------------------------------------
print(fit_mix_rtacc2,
      pars = c("alpha", "beta", "sigma", "gamma", "sigma2",
               "p_correct", "p_btask", "beta_task")) 


## ----fake-data-pars-mix, message = FALSE, tidy = FALSE----
# Build the fake stimuli
N_subj <- 20
N_trials <- 100
# Parameters true values
alpha <- 5.8
beta <- 0.05
sigma <- .4
sigma2 <- .5
gamma <- 5.2
beta_task <- 0.1
p_btask <- .85
alpha_task <- qlogis(p_btask)
p_correct <- .999
tau_u <- c(.2, .005, .3)
rho <- .3

## ----fake-data-mix, message = FALSE, tidy = FALSE----
## Build the data set here:
N <- N_subj * N_trials
stimuli <- tibble(x = rep(c(rep(-.5,N_trials/2),
                            rep(.5, N_trials/2)), N_subj),
                  x2 = rep(rep(c(-.5,.5), N_trials/2), N_subj),
                  subj = rep(1:N_subj, each = N_trials),
                  trial = rep(1:N_trials, N_subj)
                  )
stimuli
Cor_u <- matrix(rep(rho, 9), nrow = 3)
diag(Cor_u) <- 1
Cor_u
# Variance covariance matrix for subjects:
Sigma_u <- diag(tau_u, 3, 3) %*% Cor_u %*% diag(tau_u, 3, 3)
# Create the correlated adjustments 
u <- mvrnorm(n = N_subj, c(0, 0, 0), Sigma_u)
# Check whether they are correctly correlated
# (There will be some random variation,
# but if you increase the number of observations and
# the value of the correlation, you'll be able to obtain
# a more exact value below)
cor(u)
# Check the SDs
sd(u[, 1]); sd(u[, 2]); sd(u[, 3])
# Create the simulated data
df_dots_simdata <- stimuli %>%
  mutate(z = rbern(N, prob = plogis(alpha_task + x2 * beta_task)),
         rt = ifelse(z,
             rlnorm(N, meanlog = alpha + u[subj, 1] +
                             (beta + u[subj, 2]) * x,
                    sdlog = sigma),
             rlnorm(N, meanlog = gamma + u[subj, 3],
                    sdlog = sigma2)),
         acc = ifelse(z, rbern(n = N, p_correct),
              rbern(n = N, .5)),
         diff = if_else(x == .5, "hard", "easy"),
         emphasis = ifelse(x2 == .5, "accuracy", "speed"))


## ---- echo = FALSE----------------------
simdata_dots <- function(N_subj = 20,
                         N_trials = 100,
                         # Parameters true values
                         alpha = 5.8,
                         beta = 0.05,
                         sigma = .4,
                         sigma2 = .5,
                         gamma = 5.2,
                         beta_task = 0.1,
                         p_btask = .8,
                         alpha_task = qlogis(p_btask),
                         p_correct = .995,
                         tau_u = c(.2,.005, .3),
                         rho = .3){
  N <- N_subj * N_trials
  stimuli <- tibble(x = rep(c(rep(-.5,N_trials/2), rep(.5, N_trials/2)), N_subj),
                  x2 = rep(rep(c(-.5,.5), N_trials/2), N_subj),
                  subj = rep(1:N_subj, each = N_trials),
                  trial = rep(1:N_trials, N_subj)
                  )
  ## Build the data set here:
  N <- N_subj * N_trials
  stimuli <- tibble(x = rep(c(rep(-.5,N_trials/2),
                              rep(.5, N_trials/2)), N_subj),
                    x2 = rep(rep(c(-.5,.5), N_trials/2), N_subj),
                    subj = rep(1:N_subj, each = N_trials),
                    trial = rep(1:N_trials, N_subj)
                    )
  stimuli
  Cor_u <- matrix(rep(rho, 9), nrow = 3)
  diag(Cor_u) <- 1
  Cor_u
  # Variance covariance matrix for subjects:
  Sigma_u <- diag(tau_u, 3, 3) %*% Cor_u %*% diag(tau_u, 3, 3)
  # Create the correlated adjustments 
  u <- mvrnorm(n = N_subj, c(0, 0, 0), Sigma_u)
  # Check whether they are correctly correlated
  # (There will be some random variation,
  # but if you increase the number of observations and
  # the value of the correlation, you'll be able to obtain
  # a more exact value below)
  cor(u)
  # Check the SDs
  sd(u[, 1]); sd(u[, 2]); sd(u[, 3])
  # Create the simulated data
  df_dots_simdata <- stimuli %>%
    mutate(z = rbern(N, prob = plogis(alpha_task + x2 * beta_task)),
           rt = ifelse(z,
               rlnorm(N, meanlog = alpha + u[subj, 1] +
                               (beta + u[subj, 2]) * x,
                      sdlog = sigma),
               rlnorm(N, meanlog = gamma + u[subj, 3],
                      sdlog = sigma2)),
           acc = ifelse(z, rbern(n = N, p_correct),
                rbern(n = N, .5)),
           diff = if_else(x == .5, "hard", "easy"),
           emphasis = ifelse(x2 == .5, "accuracy", "speed"))
  ## # This matrix is symmetric, so it won't matter, but
  ## # be careful with how R arranges the matrix values
  ## Cor_u <- matrix(rep(rho, 9), nrow = 3)
  ## diag(Cor_u) <- 1
  ## Cor_u
  ## # Variance covariance matrix for 'subj':
  ## Sigma_u <- diag(tau_u,3,3) %*% Cor_u %*% diag(tau_u,3,3)
  ## # Create the correlated adjustments 
  ## u <- mvrnorm(n = N_subj, c(0, 0, 0), Sigma_u)
  ## # Create the data
  ## stimuli %>%
  ##   mutate(z = rbern(n = N, prob = plogis(alpha_task + x2 * beta_task)),
  ##          rt = ifelse(z,
  ##                      rlnorm(n = N, meanlog = alpha + u[subj, 1] +
  ##                                      (beta + u[subj, 2]) * x, sdlog = sigma),
  ##                      rlnorm(n = N, meanlog = gamma + u[subj, 3], sdlog = sigma2)),
  ##          acc = ifelse(z, rbern(n = N, p_correct),
  ##                       rbern(n = N, .5)),
  ##          diff = if_else(x == .5, "hard", "easy"),
  ##          emphasis = ifelse(x2 == .5, "accuracy", "speed"))
  df_dots_simdata
}


## ----simdatartacc, fig.cap = "(ref:simdatartacc)",message = FALSE----
ggplot(df_dots_simdata, aes(x = factor(acc), y = rt)) +
  geom_point(position = position_jitter(width = .4, 
                                        height = 0), alpha = .5) +
  facet_wrap(diff ~ emphasis) +
  xlab("Accuracy") +
  ylab("Response time")


## NA

## ----fitmixture_hsim, results = "hide", message = "FALSE", eval = !file.exists("dataR/fit_mix_h.RDS")----
ls_dots_simdata <- list(N = N,
                        rt = df_dots_simdata$rt,
                        x = df_dots_simdata$x,
                        x2 = df_dots_simdata$x2,
                        acc = df_dots_simdata$acc,
                        subj = df_dots_simdata$subj,
                          N_subj = N_subj)
mixture_h <- system.file("stan_models",
                        "mixture_h.stan",
                        package = "bcogsci")
fit_mix_h <- stan(file = mixture_h,
                  data = ls_dots_simdata,
                  iter = 3000,
                  control = list(adapt_delta = .9))


## ---- echo= FALSE-----------------------
if(!file.exists("dataR/fit_mix_h.RDS")){
  saveRDS(df_dots_simdata,"dataR/df_dots_simdata.RDS")
  saveRDS(fit_mix_h,"dataR/fit_mix_h.RDS")
} else {
  fit_mix_h <- readRDS("dataR/fit_mix_h.RDS")
  df_dots_simdata_h <- readRDS("dataR/df_dots_simdata_h.RDS")
}


## ---------------------------------------
print(fit_mix_h, pars = c("alpha", "beta", "sigma", "gamma", "sigma2",
                          "p_correct","p_btask", "beta_task", "tau_u",
                          "rho_u[1,2]", "rho_u[1,3]", "rho_u[2,3]"))


## ----hackmix, echo = FALSE--------------
select <- dplyr::select


## ---- message = FALSE-------------------
df_fit_mix_h <- fit_mix_h %>% as.data.frame() %>%
  select(c("alpha", "beta", "sigma", "gamma", "sigma2",
           "p_correct","p_btask", "beta_task", "tau_u[1]",
           "tau_u[2]", "tau_u[3]", "rho_u[1,2]", "rho_u[1,3]",
           "rho_u[2,3]"))
true_values <- c(alpha, beta, sigma, gamma, sigma2,
                p_correct, p_btask, beta_task, tau_u[1],
                tau_u[2], tau_u[3], rep(rho,3))
mcmc_recover_hist(df_fit_mix_h, true_values)


## ----fitmixture_h, echo = FALSE, results = "hide", message = "FALSE", eval = FALSE----
## !file.exists("dataR/fit_mix_hl.RDS")
## df_dots_simdatal <- simdata_dots(N_trials = 2800)
## ls_dots_simdatal <- list(N = N,
##                          rt = df_dots_simdatal$rt,
##                          x = df_dots_simdatal$x,
##                          x2 = df_dots_simdatal$x2,
##                           acc = df_dots_simdatal$acc,
##                           subj = df_dots_simdatal$subj,
##                          N_subj = N_subj)
## # This model needs more samples than the usual to get good ESS:
## fit_mix_hl <- stan(file = mixture_h,
##                    data = ls_dots_simdatal)


## ---- eval = FALSE, echo = FALSE--------
## if(!file.exists("dataR/fit_mix_h.RDS")){
##   saveRDS(ls_dots_simdatal,"dataR/ls_dots_simdatal.RDS")
##   saveRDS(fit_mix_hl,"dataR/fit_mix_hl.RDS")
## } else {
##   fit_mix_hl <- readRDS("dataR/fit_mix_hl.RDS")
## }


## ---- message = FALSE, echo = FALSE, eval = FALSE----
## df_fit_mix_h <- fit_mix_hl %>% as.data.frame() %>%
##   select(c("alpha", "beta", "sigma", "gamma", "sigma2",
##            "p_correct","p_btask", "beta_task", "tau_u[1]",
##            "tau_u[2]", "tau_u[3]", "rho_u[1,2]", "rho_u[1,3]",
##            "rho_u[2,3]"))
## true_values <- c(alpha, beta, sigma, gamma, sigma2,
##                 p_correct, p_btask, beta_task, tau_u[1],
##                 tau_u[2], tau_u[3], rep(rho,3))
## mcmc_recover_hist(df_fit_mix_h, true_values)


## ---------------------------------------
df_dots <- df_dots %>%
  mutate(x = if_else(diff == "easy", -.5, .5),
         x2 = if_else(emphasis == "accuracy", .5, -.5))


## ---------------------------------------
df_dots_data_short <- df_dots %>%
  group_by(subj) %>% 
  sample_n(600)


## ----  eval = !file.exists("dataR/stanfit_short.RDS")----
ls_dots_data_short <-
  list(N = nrow(df_dots_data_short),
       rt = df_dots_data_short$rt,
       x = df_dots_data_short$x,
       x2 = df_dots_data_short$x2,
       acc = df_dots_data_short$acc,
       subj = as.numeric(df_dots_data_short$subj),
       N_subj = length(unique(df_dots_data_short$subj)))
fit_mix_data <- stan(file = mixture_h,
                     data = ls_dots_data_short,
                     chains = 4,
                     iter = 2000,
                     control = list(adapt_delta =.9,
                                    max_treedepth = 12))


## ----echo = FALSE-----------------------
if(!file.exists("dataR/stanfit_short.RDS")){
  saveRDS(fit_mix_data,"dataR/stanfit_short.RDS")
  saveRDS(ls_dots_data_short ,"dataR/dots_short.RDS")
} else {
  fit_mix_data <- readRDS("dataR/stanfit_short.RDS")
  ls_dots_data_short <- readRDS("dataR/dots_short.RDS")
}


## ---------------------------------------
print(fit_mix_data,
      pars = c("alpha", "beta", "sigma", "gamma", "sigma2",
               "p_correct","p_btask", "beta_task", "tau_u",
               "rho_u[1,2]", "rho_u[1,3]", "rho_u[2,3]"))


## ----traceplotmulti, fig.cap = "(ref:traceplotmulti)", message = FALSE----
traceplot(fit_mix_data)


## ----mixture_hs, echo = FALSE-----------
mixture_h2 <- system.file("stan_models",
                        "mixture_h2.stan",
                        package = "bcogsci")


## NA

## ----   eval = !file.exists("dataR/stanfit_s.RDS")----

fit_mixs_data <- stan(file = mixture_h,
                     data = ls_dots_data_short,
                     chains = 4,
                     iter = 2000,
                     control = list(adapt_delta =.9,
                                    max_treedepth = 12))




## ----echo = FALSE-----------------------
if(!file.exists("dataR/stanfit_s.RDS")){
  saveRDS(fit_mixs_data,"dataR/stanfit_s.RDS")
} else {
  fit_mixs_data <- readRDS("dataR/stanfit_s.RDS")
}


## ---------------------------------------
print(fit_mixs_data,
      pars = c("alpha", "beta", "sigma", "gamma", "sigma2",
               "p_btask", "beta_task", "tau_u",
               "rho_u[1,2]", "rho_u[1,3]", "rho_u[2,3]"))


## ----traceplotnomulti, fold=TRUE, fig.cap = "(ref:traceplotnomulti)", message = FALSE----
traceplot(fit_mixs_data)


## ----  echo = FALSE, eval = FALSE-------
## #cmdstanr code: not in use
## tic()
## library(cmdstanr)
## mod <- cmdstan_model(mixture_h)
## mod_s <- cmdstan_model("mixture_h2.stan")
## #mod2 <- cmdstan_model("mixture_h2.stan")
## #mod3 <- cmdstan_model("mixture_h3.stan")
## fit_short_mv <- mod$sample(
##   data = ls_dots_data_short,
##   seed = 123,
##   adapt_delta =.95,
##   max_treedepth = 12,
##   chains = 4,
##   iter_warmup = 1000,
##   iter_sampling = 1000,
##   parallel_chains = 4,
##   refresh = 100
## )
## 
## fit_short_m <- mod$sample(
##   data = ls_dots_data_short,
##   seed = 123,
##   adapt_delta =.95,
##   max_treedepth = 12,
##   chains = 10,
##   iter_warmup = 1000,
##   iter_sampling = 1000,
##   parallel_chains = 10,
##   refresh = 100
## )
## 
## fit_short_s <- mod_s$sample(
##   data = ls_dots_data_short,
##   seed = 123,
##   adapt_delta =.95,
##   max_treedepth = 12,
##   chains = 4,
##   iter_warmup = 1000,
##   iter_sampling = 1000,
##   parallel_chains = 4,
##   refresh = 100
## )
## fit_short_s$draws(c("alpha","beta","sigma","sigma2","p_btask","beta_task")) %>%
##   mcmc_trace()
## mod <- cmdstan_model(mixture_h)
## fit_all <- mod$sample(
##   data = ls_dots_data,
##   seed = 123,
##   adapt_delta =.9,
##   max_treedepth = 13,
##   chains = 4,
##   parallel_chains = 4,
##   refresh = 500
## )
## 
## 
## 
## toc()


## NA

## ---- eval = FALSE, eval = !file.exists("dataR/gen_mix_data.RDS")----
mixture_h_gen <- system.file("stan_models",
                            "mixture_h_gen.stan",
                            package = "bcogsci")
gen_model <- stan_model(mixture_h_gen)
draws_par <- as.matrix(fit_mixs_data)[1:500, ,drop = FALSE]
gen_mix_data <- gqs(gen_model,
                    data = ls_dots_data_short,
                    draws = draws_par)


## ---- echo = FALSE----------------------
if(!file.exists("dataR/gen_mix_data.RDS")){
  saveRDS(gen_mix_data,"dataR/gen_mix_data.RDS")
} else {
  gen_mix_data <- readRDS("dataR/gen_mix_data.RDS")
}


## ----postpmix, message = FALSE, fig.cap = "(ref:postpmix)"----
rt_pred <- extract(gen_mix_data)$rt_pred 
ppc_dens_overlay(y = ls_dots_data_short$rt, yrep = rt_pred[1:100,]) +
  coord_cartesian(xlim = c(0, 2000)) 


## ----postpmanip, message = FALSE, fig.cap = "(ref:postpmanip)"----
meanrt_diff <- function(rt){
  mean(rt[ls_dots_data_short$x == .5]) -
    mean(rt[ls_dots_data_short$x == -.5])
}  
ppc_stat(ls_dots_data_short$rt,
         yrep = rt_pred,
         stat = meanrt_diff) 


## ---------------------------------------
acc_pred <- extract(gen_mix_data)$acc_pred
df_dots_pred <-
  tibble(rt = ls_dots_data_short$rt,
         acc = ls_dots_data_short$acc,
         difficulty = ifelse(ls_dots_data_short$x==.5,
                             "hard", "easy"),
         emphasis = ifelse(ls_dots_data_short$x2 ==-.5,
                           "speed", "accuracy"),
         acc_pred1 = acc_pred[1,],
         rt_pred1 = rt_pred[1,])


## ----postppdobs, echo = FALSE, fig.cap = "(ref:postppdobs)"----
ggplot(df_dots_pred, aes(x = factor(acc), y = rt)) +
  geom_point(shape = 0,
             position = position_jitter(width = .4, height = 0),
             color = "gray",
             alpha = .8) +
  geom_point(aes(x = factor(acc_pred1), y = rt_pred1), color = "black",
             position = position_jitter(width = .4, height = 0),
             alpha = .5) +
  facet_wrap(difficulty ~ emphasis) +
  xlab("Accuracy") +
  ylab("Response time") 


## ----echo = FALSE-----------------------
## if(!file.exists("dataR/fit_mv_data.RDS")){
##   saveRDS(fit_mv_data,"dataR/fit_mv_data.RDS")
## } else {
##   fit_mv_data <- readRDS("dataR/fit_mv_data.RDS")
## }


## Changes in the true values.


## Guessing bias in the model.


## More hierarchical parameters.

