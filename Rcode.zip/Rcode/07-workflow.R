## ----figPriorPredCh, echo=FALSE, fig.height=2.5, fig.width=3*3, fig.cap="Prior predictive checks. a) In a first step, define a summary statistic that one wants to investigate. b) Second, define extremity thresholds (shaded areas), for which one does not expect a lot of prior data. c) Third, simulate prior model predictions for the data (histogram) and compare them with the extreme values (shaded areas).", message=FALSE, results="hide"----

c_light <- "#DCBCBC"
c_light_highlight <- "#C79999"
c_mid <- "#B97C7C"
c_mid_highlight <- "#A25050"
c_dark <- "#8F2727"
c_dark_highlight <- "#7C0000"

set.seed(123)
d <- data.frame(x = rnorm(250, 1, 1))
pPPC_A <- ggplot() +
  stat_bin(data = d, aes(x = x, y = ..density..), geom = "blank", bins=30) +
  geom_blank(aes(x = -3.5, y = 0.6), stat = "identity") + #, width = 3, fill = c_mid
  geom_blank(aes(x = +5.5, y = 0.6), stat = "identity") + # , width = 3, fill = c_mid
  geom_blank(aes(x = c(-2, -2), y = c(0, 0.6))) + # , size = 2, colour = c_dark
  geom_blank(aes(x = c(+4, +4), y = c(0, 0.6))) + # , size = 2, colour = c_dark
  # geom_line(aes(x=c(-3.5,-2),y=c(0.3,0.3)), arrow=arrow(length=unit(0.30,"cm"), ends="first", type = "closed"), colour=c_dark, size=2)+
  # geom_line(aes(x=c(4,5.5),y=c(0.3,0.3)), arrow=arrow(length=unit(0.30,"cm"), ends="last", type = "closed"), colour=c_dark, size=2)+
  labs(x = "Summary Statistic [t(y_pred)]") +
  theme(axis.text.x = element_blank(), axis.ticks.x = element_blank())

pPPC_B <- ggplot() + # stat_bin(data=d, aes(x=x, y=..density..)) +
  geom_bar(aes(x = -3.5, y = 0.6), stat = "identity", width = 3, fill = c_mid) +
  geom_bar(aes(x = +5.5, y = 0.6), stat = "identity", width = 3, fill = c_mid) +
  geom_line(aes(x = c(-2, -2), y = c(0, 0.6)), size = 2, colour = c_dark) +
  geom_line(aes(x = c(+4, +4), y = c(0, 0.6)), size = 2, colour = c_dark) +
  geom_line(aes(x = c(-3.5, -2), y = c(0.3, 0.3)), arrow = arrow(length = unit(0.30, "cm"), ends = "first", type = "closed"), colour = c_dark, size = 2) +
  geom_line(aes(x = c(4, 5.5), y = c(0.3, 0.3)), arrow = arrow(length = unit(0.30, "cm"), ends = "last", type = "closed"), colour = c_dark, size = 2) +
  labs(x = "Summary Statistic [t(y_pred)]", y = "density") +
  theme(axis.text.x = element_blank(), axis.ticks.x = element_blank())

pPPC_C <- ggplot() +
  stat_bin(data = d, aes(x = x, y = ..density..), bins=30) +
  geom_bar(aes(x = -3.5, y = 0.6), stat = "identity", width = 3, fill = c_mid) +
  geom_bar(aes(x = +5.5, y = 0.6), stat = "identity", width = 3, fill = c_mid) +
  geom_line(aes(x = c(-2, -2), y = c(0, 0.6)), size = 2, colour = c_dark) +
  geom_line(aes(x = c(+4, +4), y = c(0, 0.6)), size = 2, colour = c_dark) +
  geom_line(aes(x = c(-3.5, -2), y = c(0.3, 0.3)), arrow = arrow(length = unit(0.30, "cm"), ends = "first", type = "closed"), colour = c_dark, size = 2) +
  geom_line(aes(x = c(4, 5.5), y = c(0.3, 0.3)), arrow = arrow(length = unit(0.30, "cm"), ends = "last", type = "closed"), colour = c_dark, size = 2) +
  labs(x = "Summary Statistic [t(y_pred)]") +
  theme(axis.text.x = element_blank(), axis.ticks.x = element_blank())

# quartz(width=3*3, height=2.5)
cowplot::plot_grid(pPPC_A, pPPC_B, pPPC_C, labels = c("a", "b", "c"), ncol = 3)


## ----FigBayes, echo=FALSE, fig.width=6, fig.height=6, fig.cap="The role of priors for informative and uninformative data. a)-c) When the data provides good information via the likelihood (b), then a flat uninformative prior (a) is sufficient to obtain a concentrated posterior (c). d)-f) When the data does not sufficiently constrain the parameters through the likelihood (e), then using a flat uninformative prior (d) also leaves the posterior (f) widely spread out. g)-i) When the data does not constrain the parameter through the likelihood (h), then including domain expertise through an informative prior (g) can help to constrain the posterior (i) to reasonable values.", message=FALSE, results="hide"----

FigBay <- function(corr) {
  sigma <- matrix(c(1, corr, corr, 1), nrow = 2)
  m <- c(0, 0)
  data.grid <- expand.grid(s.1 = seq(-3, 3, length.out = 200), s.2 = seq(-3, 3, length.out = 200))
  q.samp <- cbind(data.grid, prob = mvtnorm::dmvnorm(data.grid, mean = m, sigma = sigma))
  FigBay3c <- ggplot(q.samp, aes(x = s.1, y = s.2)) +
    geom_raster(aes(fill = prob)) +
    scale_fill_gradient(low="white",high=c_dark,guide=FALSE)+
    #scale_fill_gradient(guide = FALSE) +
    labs(x = "", y = "") +
    coord_fixed(xlim = c(-3, 3), ylim = c(-3, 3), ratio = 1) +
    # papaja::theme_apa() +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.background = element_rect(colour = "black", size = 4, fill = NA),
      axis.text.x = element_blank(), axis.ticks.x = element_blank(),
      axis.text.y = element_blank(), axis.ticks.y = element_blank()
    )
  return(FigBay3c)
}

sigma <- matrix(c(1, -0.9, -0.9, 1), nrow = 2)
m <- c(0, 0)
data.grid <- expand.grid(s.1 = seq(-3, 3, length.out = 200), s.2 = seq(-3, 3, length.out = 200))
q.samp <- cbind(data.grid, prob = mvtnorm::dmvnorm(data.grid, mean = m, sigma = sigma))
maxQ <- max(q.samp$prob)
mINQ <- min(q.samp$prob)
s1 <- unique(q.samp$s.1)
q.samp$prob2 <- NA
for (i in 1:length(s1)) { # i <- 1
  idxQ <- which(q.samp$s.1 == s1[i])
  q.samp$prob2[idxQ] <- dnorm(q.samp$s.2[idxQ], -s1[i], 1)
}
q.samp$prob <- q.samp$prob2
FigBay2bc3b <- ggplot(q.samp, aes(x = s.1, y = s.2)) +
  geom_raster(aes(fill = prob)) +
  scale_fill_gradient(low="white",high=c_dark,guide=FALSE)+
  #scale_fill_gradient(guide = FALSE) +
  labs(x = "", y = "") +
  coord_fixed(xlim = c(-3, 3), ylim = c(-3, 3), ratio = 1) +
  # papaja::theme_apa() +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_rect(colour = "black", size = 4, fill = NA),
    axis.text.x = element_blank(), axis.ticks.x = element_blank(),
    axis.text.y = element_blank(), axis.ticks.y = element_blank()
  )

FigBay1a2a <- FigBay(1) + labs(title = "Prior")
FigBay3c <- FigBay(-0.7) + labs(title = "Posterior")

FigBay1bc3a <- FigBay(0)
FigBay1b <- FigBay1bc3a + labs(title = "Likelihood")
FigBay1c <- FigBay1bc3a + labs(title = "Posterior")
FigBay3a <- FigBay1bc3a + labs(title = "Prior")

FigBay2b3b <- FigBay2bc3b + labs(title = "Likelihood")
FigBay2c <- FigBay2bc3b + labs(title = "Posterior")

cowplot::plot_grid(FigBay1a2a, FigBay1b, FigBay1c,
  FigBay1a2a, FigBay2b3b, FigBay2c,
  FigBay3a, FigBay2b3b, FigBay3c,
  labels = c("a", "b", "c", "d", "e", "f", "g", "h", "i"), ncol = 3
)


## ----FigPostPredCh, echo=FALSE, fig.height=2.5, fig.width=5, fig.cap="Posterior predictive checks. Compare posterior model predictions (histogram) with observed data (vertical line) for a specific summary statistic, t(y). a) This displays a case where the observed summary statistic (vertical line) lies within the posterior model predictions (histogram). b) This displays a case where the summary statistic of the observed data (vertical line) lies clearly outside of what the model predicts a posteriori (histogram).", message=FALSE, results="hide"----

set.seed(123)
dx <- rnorm(250, 1, 1)
d <- data.frame(x = c(dx, dx), y = rep(c(1.4, 6), each = 250), cond = rep(c("a", "b"), each = 250))
ggplot(data = d, aes(x = x, y = ..density..)) +
  stat_bin() +
  geom_vline(aes(xintercept = y)) +
  facet_wrap(~cond) +
  labs(x = "Summary Statistic [t(y)]") +
  theme(axis.text.x = element_blank(), axis.ticks.x = element_blank())


## ---------------------------------------
priors <- c(
  prior(normal(0, 10), class = Intercept),
  prior(normal(0, 1), class = b, coef = so),
  prior(normal(0, 1), class = sd),
  prior(normal(0, 1), class = sigma),
  prior(lkj(2), class = cor)
)


## ----FigLKJ, echo=FALSE, fig.cap="Shape of the LKJ prior. This is the prior density for the random effects correlation parameter, here used as a prior for the correlation between the effect size (so) and the intercept. The shape shows that correlation estimates close to zero are expected, and that very strong positive correlations (close to 1) or negative correlations (close to -1) are increasingly unlikely. Thus, correlation estimates are regularized towards values of zero.", fig.height=3, fig.width=3----

idx <- seq(-1, +1, by = 0.01)
dd <- c()
for (i in 1:length(idx)) {
  x <- matrix(c(1, idx[i], idx[i], 1), ncol = 2, nrow = 2)
  dd[i] <- rethinking::dlkjcorr(x, eta = 2, log = FALSE)
}
# quartz(width=3,height=3)
qplot(x = idx, y = dd, geom = "line") + labs(x = "Correlation", y = "") + theme_bw()


## ----simPrior1, cache=TRUE, message=FALSE, results="hide"----
data("df_gibsonwu")
df_gibsonwu <- df_gibsonwu %>%
  mutate(so = ifelse(type == "obj-ext", 1, -1))
set.seed(123)
fit_prior_gibsonwu <- brm(rt ~ so + (so | subj) + (so | item),
  data = df_gibsonwu,
  family = lognormal(),
  prior = priors,
  sample_prior = "only"
)


## ----figPrior1a, echo=FALSE, message = FALSE, fig.cap="Prior predictive checks for a high-variance prior. Multivariate summary statistic: Distribution of histograms of reading times shows very short and also very long reading times are expected too frequently by the uninformative prior."----

nsim <- 1000
rtfakemat <- t(posterior_predict(fit_prior_gibsonwu, ndraws = nsim))

## This code is based on Michael Betancourt's posts on his home page.
# Colour codes to use
c_light <- "#DCBCBC"
c_light_highlight <- "#C79999"
c_mid <- "#B97C7C"
c_mid_highlight <- "#A25050"
c_dark <- "#8F2727"
c_dark_highlight <- "#7C0000"
# set very large data points to a value of 2000
rtfakematH <- rtfakemat
rtfakematH[rtfakematH > 2000] <- 2000
# Compute one histogram per simulated dataset
binwidth <- 20
breaks <- seq(0, max(rtfakematH, na.rm = TRUE) + binwidth, binwidth)
histmat <- matrix(NA, ncol = nsim, nrow = length(breaks) - 1)
for (i in 1:nsim) {
  histmat[, i] <- hist(rtfakematH[, i], breaks = breaks, plot = FALSE)$counts
}
# For each bin, compute quantiles across histograms
probs <- seq(0.1, 0.9, 0.1)
quantmat <- as.data.frame(matrix(NA, nrow = dim(histmat)[1], ncol = length(probs)))
names(quantmat) <- paste0("p", probs)
for (i in 1:dim(histmat)[1]) {
  quantmat[i, ] <- quantile(histmat[i, ], p = probs)
}
quantmat$x <- breaks[2:length(breaks)] - binwidth / 2 # add bin mean
# Plot
fig_pri_1a <- ggplot(data = quantmat, aes(x = x)) +
  geom_ribbon(aes(ymax = p0.9, ymin = p0.1), fill = c_light) +
  geom_ribbon(aes(ymax = p0.8, ymin = p0.2), fill = c_light_highlight) +
  geom_ribbon(aes(ymax = p0.7, ymin = p0.3), fill = c_mid) +
  geom_ribbon(aes(ymax = p0.6, ymin = p0.4), fill = c_mid_highlight) +
  geom_line(aes(y = p0.5), colour = c_dark, size = 1) +
  ## labs(title = "Prior Pred. Distr.", y = "", x = "Reading Time [ms]")
  labs(y = "", x = "RT [ms]")
fig_pri_1a 
# dist_hist <- function(x) {
#  binwidth <- 20
#  breaks <- seq(0, max(x, na.rm = TRUE) + binwidth, binwidth)
#  histmat <- hist(x, breaks = breaks, plot = FALSE)$counts
# }
# fig_pri_1a <- pp_check(fit_prior_gibsonwu, type="stat", stat="mean") +
#  labs(x = "Reading Time [ms]") + theme(legend.position="none")


## ----s2000, echo=TRUE, message=FALSE,  fig.cap ="Prior predictive distribution of average reading times shows that extremely large reading times of more than 2000 ms are too frequently expected. Distribution of standard deviations of reading times shows that very large variances are over-expected in the priors. Values larger than 2000 are plotted at a value of 2000 for visualization." , message= FALSE, fig.width = 2.2, fig.height = 2.2, fig.show = "hold",  fig.align='center', out.width = '48%'----
mean_2000 <- function(x) {
  tmp <- mean(x)
  tmp[tmp > 2000] <- 2000
  tmp
}
sd_2000 <- function(x) {
  tmp <- sd(x)
  tmp[tmp > 2000] <- 2000
  tmp
}
pp_check(fit_prior_gibsonwu, type = "stat", stat = "mean_2000") +
  labs(x = "Mean RT [ms]") + 
  theme(legend.position = "none")
pp_check(fit_prior_gibsonwu, type = "stat", stat = "sd_2000") +
  labs(x = "Standard Deviation RT [ms]") + 
  theme(legend.position = "none")


## ----diff2000, message = FALSE, fig.cap = "Prior predictive distribution of differences in reading times between object minus subject relatives shows that very large effect sizes are far too frequently expected. Values larger than 2000 (or smaller than -2000) are plotted at a value of 2000 (or -2000) for visualization.", fig.height = 2.2----
effsize_2000 <- function(x) {
  tmp <- mean(x[df_gibsonwu$so == +1]) - 
         mean(x[df_gibsonwu$so == -1])
  tmp[tmp > +2000] <- +2000
  tmp[tmp < -2000] <- -2000
  tmp
}
pp_check(fit_prior_gibsonwu, type = "stat", stat = "effsize_2000") +
  labs(x = "Object - Subject [S-O RT]") + 
  theme(legend.position = "none")


## ----maximal2000, echo=TRUE, message = FALSE, results = "hide", fig.cap = "Maximal prior predicted effect size (object - subject relatives) across subjects again shows far too many extreme values and standard deviation of effect size (object - subject relatives) across subjects; again far too many extreme values are expected. Values > 2000 or < -2000 are plotted at a value of 2000 or -2000 for visualization.", fig.width = 2.2, fig.height = 2.2, fig.show = "hold",  fig.align='center', out.width = '48%'----
effsize_max_2000 <- function(x) {
  df_gibsonwu$rtfake <- x
  tmp <- df_gibsonwu %>%
    group_by(subj, so) %>%
    summarize(rtfake = mean(rtfake)) %>%
    # calculates the difference between conditions:
    summarize(dif =  rtfake[so == 1] - rtfake[so == -1])
  effect_size_max <- max(abs(tmp$dif), na.rm = TRUE)
  effect_size_max[effect_size_max > 2000] <- 2000
  effect_size_max
}
effsize_sd_2000 <- function(x) {
  df_gibsonwu$rtfake <- x
  tmp <- df_gibsonwu %>%
    group_by(subj, so) %>%
    summarize(rtfake = mean(rtfake)) %>%
    summarize(dif =  rtfake[so == 1] - rtfake[so == -1])
  effect_size_SD <- sd(tmp$dif, na.rm = TRUE)
  effect_size_SD[effect_size_SD > 2000] <- 2000
  effect_size_SD
}
pp_check(fit_prior_gibsonwu, 
                       type = "stat", 
                       stat = "effsize_max_2000") +
  labs(x = "Max Effect Size [S-O RT]") + 
  theme(legend.position = "none")
pp_check(fit_prior_gibsonwu, 
                       type = "stat", 
                       stat = "effsize_sd_2000") +
  labs(x = "SD Effect Size [S-O RT]") + 
  theme(legend.position = "none")


## ----figPrior1, echo=FALSE, fig.cap="Prior predictive checks for a high-variance prior. Distributions are over simulated hypothetical data. a) Multivariate summary statistic: Distribution of histograms of reading times shows very short and also very long reading times are expected too frequently by the uninformative prior. b)-f) Scalar summary statistics. Light blue/grey shows prior predictive distributions, dark blue/grey shows the data. b) Distribution of average reading times shows that extremely large reading times of more than 2000 ms are too frequently expected. c) Distribution of differences in reading times between object minus subject relatives shows that very large effect sizes are far too frequently expected. d) Distribution of standard deviations of reading times shows that very large variances are over-expected in the priors. e) Maximal effect size (object - subject relatives) across subjects again shows far too many extreme values. f) Standard deviation of effect size (object - subject relatives) across subjects; again far too many extreme values are expected. a)-f) Values > 2000 or < -2000 are plotted at a value of 2000 or -2000 for visualization.", fig.height=7*0.7, fig.width=6*0.7, message = FALSE, results = "hide", eval = FALSE----
## 
## txtSz <- 11
## # fig_pri_1a <- fig_pri_1a + theme_bw(base_size = txtSz)
## # fig_pri_1b <- fig_pri_1b + theme_bw(base_size = txtSz)
## # fig_pri_1c <- fig_pri_1c + theme_bw(base_size = txtSz)
## # fig_pri_1d <- fig_pri_1d + theme_bw(base_size = txtSz)
## # fig_pri_1e <- fig_pri_1e + theme_bw(base_size = txtSz)
## # fig_pri_1f <- fig_pri_1f + theme_bw(base_size = txtSz)
## 
## # grid.arrange(fig_pri_1a, fig_pri_1d, fig_pri_1b, fig_pri_1c, fig_pri_1e, fig_pri_1f, ncol=2)
## # quartz()
## cowplot::plot_grid(fig_pri_1a, fig_pri_1b, fig_pri_1c, fig_pri_1d, fig_pri_1e, fig_pri_1f, labels = c("a", "b", "c", "d", "e", "f"), ncol = 2, label_x = -0.02)


## ----figPriorAdjust1, echo=FALSE, fig.cap="Prior distribution in log-space and in ms-space for a toy example of a linear regression. a) Displays the prior distribution of the intercept in log-space. b) Displays the prior distribution of the intercept in ms-space. c) Displays the prior distribution of the effect size in log-space. d) Displays the prior distribution of the effect size in ms-space.", fig.height=5.5, fig.width=5.5----

nsimX <- 100000

# Intercept
dTmp <- data.frame(norm = rnorm(nsimX, 6, 0.6))
dTmp$expnorm <- exp(dTmp$norm)
pPAdj_A <- ggplot(data = dTmp, aes(x = norm, y = ..density..)) +
  geom_density() +
  labs(x = "Prior distribution in log-space\n[normal distribution]", title = "Intercept")
pPAdj_B <- ggplot(data = subset(dTmp, expnorm < 2500), aes(x = expnorm, y = ..density..)) +
  geom_density() +
  labs(x = "Prior distribution in ms space\n[lognormal distribution]", title = "Intercept")

# Effect size SO
dTmp2 <- data.frame(int = rnorm(nsimX, 6, 0.6), so = rnorm(nsimX, 0, 0.05))
dTmp2$cond1 <- dTmp2$int + dTmp2$so
dTmp2$cond2 <- dTmp2$int - dTmp2$so
dTmp2$logcond1 <- exp(dTmp2$cond1)
dTmp2$logcond2 <- exp(dTmp2$cond2)
dTmp2$expso <- dTmp2$logcond1 - dTmp2$logcond2
# I'm not sure whether this is correct?
pPAdj_C <- ggplot(data = dTmp2, aes(x = so, y = ..density..)) +
  geom_density() +
  labs(x = "Prior distribution in log-space\n[normal distribution]", title = "Effect size")
pPAdj_D <- ggplot(data = subset(dTmp2, abs(expso) < 2500), aes(x = expso, y = ..density..)) +
  geom_density() +
  labs(x = "Prior distribution in ms space\n[lognormal distribution]", title = "Effect size")

txtSz <- 11
pPAdj_A <- pPAdj_A + theme_bw(base_size = txtSz)
pPAdj_B <- pPAdj_B + theme_bw(base_size = txtSz)
pPAdj_C <- pPAdj_C + theme_bw(base_size = txtSz)
pPAdj_D <- pPAdj_D + theme_bw(base_size = txtSz)
# quartz(width=5.5,height=5.5)
cowplot::plot_grid(pPAdj_A, pPAdj_B, pPAdj_C, pPAdj_D, labels = c("a", "b", "c", "d"), ncol = 2, rel_widths = c(1, 1.2))


## ---------------------------------------
priors2 <- c(
  prior(normal(6, 0.6), class = Intercept),
  prior(normal(0, 0.05), class = b, coef = so),
  prior(normal(0, 0.1), class = sd),
  prior(normal(0, 0.5), class = sigma),
  prior(lkj(2), class = cor)
)


## ----simPrior2, include=FALSE, message = FALSE, results = "hide"----
set.seed(123)
fit_prior_gibsonwub <- brm(rt ~ so + (1 + so | subj) + (1 + so | item),
  data = df_gibsonwu,
  family = lognormal(),
  prior = priors2,
  sample_prior = "only"
)


## ----figPrior2a-f, include=FALSE, cache=TRUE, message = FALSE, results = "hide"----

rtfakemat2 <- t(posterior_predict(fit_prior_gibsonwub, ndraws = nsim))

# rtfakematH <- rtfakemat2; rtfakematH[rtfakematH>10000] <- NA
rtfakematH <- rtfakemat2
rtfakematH[rtfakematH > 2000] <- 2000
# Compute one histogram per simulated dataset
binwidth <- 20
breaks <- seq(0, max(rtfakematH, na.rm = TRUE) + binwidth, binwidth)
histmat <- matrix(NA, ncol = nsim, nrow = length(breaks) - 1)
for (i in 1:nsim) {
  histmat[, i] <- hist(rtfakematH[, i], breaks = breaks, plot = FALSE)$counts
}
# For each bin, compute quantiles across histograms
probs <- seq(0.1, 0.9, 0.1)
quantmat <- as.data.frame(matrix(NA, nrow = dim(histmat)[1], ncol = length(probs)))
names(quantmat) <- paste0("p", probs)
for (i in 1:dim(histmat)[1]) {
  quantmat[i, ] <- quantile(histmat[i, ], p = probs)
}
quantmat$x <- breaks[2:length(breaks)] - binwidth / 2 # add bin mean
# Plot
# maxcut <- 2000; quantmat0 <- quantmat[quantmat$x<maxcut,]
fig_pri_2a <- ggplot(data = quantmat, aes(x = x)) +
  geom_ribbon(aes(ymax = p0.9, ymin = p0.1), fill = c_light) +
  geom_ribbon(aes(ymax = p0.8, ymin = p0.2), fill = c_light_highlight) +
  geom_ribbon(aes(ymax = p0.7, ymin = p0.3), fill = c_mid) +
  geom_ribbon(aes(ymax = p0.6, ymin = p0.4), fill = c_mid_highlight) +
  geom_line(aes(y = p0.5), colour = c_dark, size = 1) +
  labs(y = "", x = "RT [ms]")

# Mean + SD
mean_2000 <- function(x) {
  tmp <- mean(x)
  tmp[tmp > 2000] <- 2000
  tmp
}
sd_2000 <- function(x) {
  tmp <- sd(x)
  tmp[tmp > 2000] <- 2000
  tmp
}
fig_pri_2b <- pp_check(fit_prior_gibsonwub, type = "stat", stat = "mean_2000") +
  labs(x = "Mean RT [ms]") + theme(legend.position = "none")
fig_pri_2d <- pp_check(fit_prior_gibsonwub, type = "stat", stat = "sd_2000") +
  labs(x = "Standard Deviation RT [ms]") + theme(legend.position = "none")
# Effect size
effsize_2000 <- function(x) {
  tmp <- mean(x[df_gibsonwu$so == +1]) - mean(x[df_gibsonwu$so == -1])
  tmp[tmp > +2000] <- +2000
  tmp[tmp < -2000] <- -2000
  tmp
}
fig_pri_2c <- pp_check(fit_prior_gibsonwub, type = "stat", stat = "effsize_2000") +
  labs(x = "Object - Subject [S-O RT]") + theme(legend.position = "none")
# effect size per subject
effsize_max_2000 <- function(x) {
  df_gibsonwu$rtfake <- x
  tmp <- df_gibsonwu %>%
    group_by(subj, so) %>%
    summarize(rtfake = mean(rtfake)) %>%
    spread(key = "so", value = "rtfake") %>%
    mutate(dif = `1` - `-1`)
  EffectSizeMax <- max(abs(tmp$dif), na.rm = TRUE)
  EffectSizeMax[EffectSizeMax > 2000] <- 2000
  EffectSizeMax
}
effsize_sd_2000 <- function(x) {
  df_gibsonwu$rtfake <- x
  tmp <- df_gibsonwu %>%
    group_by(subj, so) %>%
    summarize(rtfake = mean(rtfake)) %>%
    spread(key = "so", value = "rtfake") %>%
    mutate(dif = `1` - `-1`)
  EffectSizeSD <- sd(tmp$dif, na.rm = TRUE)
  EffectSizeSD[EffectSizeSD > 2000] <- 2000
  EffectSizeSD
}
fig_pri_2e <- pp_check(fit_prior_gibsonwub, type = "stat", stat = "effsize_max_2000") +
  labs(x = "Max Effect Size [S-O RT]") + theme(legend.position = "none")
fig_pri_2f <- pp_check(fit_prior_gibsonwub, type = "stat", stat = "effsize_sd_2000") +
  labs(x = "SD Effect Size [S-O RT]") + theme(legend.position = "none")


## ----figPrior2, echo=FALSE, fig.cap="Prior predictive checks after adjusting the priors. The figures show prior predictive distributions. a) Histograms of reading times. Shaded areas correspond to 10-90 percent, 20-80 percent, 30-70 percent, and 40-60 percent quantiles across histograms; the solid line indicates the median across hypothetical datasets. This now provides a much more reasonable range of expectations. b)-f) Light blue/grey shows prior predictive distributions, dark blue/grey shows the data. b) Average log reading times now span a more reasonable range of values. c) Differences in reading times between object minus subject relatives; the values are now much more constrained without lots of extreme values. d) Standard deviations of reading times; in contrast to the relatively uninformative priors, values are in a reasonable range. e) Maximal effect size (object - subject relatives) across subjects; again, prior expectations are now much more reasonable compared to the uninformative prior. f) Standard deviation of effect size (object minus subject relative reading times) across subjects; this no longer shows a dominance of extreme values any more. a)-f) Values > 2000 or < -2000 are plotted at 2000 or -2000 for visualization.", fig.height=7*0.7, fig.width=6*0.7, message = FALSE----

txtSz <- 11
# fig_pri_2a <- fig_pri_2a + theme_bw(base_size = txtSz)
# fig_pri_2b <- fig_pri_2b + theme_bw(base_size = txtSz)
# fig_pri_2c <- fig_pri_2c + theme_bw(base_size = txtSz)
# fig_pri_2d <- fig_pri_2d + theme_bw(base_size = txtSz)
# fig_pri_2e <- fig_pri_2e + theme_bw(base_size = txtSz)
# fig_pri_2f <- fig_pri_2f + theme_bw(base_size = txtSz)

cowplot::plot_grid(fig_pri_2a, fig_pri_2b, fig_pri_2c, fig_pri_2d, fig_pri_2e, fig_pri_2f, labels = c("a", "b", "c", "d", "e", "f"), ncol = 2, label_x = -0.02)


## ----brmPosterior, message=FALSE, results="hide"----
fit_gibsonwu <- brm(rt ~ so + (1 + so | subj) + (1 + so | item), 
  data = df_gibsonwu,
  family = lognormal(), 
  prior = priors2
)


## ---- eval = FALSE----------------------
## fit_gibsonwu

## ---- echo = FALSE, eval=FALSE----------
## short_summary(fit_gibsonwu) # round(fixef(fit_gibsonwu), 3)


## ----FigPosteriorB, fig.width=4, fig.height=3, fig.cap="Posterior distribution for the slope parameter, estimating the difference in reading times between object relative minus subject relative sentences.", message = FALSE----
mcmc_hist(fit_gibsonwu, pars = c("b_so")) +
  labs(x = "Object - subject relatives", 
       title = "Posterior distribution")


## ---- echo=TRUE-------------------------
postgw <- as_draws_df(fit_gibsonwu)
mean(postgw$b_so < 0)


## ----FigPosta-f, include=FALSE, message = FALSE , results = "hide"----

rtpostmat <- t(posterior_predict(fit_gibsonwu, ndraws = nsim))

rtpostmatH <- rtpostmat
rtpostmatH[rtpostmatH > 2000] <- 2000
# Compute one histogram per simulated dataset
binwidth <- 20
breaks <- seq(0, max(rtpostmatH, na.rm = TRUE) + binwidth, binwidth)
histmat <- matrix(NA, ncol = nsim, nrow = length(breaks) - 1)
for (i in 1:nsim) {
  histmat[, i] <- hist(rtpostmatH[, i], breaks = breaks, plot = FALSE)$counts
}
# For each bin, compute quantiles across histograms
probs <- seq(0.1, 0.9, 0.1)
quantmat <- as.data.frame(matrix(NA, nrow = dim(histmat)[1], ncol = length(probs)))
names(quantmat) <- paste0("p", probs)
for (i in 1:dim(histmat)[1]) {
  quantmat[i, ] <- quantile(histmat[i, ], p = probs)
}
quantmat$x <- breaks[2:length(breaks)] - binwidth / 2 # add bin mean
df_gibsonwu$rt[df_gibsonwu$rt > 2000] <- 2000
quantmat$data <- hist(df_gibsonwu$rt, breaks = breaks, plot = FALSE)$counts
# Plot
# maxcut <- 2000; quantmat0 <- quantmat[quantmat$x<maxcut,]
FigPosa <- ggplot(data = quantmat, aes(x = x)) +
  geom_ribbon(aes(ymax = p0.9, ymin = p0.1), fill = c_light) +
  geom_ribbon(aes(ymax = p0.8, ymin = p0.2), fill = c_light_highlight) +
  geom_ribbon(aes(ymax = p0.7, ymin = p0.3), fill = c_mid) +
  geom_ribbon(aes(ymax = p0.6, ymin = p0.4), fill = c_mid_highlight) +
  geom_line(aes(y = p0.5), colour = c_dark, size = 1, linetype = 3) +
  geom_line(aes(y = data), colour = c_dark_highlight, size = 1) +
  labs(title = "Posterior Predictive Distr.", y = "", x = "y")

# Mean + SD
mean_2000 <- function(x) {
  tmp <- mean(x)
  tmp[tmp > 2000] <- 2000
  tmp
}
sd_2000 <- function(x) {
  tmp <- sd(x)
  tmp[tmp > 2000] <- 2000
  tmp
}
FigPosb <- pp_check(fit_gibsonwu, type = "stat", stat = "mean_2000") +
  labs(x = "Mean RT [ms]") + theme(legend.position = "none")
FigPosd <- pp_check(fit_gibsonwu, type = "stat", stat = "sd_2000") +
  labs(x = "Standard Deviation RT [ms]") + theme(legend.position = "none")
# Effect size
effsize_2000 <- function(x) {
  tmp <- mean(x[df_gibsonwu$so == +1]) - mean(x[df_gibsonwu$so == -1])
  tmp[tmp > +2000] <- +2000
  tmp[tmp < -2000] <- -2000
  tmp
}
FigPosc <- pp_check(fit_gibsonwu, type = "stat", stat = "effsize_2000") +
  labs(x = "Object - Subject [S-O RT]") + theme(legend.position = "none")
# effect size per subject
effsize_max_2000 <- function(x) {
  df_gibsonwu$rtfake <- x
  tmp <- df_gibsonwu %>%
    group_by(subj, so) %>%
    summarize(rtfake = mean(rtfake)) %>%
    spread(key = "so", value = "rtfake") %>%
    mutate(dif = `1` - `-1`)
  EffectSizeMax <- max(abs(tmp$dif), na.rm = TRUE)
  EffectSizeMax[EffectSizeMax > 2000] <- 2000
  EffectSizeMax
}
effsize_sd_2000 <- function(x) {
  df_gibsonwu$rtfake <- x
  tmp <- df_gibsonwu %>%
    group_by(subj, so) %>%
    summarize(rtfake = mean(rtfake)) %>%
    spread(key = "so", value = "rtfake") %>%
    mutate(dif = `1` - `-1`)
  EffectSizeSD <- sd(tmp$dif, na.rm = TRUE)
  EffectSizeSD[EffectSizeSD > 2000] <- 2000
  EffectSizeSD
}
FigPose <- pp_check(fit_gibsonwu, type = "stat", stat = "effsize_max_2000") +
  labs(x = "Max Effect Size [S-O RT]") + theme(legend.position = "none")
FigPosf <- pp_check(fit_gibsonwu, type = "stat", stat = "effsize_sd_2000") +
  labs(x = "SD Effect Size [S-O RT]") + theme(legend.position = "none")


## ----FigPost, echo=FALSE, fig.cap="Posterior predictive checks for weakly informative priors. Distributions are over posterior predictive simulated data. a) Histograms of reading times. 10-90 percent, 20-80 percent, 30-70 percent, and 40-60 percent quantiles across histograms are shown as shaded areas; the median is shown as a dotted line and the observed data as a solid line. For illustration, values > 2000 are plotted as 2000; modeling was done on the original data. b)-f) Light blue/grey shows the posterior predictive distributions, dark blue/grey shows the data. b) Average reading times. c) Differences in reading times between object minus subject relatives. d) Standard deviations of reading times. e) Maximal effect size (object - subject relatives) across subjects. f) Standard deviation of effect size across subjects.", fig.height=7, fig.width=6, message = FALSE----

cowplot::plot_grid(FigPosa, FigPosb, FigPosc, FigPosd, FigPose, FigPosf, labels = c("a", "b", "c", "d", "e", "f"), ncol = 2, label_x = -0.02)

