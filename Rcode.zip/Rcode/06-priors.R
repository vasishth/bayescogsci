## ---- message = FALSE, results = "hide"----
data("df_gg05_rc")
df_gg05_rc <- df_gg05_rc %>%
mutate(c_cond = if_else(condition == "objgap", 1/2, -1/2))
fit_gg05 <- brm(RT ~ c_cond + (1 + c_cond || subj) + 
                  (1 + c_cond || item), df_gg05_rc)


## ---------------------------------------
(default_b <- posterior_summary(fit_gg05,
                                    variable = "b_c_cond"))


## ---------------------------------------
fit_lmer <- lmer(RT ~ c_cond + (1 + c_cond || subj) +
                  (1 + c_cond || item), df_gg05_rc)
b <- summary(fit_lmer)$coefficients["c_cond", "Estimate"]
SE <- summary(fit_lmer)$coefficients["c_cond", "Std. Error"]
## estimate of the slope and
## lower and upper bounds of the 95% CI:
(lmer_b <- c(b, b - (2 * SE), b + (2 * SE)))


## ----munifgg05 ,message=FALSE, results = "hide"----
fit_gg05_unif <- brm(RT ~ c_cond + (1 + c_cond || subj) +
                      (1 + c_cond || item),
       prior = c(
         prior(uniform(-2000, 2000), class = Intercept),
         prior(uniform(-2000, 2000), class = b, coef = "c_cond"),
         prior(normal(0, 500), class = sd),
         prior(normal(0, 500), class = sigma)),
       df_gg05_rc,
       control = list(adapt_delta = 0.999,
                      max_treedepth = 15))


## ---------------------------------------
(uniform_b <- posterior_summary(fit_gg05_unif, variable = c("b_c_cond")))


## ----slopesmeansCIs,echo=FALSE, tidy = FALSE, results= "asis"----
 slopes<-data.frame(rbind(lmer_b,
                          default_b[c(1,3,4)],
               uniform_b[c(1,3,4)]))
 slopes$model<-c("Frequentist","Default prior","Uniform")
 slopes<-slopes[c(4,1,2,3)]
 rownames(slopes)<-NULL
 colnames(slopes)<-c("model","mean","lower","upper")
kableExtra::kable(slopes,
                  digits = 0, booktabs = TRUE, 
                  vline = "", # format="latex",
  caption = "Estimates of the mean difference (with 95\\% confidence/credible intervals) between two conditions in a hierarchical model of English relative clause data from Grodner and Gibson, 2005, using (a) the frequentist hierarchical model, (b) a Bayesian model using default priors from the brm function, and (c) a Bayesian model with uniform priors.")


## ----initialguess,echo=FALSE,results = "hold",fig.height= 4.5, fig.cap =  "A truncated normal distribution representing a prior distribution on mean reading times.", echo = FALSE, warning = FALSE----
x<-seq(0,10000,by=0.01)
plot(x,extraDistr::dtnorm(x,mean = 300, sd = 1000, a = 0),type="l")


## ----echo=FALSE,message=FALSE,warning=FALSE----
data("df_gibsonwu")
df_gibsonwu$cond<-ifelse(df_gibsonwu$type=="obj-ext",1/2,-1/2)
m1<-lmer(rt~cond + (1+cond||subj) + (1+cond||item),df_gibsonwu)
vcm1 <- VarCorr(m1, comp = c("Std.Dev."))
vcm1<-data.frame(vcm1)[,c(1,2,5)]

data("df_gibsonwu2")
df_gibsonwu2$cond<-ifelse(df_gibsonwu2$condition=="obj-ext",1/2,-1/2)

m2<-lmer(rt~cond + (1+cond||subj) + (1+cond||item),df_gibsonwu2)
vcm2 <- VarCorr(m2, comp = c("Std.Dev."))
vcm2<-data.frame(vcm2)[,c(1,2,5)]

data("df_persianE1")
df_persianE1$pred<-ifelse(df_persianE1$predability=="predictable",
                          1/2,-1/2)
df_persianE1$dist<-ifelse(df_persianE1$distance=="long",
                          1/2,-1/2)
df_persianE1$distxpred<-df_persianE1$dist*df_persianE1$pred*2

m3<-lmer(rt~dist+pred+distxpred+
           (1+dist+pred+distxpred||subj)+
           (1+dist+pred+distxpred||item),
         df_persianE1)
vcm3 <- VarCorr(m3, comp = c("Std.Dev."))
vcm3<-data.frame(vcm3)[,c(1,2,5)]

data("df_dutch")
df_dutch$cond<-df_dutch$condition/2
m4<-lmer(exp(NP1)~cond+(1+cond||subject) +
           (1+cond||item),df_dutch)
vcm4 <- VarCorr(m4, comp = c("Std.Dev."))
vcm4<-data.frame(vcm4)[,c(1,2,5)]

data("df_english")
df_english$cond<-df_english$condition/2
m5<-lmer(exp(NP1)~cond+(1+cond||subject) +
           (1+cond||item),df_english)
vcm5 <- VarCorr(m5, comp = c("Std.Dev."))
vcm5<-data.frame(vcm5)[,c(1,2,5)]

data("df_smithE1")
df_smithE1$N2<-ifelse(df_smithE1$N2Factor=="N2pl",1/2,-1/2)
df_smithE1$Sem<-ifelse(df_smithE1$SemFactor=="SemSim",1/2,-1/2)
df_smithE1$N2xSem<-df_smithE1$N2*df_smithE1$Sem*2

m6<-lmer(RT~N2+Sem+N2xSem+(1+N2+Sem+N2xSem||Participant)+
           (1+N2+Sem+N2xSem||StimSet),df_smithE1)
vcm6 <- VarCorr(m6, comp = c("Std.Dev."))
vcm6<-data.frame(vcm6)[,c(1,2,5)]

data("df_smithE2")
df_smithE2$N2<-ifelse(df_smithE2$N2Factor=="N2pl",1/2,-1/2)
df_smithE2$Sem<-ifelse(df_smithE2$SemFactor=="SemSim",1/2,-1/2)
df_smithE2$Verb<-ifelse(df_smithE2$VerbFactor=="Vpl",1/2,-1/2)
df_smithE2$N2xSem<-df_smithE2$N2*df_smithE2$Sem*2
df_smithE2$N2xVerb<-df_smithE2$N2*df_smithE2$Verb*2
df_smithE2$SemxVerb<-df_smithE2$Sem*df_smithE2$Verb*2
df_smithE2$N2xSemxVerb<-df_smithE2$N2*df_smithE2$Sem*df_smithE2$Verb*4
m7<-lmer(RT~N2+Sem+N2xSem+N2xVerb+SemxVerb+N2xSemxVerb+
           (1+N2+Sem+N2xSem+N2xVerb+SemxVerb+N2xSemxVerb||Participant)+
           (1+N2+Sem+N2xSem+N2xVerb+SemxVerb+N2xSemxVerb||StimSet),
         df_smithE2)
vcm7 <- VarCorr(m7, comp = c("Std.Dev."))
vcm7<-data.frame(vcm7)[,c(1,2,5)]

data("df_VMJG18E1")
df_VMJG18E1$c_bvsa<-ifelse(df_VMJG18E1$cond=="a",1/2,
       ifelse(df_VMJG18E1$cond=="b",
                                 -1/2,0))
df_VMJG18E1$c_cvsb<-ifelse(df_VMJG18E1$cond=="b",1/2,
       ifelse(df_VMJG18E1$cond=="c",
                                 -1/2,0))
 df_VMJG18E1$c_dvsc<-ifelse(df_VMJG18E1$cond=="c",1/2,
       ifelse(df_VMJG18E1$cond=="d",
                                 -1/2,0))
m8<-lmer(rt~ c_bvsa+c_cvsb + c_dvsc+ (1+c_bvsa+c_cvsb + c_dvsc||subj)+(1+c_bvsa+c_cvsb + c_dvsc||item),df_VMJG18E1)
vcm8 <- VarCorr(m8, comp = c("Std.Dev."))
vcm8<-data.frame(vcm8)[,c(1,2,5)]

data("df_VMJG18E3")
df_VMJG18E3$c_bvsa<-ifelse(df_VMJG18E3$cond=="a",1/2,
       ifelse(df_VMJG18E3$cond=="b",
                                 -1/2,0))
df_VMJG18E3$c_cvsb<-ifelse(df_VMJG18E3$cond=="b",1/2,
       ifelse(df_VMJG18E3$cond=="c",
                                 -1/2,0))
 df_VMJG18E3$c_dvsc<-ifelse(df_VMJG18E3$cond=="c",1/2,
       ifelse(df_VMJG18E3$cond=="d",
                                 -1/2,0))
m9<-lmer(rt~ c_bvsa+c_cvsb + c_dvsc+ (1+c_bvsa+c_cvsb + c_dvsc||subj)+(1+c_bvsa+c_cvsb + c_dvsc||item),df_VMJG18E3)
vcm9 <- VarCorr(m9, comp = c("Std.Dev."))
vcm9<-data.frame(vcm9)[,c(1,2,5)]

data("df_VMJG18E5")
df_VMJG18E5$c_bvsa<-ifelse(df_VMJG18E5$cond=="a",1/2,
       ifelse(df_VMJG18E5$cond=="b",
                                 -1/2,0))
df_VMJG18E5$c_cvsb<-ifelse(df_VMJG18E5$cond=="b",1/2,
       ifelse(df_VMJG18E5$cond=="c",
                                 -1/2,0))
 df_VMJG18E5$c_dvsc<-ifelse(df_VMJG18E5$cond=="c",1/2,
       ifelse(df_VMJG18E5$cond=="d",
                                 -1/2,0))
m10<-lmer(rt~ c_bvsa+c_cvsb + c_dvsc+ (1+c_bvsa+c_cvsb + c_dvsc||subj)+(1+c_bvsa+c_cvsb + c_dvsc||item),df_VMJG18E5)
vcm10 <- VarCorr(m10, comp = c("Std.Dev."))
vcm10<-data.frame(vcm10)[,c(1,2,5)]

lens<-c(length(vcm1[,3]),length(vcm2[,3]),
        length(vcm3[,3]),length(vcm4[,3]),
        length(vcm5[,3]),length(vcm6[,3]),
        length(vcm7[,3]),length(vcm8[,3]),
        length(vcm9[,3]),length(vcm10[,3]))

id<-rep(1:10,lens)

vc<-rbind(vcm1[,c(2,3)],vcm2[,c(2,3)],
      vcm3[,c(2,3)],vcm4[,c(2,3)],
      vcm5[,c(2,3)],vcm6[,c(2,3)],
      vcm7[,c(2,3)],vcm8[,c(2,3)],
      vcm9[,c(2,3)],vcm10[,c(2,3)])

vcs<-data.frame(id=id,sds=vc)

colnames(vcs)[c(2,3)]<-c("vcname","sd")


residualsd<-vcs[is.na(vcs$vcname),]

intsds<-subset(vcs,vcname=="(Intercept)")
intsubj<-intsds[seq(1,20,by=2),]
intitem<-intsds[seq(1,20,by=2)+1,]

slopesds<-vcs[!is.na(vcs$vcname) &
                vcs$vcname!="(Intercept)",]

means<-c(mean(df_gibsonwu$rt),mean(df_gibsonwu2$rt),mean(df_persianE1$rt),mean(exp(df_dutch$NP1)),mean(exp(df_english$NP1)),mean(df_smithE1$RT),mean(df_smithE2$RT),mean(df_VMJG18E1$rt),mean(df_VMJG18E3$rt),mean(df_VMJG18E5$rt))


## ----rtdistrns, results = "hold",fig.height= 4.5, fig.cap =  "Distributions of reading times from ten self-paced reading studies. The two vertical lines mark the minimum and maximum means of the reading times in these ten studies.", echo = FALSE, warning = FALSE----
plot(density(df_gibsonwu$rt),ylim=c(0,0.0040),xlab="reading time (ms)",
     main="Distribution of reading times\n from 10 studies")
lines(density(df_gibsonwu2$rt),lty=2)
lines(density(df_persianE1$rt),lty=3)
lines(density(exp(df_dutch$NP1)),lty=4)
lines(density(exp(df_english$NP1)),lty=5)
lines(density(df_smithE1$RT),lty=6)
lines(density(df_smithE2$RT),lty=7)
lines(density(df_VMJG18E1$rt),lty=8)
lines(density(df_VMJG18E3$rt),lty=9)
lines(density(df_VMJG18E5$rt),lty=10)

abline(v=min(means),lty=2)
abline(v=max(means),lty=2)
text(min(means)-100,0.0035,label=as.character(round(min(means))))
text(max(means)+100,0.0035,label=as.character(round(max(means))))


## ---------------------------------------
intercept <- rnorm(100000,mean = 0, sd = 10)
slope <- rnorm(100000, mean = 0,sd = 1)
effect <- exp(intercept + slope/2) - exp(intercept - slope/2)
quantile(effect, prob = c(0.025, 0.975))


## ----logisticprior,echo=FALSE,results = "hold",fig.height= 4.5, fig.cap =  "The effect of normal priors defined on log-odds space for the intercept and slope in a logistic regression, transformed to probability space.", echo = FALSE, warning = FALSE----
mu1<-intercept + slope/2
mu2<-intercept - slope/2
p1<-exp(mu1)/(1+exp(mu1))
p2<-exp(mu2)/(1+exp(mu2))
pdiff<-p1-p2
op<-par(mfrow=c(1,2),pty="s")
hist(exp(intercept)/(1+exp(intercept)),freq=FALSE,
     main="Prior on intercept",
     xlab="probability")
hist(pdiff,freq=FALSE,
     main="Prior on slope",
     xlab="probability")


## ---- message = FALSE, results = "hide"----
restrictive_priors <- c(
  prior(normal(0, 10), class = Intercept),
  prior(normal(0, 10), class = b),
  prior(normal(0, 500), class = sd),
  prior(normal(0, 500), class = sigma)
)

fit_restrictive <- brm(RT ~ c_cond + (c_cond || subj) +
                         ( c_cond || item),
        prior = restrictive_priors,
        # Increase the iterations to avoid warnings
        iter = 4000,
        df_gg05_rc)


## ---------------------------------------
summary(fit_restrictive)


## ----vcs, fig.cap = "(ref:vcs)", echo=FALSE,results = "hold",fig.height= 4.5, echo = FALSE, warning = FALSE----
op<-par(mfrow=c(2,2),pty="s")
hist(intsubj$sd,main="Subject intercept SDs",freq=FALSE,
     xlim=c(0,max(intsubj$sd)),xlab="RTs (ms)")
x<-seq(0,800,by=0.01)
lines(x,extraDistr::dtnorm(x,mean(intsubj$sd),
                           sd(intsubj$sd)))
hist(intitem$sd,main="Item intercept SDs",freq=FALSE,
     xlim=c(0,max(intsubj$sd)),xlab="RTs (ms)")
lines(x,extraDistr::dtnorm(x,mean(intitem$sd),
                           sd(intitem$sd)))

hist(slopesds$sd,main="Slope SDs",freq=FALSE,
     xlim=c(0,max(slopesds$sd)),xlab="RTs (ms)")
lines(x,extraDistr::dtnorm(x,mean(slopesds$sd),
                           sd(slopesds$sd)))

hist(residualsd$sd,main="Residual SDs",freq=FALSE,
     xlim=c(0,max(residualsd$sd)),xlab="RTs (ms)")
lines(x,extraDistr::dtnorm(x,mean(residualsd$sd),
                           sd(residualsd$sd)))


## ----echo=FALSE,message=FALSE,warning=FALSE----
 inf_priors <- c(
  prior(normal(500, 100), class = Intercept),
  prior(normal(50, 50), class = b, coef="c_cond"),
  prior(normal(0, 300), class = sd),
  prior(normal(0, 500), class = sigma)
)

m_inf<-brm(RT~ c_cond + (1+c_cond||subj)+(1+c_cond||item),
        prior=inf_priors,
        chains=4,
        #iter = 2000,
        #warmup =1000,
        sample_prior="only",
        control = list(adapt_delta = 0.99,
                               max_treedepth=15),
        df_gg05_rc)
#summary(m_inf)
y_rep <- posterior_predict(m_inf)

y_rep<-as.vector(y_rep)

prior_pred<-data.frame(y_rep=y_rep,
                       iter=rep(1:1000,
                                each=dim(df_gg05_rc)[1]))


## ----priorpredgrodner,results = "hold",fig.height= 4.5, fig.cap =  "(ref:priorpredgrodner)", echo = FALSE, warning = FALSE, message = FALSE----
plots<-prior_pred %>%
filter(iter <= 8) %>% 
  ggplot(aes(y_rep)) + geom_histogram() + 
  facet_wrap(~iter, ncol = 2)
print(plots)


## ----echo=FALSE, results ="hide", message = FALSE----
posterior <- as.matrix(fit_gg05_unif)

m_inf<-brm(RT~ c_cond + (1+c_cond||subj)+(1+c_cond||item),
        prior=inf_priors,
        chains=4,
        cores=4,
        iter = 2000,
        warmup =1000,
        control = list(adapt_delta = 0.99,
                               max_treedepth=15),
        df_gg05_rc)


## ----uniformpriorENRC, fig.cap = "(ref:uniformpriorENRC)", echo=FALSE,results = "hold",fig.height= 4.5, echo = FALSE, warning = FALSE----
posteriorinf <- as.matrix(m_inf)

plot_title <- ggtitle("Posteriors (Uniform priors)",
                      "with medians and 80% intervals")

mcmc_areas(posterior,
           pars = c("b_Intercept","b_c_cond","sd_item__Intercept",   "sd_item__c_cond","sd_subj__Intercept","sd_subj__c_cond","sigma"),
           prob = 0.8) + plot_title


## ----infpriorENRC, fig.cap = "(ref:infpriorENRC)",echo=FALSE,results = "hold",fig.height= 4.5, echo = FALSE, warning = FALSE----
plot_title2 <- ggtitle("Posteriors (Informative priors)",
                      "with medians and 80% intervals")

mcmc_areas(posteriorinf,
           pars = c("b_Intercept","b_c_cond","sd_item__Intercept",   "sd_item__c_cond","sd_subj__Intercept","sd_subj__c_cond","sigma"),
           prob = 0.8) + plot_title2



## ----chinesemeans,echo=FALSE,results="asis"----
data("df_chineseRCs")
## remove the studies being investigated here:
df_chineseRCs<-df_chineseRCs[-c(2,3),]
kableExtra::kable(df_chineseRCs,
                  digits = 1, booktabs = TRUE, 
                  vline = "", # format="latex",
  caption = "The difference between object and subject relative clause reading times (effect), along with their standard errors (SE), from different published reading studies on Chinese relative clauses.")


## ----chinesemetanalysis,echo=FALSE,warning=FALSE,message=FALSE----
ls_chinese<-list(N=length(df_chineseRCs$y),
                 effect=df_chineseRCs$y,
                 SE=df_chineseRCs$se,
                 study_id=df_chineseRCs$study.id)
ma1 <- system.file("stan_models",
                   "meta-analysis1.stan",
                   package = "bcogsci") 
fit_chinese <- stan(
  file = ma1,
  data = ls_chinese,
   control = list(
    adapt_delta = .999,
    max_treedepth = 12
  )
)


## ----echo=FALSE-------------------------
#print.stanfit(fit_chinese,pars="zeta")
zeta_mean<-summary(fit_chinese,pars="zeta")$summary[1,1]
zeta_lower<-summary(fit_chinese,pars="zeta")$summary[1,2]
zeta_upper<-summary(fit_chinese,pars="zeta")$summary[1,3]


## ----chinesemetanalysisposterior, echo=FALSE, fig.cap = "(ref:chinesemetanalysisposterior)", message = FALSE----
bayesplot::mcmc_hist(as.data.frame(fit_chinese),
  pars = c("zeta")
)


## ---------------------------------------
data("df_gibsonwu")
df_gibsonwu <- df_gibsonwu %>%
  mutate(c_cond = if_else(type == "obj-ext", 1/2, -1/2))


## ---------------------------------------
int <- mean(log(df_gibsonwu$rt))
b <- 0.041
exp(int + b/2) - exp(int - b/2)
lower <- -0.079
exp(int + lower/2) - exp(int - lower/2)
upper <- 0.145
exp(int + upper/2) - exp(int - upper/2)


## ----message=FALSE, results = "hide"----
## uninformative priors on the parameters of interest
## and on the variance components:
fit_gibsonwu_log <- brm(rt ~ c_cond + 
                         (c_cond | subj) + 
                         (c_cond | item),
  family = lognormal(),
  prior =
    c(
      prior(normal(6, 1.5), class = Intercept),
      prior(normal(0, 1), class = b),
      prior(normal(0, 1), class = sigma),
      prior(normal(0, 1), class = sd),
      prior(lkj(2), class = cor)
    ),
  data = df_gibsonwu
)
## meta-analysis priors:
fit_gibsonwu_ma <- brm(rt ~ c_cond + 
                         (c_cond | subj) + 
                         (c_cond | item),
  family = lognormal(),
  prior =
    c(
      prior(normal(6, 1.5), class = Intercept),
      prior(normal(0.041, 0.2), class = b),
      prior(normal(0, 1), class = sigma),
      prior(normal(0, 1), class = sd),
      prior(lkj(2), class = cor)
    ),
  data = df_gibsonwu
)


## ----echo=FALSE-------------------------
post_summary <- posterior_summary(fit_gibsonwu_log, 
                  variable = "b_c_cond")
post_mean <- post_summary[1, 1]
post_lower <- post_summary[1, 3]
post_upper <- post_summary[1, 4]
post_sd <- post_upper - post_lower

post_summary_ma<-round(posterior_summary(fit_gibsonwu_ma, 
                  variable = "b_c_cond"),3)
post_mean_ma<-post_summary_ma[1,1]
post_lower_ma<-post_summary_ma[1,3]
post_upper_ma<-post_summary_ma[1,4]
post_sd<-post_upper_ma-post_lower_ma

posteriors_ma<-
  data.frame(rbind(c(post_mean,                                  post_lower,
                     post_upper),
c(post_mean_ma,post_lower_ma,post_upper_ma)))

posteriors_ma<-cbind(c("Normal(0,1)",
                    "Normal(0.041, 0.2)"),
      posteriors_ma)

colnames(posteriors_ma)<-c("Priors","Mean","Lower","Upper")


## ----mapriors,echo=FALSE,results="asis"----
kableExtra::kable(posteriors_ma,
                  digits = 2, booktabs = TRUE, 
                  vline = "", # format="latex",
  caption = "A summary of the posteriors under a relatively uninformative prior and an informative prior based on a meta-analysis, for the Chinese relative clause data from Gibson and Wu, 2013.")


## ----echo=FALSE,message=FALSE,warning=FALSE----
## replication attempt:
data("df_gibsonwu2")
df_gibsonwu2 <- df_gibsonwu2 %>%
  mutate(c_cond = if_else(condition == "obj-ext", 1/2, -1/2))

## relatively uninformative prior on the effect of interest
## and on the variance components:
fit_df_gibsonwu2 <- brm(rt ~ c_cond + 
                                (c_cond | subj) + (c_cond | item),
  family = lognormal(),
  prior =
    c(
      prior(normal(6, 1.5), class = Intercept),
      prior(normal(0, 1), class = b),
      prior(normal(0, 1), class = sigma),
      prior(normal(0, 1), class = sd),
      prior(lkj(2), class = cor)
    ),
  data = df_gibsonwu2
)
post_summary2<-round(posterior_summary(fit_df_gibsonwu2, 
                  variable = "b_c_cond"),3)
post_mean2<-post_summary2[1,1]
post_lower2<-post_summary2[1,3]
post_upper2<-post_summary2[1,4]

## informative prior:
fit_df_gibsonwu2_inf <- brm(rt ~ c_cond + 
                              (c_cond | subj) + (c_cond | item),
  family = lognormal(),
  prior =
    c(
      prior(normal(6, 1.5), class = Intercept),
      prior(normal(-0.07,0.2), class = b),
      prior(normal(0, 1), class = sigma),
      prior(normal(0, 1), class = sd),
      prior(lkj(2), class = cor)
    ),
  data = df_gibsonwu2
)
post_summary2_inf<-round(posterior_summary(fit_df_gibsonwu2_inf,variable = "b_c_cond"),3)
post_mean2_inf<-post_summary2_inf[1,1]
post_lower2_inf<-post_summary2_inf[1,3]
post_upper2_inf<-post_summary2_inf[1,4]

## meta-analysis prior:
fit_df_gibsonwu2_ma <- brm(rt ~ c_cond + 
                                (c_cond | subj) + (c_cond | item),
  family = lognormal(),
  prior =
    c(
      prior(normal(6, 1.5), class = Intercept),
      prior(normal(0.041, 0.2), class = b),
      prior(normal(0, 1), class = sigma),
      prior(normal(0, 1), class = sd),
      prior(lkj(2), class = cor)
    ),
  data = df_gibsonwu2
)
post_summary2_ma<-round(posterior_summary(fit_df_gibsonwu2_ma, 
                  variable = "b_c_cond"),3)
post_mean2_ma<-post_summary2_ma[1,1]
post_lower2_ma<-post_summary2_ma[1,3]
post_upper2_ma<-post_summary2_ma[1,4]


posteriors<-data.frame(rbind(c(post_mean2,
                               post_lower2,post_upper2),
c(post_mean2_inf,post_lower2_inf,post_upper2_inf),
c(post_mean2_ma,post_lower2_ma,post_upper2_ma)
))

posteriors<-cbind(c("Normal(0,1)",
                    "Normal(-0.07,0.2)",
                    "Normal(0.041, 0.2)"),
      posteriors)
colnames(posteriors)<-c("Priors","Mean","Lower","Upper")


## ----replicationpriors,echo=FALSE,results="asis"----
kableExtra::kable(posteriors,
                  digits = 2, booktabs = TRUE, 
                  vline = "", # format="latex",
  caption = "A summary of the posteriors under a (relatively) uninformative prior (Normal(0,1)), a prior based on the original data, and a meta-analysis prior, for data from a replication attempt of Gibson and Wu, 2013.")

